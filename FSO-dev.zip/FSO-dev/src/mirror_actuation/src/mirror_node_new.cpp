#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <libserial/SerialPort.h>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "mirror_node.hpp"
#include "../../custom_interfaces/custom_dt.h"

#include "custom_interfaces/msg/camera_coords_message.hpp"
#include "custom_interfaces/msg/heart_beat.hpp"  
#include "custom_interfaces/msg/move_mirror.hpp"



/*
 * Mirror
 * Mirror represents a virtual model of a physical mirror. It maintains the mirror's state, and has methods to enact a change in the physical state of the mirror.
 * Note that Mirror doesn't directly update the physical mirror. The mirrorUpdate message is first sent out to a Mirror_Translator, which parses the mirrorUpdate and
 * then dispatches the command to the selected interface.
 * 
 * ROS2 PARAMETERS
 * - mirrorIdParam: The ID of the mirror. Used when addressing messages to a serial interface.
 *
 * 7/15/24
 * In trying to follow "Open-Closed" in SOLID, I've made a new mirror node to not break backwards compatibility.
 * Following Brian's ptu-5 example, I'm converting this to a combo "command + serial" node. This node receives a message, and also dispatches it to the
 * serial interface.
 * I'm also updating the style to match Brian's.
 */

using namespace std::chrono_literals;
using std::placeholders::_1;


class Mirror : public rclcpp::Node
{
  public:
  Mirror() : Node("mirror")
  {
    initialization();

    std::string statusMsgName = this->get_name();
    statusMsgName.append("_status");
    status = this->create_publisher<custom_interfaces::msg::HeartBeat>(statusMsgName, 10);
    
    //Timers
    heartBeatTimer = this->create_wall_timer(1000ms, std::bind(&Mirror::heartBeat, this));
    watchDogTimer = this->create_wall_timer(100ms, std::bind(&Mirror::watchDog, this));


    //Callbacks
    //Register a callback function that will be called whenever there is attempt
    //to change one or more parameters of the node
    parameter_callback_handle = this->add_on_set_parameters_callback(
    std::bind(&Mirror::parameter_change_callback, this, std::placeholders::_1));

    recvMoveCmd = this->create_subscription<custom_interfaces::msg::MoveMirror>("move_mirror", 10, std::bind(&Mirror::moveMirrorCallback, this, _1));

    updateXY(0,0);

  }

  ~Mirror()
  {
    updatePos(XAXIS, 0.0f);
    updatePos(YAXIS, 0.0f);
    m_mirrorPort.Close();
  }

  private:

  bool connect_serial()
  {
    bool success = false;
    std::string nodeName = this->get_name();
    std::string nodePort = this->get_parameter("comm_port").as_string();

    try 
    {
      //Close the serial if open
      if(m_mirrorPort.IsOpen())
      {
        m_mirrorPort.Close();
      }

      RCLCPP_INFO(this->get_logger(), "Trying to open %s Serial Port:  %s", nodeName.c_str(), nodePort.c_str());

      m_mirrorPort.Open(this->get_parameter("comm_port").as_string());
      m_mirrorPort.SetBaudRate(LibSerial::BaudRate::BAUD_230400);  //recommended 256000pbs, libserial does not support using closest
      m_mirrorPort.SetCharacterSize(LibSerial::CharacterSize::CHAR_SIZE_8);
      m_mirrorPort.SetStopBits(LibSerial::StopBits::STOP_BITS_1);
      m_mirrorPort.SetParity(LibSerial::Parity::PARITY_NONE);
      m_mirrorPort.SetFlowControl(LibSerial::FlowControl::FLOW_CONTROL_NONE);
      
      if(m_mirrorPort.IsOpen())
      {
        success = true;
        nodeState = status::state::running;
        RCLCPP_INFO(this->get_logger(), "%s Serial Port %s successfully opened", nodeName.c_str(), nodePort.c_str());
      }
      else
      {
        success = false;
        nodeState = status::state::error;
        RCLCPP_WARN(this->get_logger(), "%s Serial Port %s was not opened", nodeName.c_str(), nodePort.c_str());
      }

      return success;
    }
    catch (const LibSerial::NotOpen&)
    {
      success = false;
      nodeState = status::state::error;
      RCLCPP_WARN(this->get_logger(), "%s Serial Port %s not open", nodeName.c_str(), nodePort.c_str());
    }
    catch (const LibSerial::OpenFailed&)
    {
      success = false;
      nodeState = status::state::error;
      RCLCPP_WARN(this->get_logger(), "%s Serial Port %s failed to open", nodeName.c_str(), nodePort.c_str());
    }
    catch (const LibSerial::AlreadyOpen&)
    {
      success = true;
      nodeState = status::state::error;
      RCLCPP_WARN(this->get_logger(), "%s Serial Port %s is already open", nodeName.c_str(), nodePort.c_str());
    }
    return success;
  }
  void declareParams()
  {
    nodeCommType = status::commType::serial;
    nodeState = status::state::initializating;  
    moveToXY = "xy=0.0";
    
    this->declare_parameter("comm_port", "/dev/ttyACM1");
    this->declare_parameter("mirror_id_param", -1);
    this->declare_parameter("moveCmdXY", "xy=0;0");
  }

  bool get_resp(std::string &rtnValue, bool silent = false)
  {
    bool success = true;
    std::string nodeName = this->get_name();
    std::string nodePort = this->get_parameter("comm_port").as_string();
    try
    {
        m_mirrorPort.ReadLine(rtnValue);
        rtnValue.pop_back();  //Remove newline
    }
    catch (const LibSerial::NotOpen&)
    {
      success = false;
      nodeState = status::state::error;
      RCLCPP_WARN(this->get_logger(), "%s Serial Port %s not open", nodeName.c_str(), nodePort.c_str());
    }
    catch (const LibSerial::OpenFailed&)
    {
      success = false;
      nodeState = status::state::error;
      RCLCPP_WARN(this->get_logger(), "%s Serial Port %s failed to open", nodeName.c_str(), nodePort.c_str());
    }
    catch (const LibSerial::AlreadyOpen&)
    {
      success = true;
      nodeState = status::state::error;
      RCLCPP_WARN(this->get_logger(), "%s Serial Port %s is already open", nodeName.c_str(), nodePort.c_str());
    }

    if(!silent)
    {
      std::string strSuccess = (success == 0) ? "false" : "true";
      RCLCPP_INFO(this->get_logger(), "Read was successful:  %s", strSuccess.c_str());
      RCLCPP_INFO(this->get_logger(), "Response: %s", rtnValue.c_str());
    }
    
  }

  void heartBeat()
  {   
  //   auto msg = custom_interfaces::msg::HeartBeat();
  //   msg.epoch = timer.timeSinceEpoch_us();
  //   msg.node_state = (int)nodeState;
  //   msg.comm_type = (int)nodeCommType;
  //   status->publish(msg);
  }

  void initialization()
  {
    declareParams();
    initializeFlags();
    if(!connect_serial())
    {
      nodeState = status::state::error;
    }

    if(m_mirrorPort.IsOpen())
    {
      if(!isMirrorHealthy())
      {
        nodeState = status::state::error;
      }
    } 
  }

  void initializeFlags()
  {

  } 

  bool isBitSet(int input, int bitToCheck)
  {
    //Check if a bit is set, input is the num to check
    //                       bitToCheck is the nth bit to verify
 
    bool success = (input & (1 << bitToCheck) ? true : false);

    return success;
  }

  bool isMirrorHealthy()
  {

    std::map<int, std::string> errorCodes;  //Key:  Bit | Value: Description  Bits 14-31 reserved
    errorCodes.insert({0, "Proxy not connected!"});
    errorCodes.insert({1, "Proxy temperature threshold is reached!"});
    errorCodes.insert({2, "Mirror temperature threshold is reached!"});
    errorCodes.insert({3, "Mirror EEPROM not valid!"});
    errorCodes.insert({4, "Mirror not stable!"});
    errorCodes.insert({5, "Output current limit is reached!" });
    errorCodes.insert({6, "Output current average limit is reached!"});
    errorCodes.insert({7, "XY input is trimmed!"});
    errorCodes.insert({8, "Proxy was disconnected!"});
    errorCodes.insert({9, "Proxy temperature threshold was reached!"});
    errorCodes.insert({10, "Mirror temperature threshold was reached!"});
    errorCodes.insert({11, "Output current limit was reached!"});
    errorCodes.insert({12, "Output current average limit was reached!"});
    errorCodes.insert({13, "XY input was was trimmed!"});

    bool success = true;
    std::string response;
    int statusBits;

    sendCmd("status", true);
    get_resp(response, true);

    if(!response.empty())
    {
      statusBits = std::atoi(response.c_str());
      for(int i = 0; i < 14; i++)
      {
        if(isBitSet(statusBits, i))
        {
          success = false;
          std::map<int, std::string>::iterator it;
          it = errorCodes.find(i);
          RCLCPP_ERROR(this->get_logger(), MIRROR_STATUS_ERROR, it->second.c_str());
        }
      }
    }
    
    return success;
  }

  void moveMirrorCallback(const custom_interfaces::msg::MoveMirror::SharedPtr msg)
  {
     updateXY(msg->x, msg->y);
     
  }

  rcl_interfaces::msg::SetParametersResult parameter_change_callback(const std::vector<rclcpp::Parameter> &params){
    auto result = rcl_interfaces::msg::SetParametersResult();
    result.successful = true;


    for(const auto &param : params)
    {
      RCLCPP_INFO(this->get_logger(), MSG_PARAM_UPDATE, param.get_name().c_str(), param.as_string().c_str());

      if(param.get_name() == "comm_port" && param.get_type() ==  rclcpp::ParameterType::PARAMETER_STRING)
      {
        nodeState = status::state::reconnecting;  //set flag to reconnect in watchdog
      }
      else if(param.get_name() == "mirror_id_param" && param.get_type() == rclcpp::ParameterType::PARAMETER_STRING)
      {

      }
      else if(param.get_name() == "moveCmdXY" && param.get_type() == rclcpp::ParameterType::PARAMETER_STRING)
      {
        moveToXY = param.as_string();
        sendCmd(moveToXY);
      }
      else
      {
        result.successful = false;
        result.reason = "Parameter not supported";
      }
    }

    return result;

  }
  
  bool reconnect(int numRetries)
  {
    bool success = false;
    std::string name = this->get_name();
    std::string port = this->get_parameter("comm_port").as_string();
    
    for (int i = 1; i <= numRetries; i++)
    {
    RCLCPP_WARN(this->get_logger(), "Trying to reconnect, attempt %d", i);
    if(connect_serial())
    {
        success = true;
        break;
    }
    else
    {
        usleep(10 * 1000);
        if(i == numRetries)
        {
        success = false;
        RCLCPP_ERROR(this->get_logger(), "%s failed to reconnect to port:  %s", name.c_str(), port.c_str());
        nodeState = status::state::error;
        }
    }
    }
    return success;
  }

  bool sendCmd(std::string cmd, bool silent = false)
  {    bool success = false; 
    try
    {     
      if(m_mirrorPort.IsOpen())
      {
        std::string::iterator it;
        for(it = cmd.begin(); it != cmd.end(); ++it)
        {  
          m_mirrorPort.WriteByte(*it);
        }
        m_mirrorPort.WriteByte('\r');
        m_mirrorPort.WriteByte('\n');  //terminate cmd

        success = true;
      } 

      m_mirrorPort.DrainWriteBuffer();  //wait for command to sent


      if(!silent)
      {
        std::string strSuccess = (success == 0) ? "false" : "true";
        RCLCPP_INFO(this->get_logger(), "Cmd Sent:  %s | Was Successful: %s", cmd.c_str(), strSuccess.c_str());
      }
    }
    catch (const LibSerial::NotOpen&)
    {
      success = false;
      //RCLCPP_WARN(this->get_logger(), "%s Serial Port %s not opened", this->get_name(), this->get_parameter("comm_port").as_string().c_str());
      nodeState = status::state::notConnected;
      std::string msg = "Command failed:  " + cmd;
      //reconnect(3);
    }
    catch (const LibSerial::OpenFailed&)
    {
      success = false;
      //RCLCPP_WARN(this->get_logger(), "%s Serial Port %s failed to open", this->get_name(), this->get_parameter("comm_port").as_string().c_str());
      nodeState = status::state::notConnected;
      std::string msg = "Command failed:  " + cmd;
      //reconnect(3);
    }
    catch (const LibSerial::AlreadyOpen&)
    {
      success = true;
      //RCLCPP_WARN(this->get_logger(), "%s Serial Port %s already open", port->second->status.msgName.c_str(), port->second->status.commPort.c_str());
    }
    
    return success;
  }

  void updatePos(uint16_t whichAxis, double arg)
  {
    //std::cout << "updatePos called" << std::endl;
    std::string argStr;
    std::stringstream tempStrStream;
    tempStrStream << std::fixed << std::setprecision(5) << arg;
    if(whichAxis == XAXIS){
      argStr = "x=" + tempStrStream.str();
    } else {
      argStr = "y=" + tempStrStream.str();
    }
    sendCmd(argStr);
  }

  void updateXY(double Xm, double Ym)
  {
    std::string argStr;
    std::stringstream tempStrStreamX;
    std::stringstream tempStrStreamY;

    tempStrStreamX << std::fixed << std::setprecision(5) << Xm;
    tempStrStreamY << std::fixed << std::setprecision(5) << Ym;

    argStr = "xy=" + tempStrStreamX.str() + ";" + tempStrStreamY.str(); 
    sendCmd(argStr);

  }

  void watchDog()
  {
    //Keep this code short - it will tie up Node
    //Move to a thread at some point
    if(nodeState == status::state::reconnecting)
    {
      RCLCPP_INFO(this->get_logger(), MSG_WD_FIRED, "reconnect");
      nodeState = (reconnect(3)) ? status::state::running : status::state::error;

    }

    if(!isMirrorHealthy())
    {
      nodeState = status::state::error;
    }
  }
  
  private:
  rclcpp::TimerBase::SharedPtr heartBeatTimer;
  status::commType nodeCommType;
  status::state nodeState;
  rclcpp::TimerBase::SharedPtr mirrorStatusTimer;
  LibSerial::SerialPort m_mirrorPort;


  rclcpp::Publisher<custom_interfaces::msg::HeartBeat>::SharedPtr status;
  rclcpp::TimerBase::SharedPtr watchDogTimer;
  rclcpp::TimerBase::SharedPtr cameraTimer;
  rclcpp::Subscription<custom_interfaces::msg::MoveMirror>::SharedPtr recvMoveCmd;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;

  

  double pos_x;
  double pos_y;
  float xpyp;

  std::string moveToXY;
};

int main(int argc, char * argv[]){
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Mirror>());
  rclcpp::shutdown();
  return 0;
}
