#!/bin/bash

#######################################################################
#
# SCRIPT MUST BE RUN AS USER
#
#This is a bash script that automates the setup
#process for our current PTU environment.
#
#This contains ALL setup commands that will need 
#to be ran to setup our ROS PTU environment. Each command
#in the COMMANDS array will be ran, after their execution
#the script will check their exit code to ensure they are executed
#properly. The functions will then be appended to a PASSED_COM
#or a FAILED_COM array depending respective to their exit code 
#(exit code 0 indicates a pass).
#
#Adding functions to the COMMANDS list: The COMMANDS array 
#contains ALL commands to be ran to setup the environment. The 
#commands are ran in chronological order from top down, thus the 
#ordering is important within the list. To add a command to the list
#you must create a user defined function in the form of:
#
# foo_func(){
#     #do something
# }
#
#The function can then be added to the COMMANDS array in the position in
#which that command needs to be executed. Minimize the amount of commands
#in a single function to improve organization and robustness of the
#script. Although tedious, this will allow for installation
#debugging to be a smoother process!

#######################################################################

PASS_COLOR='\033[1;32m'
FAIL_COLOR='\033[1;31m'
WARNING_COLOR='\033[1;33m'
NO_COLOR='\033[0m'

#Commands to setup environment
declare -a COMMANDS=(
    "generate_ssh"
    "user_access_serial"
    "usb_access"
    "fpga_rules"
    "create_setup_directory"
    "create_project_folder"
    "install_git"
    "verify_python"
    "install_pip"
    "install_pyvisa"
    "install_libSerial"
    "install_dev_tools"
    "install_nmap"
    "install_nfs"
    "mount_nfs"
    "config_fstab"
    "copy_hardware"
    "copy_software"
    "extract_hardware_packages"
    "install_gcc_12"
    "install_make"
    "install_python_usbtmc"
    "install_meld"
    "install_putty"
    "install_ros2"
    "install_locales"
    "set_locales"
    "install_software_properties"
    "add_apt_repo"
    "install_curl"
    "install_pyqt6"
    "install_openssh"
    "extract_arduino"
    "install_arduino"
    "add_user_to_dialout"
    "curl_ros"
    "install_ros_humble"
    "install_ros_dev_tools"
    "install_pylon"
    "install_pylon_supp"
    "install_codemeter"
    "initialize_rosdep"
    "update_rosdep"
    "install_rosdep"
    "setup_ros_bash"
    "udpate_usbtmc_rules"
    "source_ssh"
    "export_ros"
    "install_vscode"
    "install_vscode_extensions"
    "fix_empy_version"  #must be after "install pip"
    "install_cffi"
    "install_kconfig"
    "install_jsonschema"
    "install_jinja2"
)

declare -a FPGA_COMMANDS=(
    "check_for_pci"
    "copy_fpga_zip"
    "unzip_fpga_zip"
    "make_install"
    "make_tools"
    "set_script_perms"
    "pci_startup"
)

declare -a NI_COMMANDS=(
    "test"
)

#Pass/Fail Arrays
declare -a PASSED_COMS
declare -a FAILED_COMS

#Args flags
standard_install=false
fpga_install=false
ni_install=false

#Check Args

while getopts "asfnh" opt; do
    case $opt in

        a)
            standard_install=true
            fpga_install=true
            ni_install=true
            ;;
        s)
            standard_install=true
            ;;
        f)
            fpga_install=true
            ;;
        n)
            ni_install=true
            ;;
        h)
            echo "Usage: ./Setupenvironment -[flags]"
            echo
            echo "          Flag   |               Description                   |          Example        "
            echo
            echo "Flag: |    -a    |    Install all available modules.           |    ./Setupenvironment -a"
            echo
            echo "Flag: |    -s    |    Install only environment modules.        |    ./Setupenvironment -s"
            echo
            echo "Flag: |    -f    |    Install FPGA modules.                    |    ./Setupemvironment -f"
            echo
            echo "Flag: |    -n    |    Install National Instruments modules.    |    ./Setupenvironment -n"
            echo
            ;;
        \?)
            echo "Usage: ./Setupenvironment -[flags]"
            echo
            echo "          Flag   |               Description                   |          Example        "
            echo
            echo "Flag: |    -a    |    Install all available modules.           |    ./Setupenvironment -a"
            echo
            echo "Flag: |    -s    |    Install only environment modules.        |    ./Setupenvironment -s"
            echo
            echo "Flag: |    -f    |    Install FPGA modules.                    |    ./Setupemvironment -f"
            echo
            echo "Flag: |    -n    |    Install National Instruments modules.    |    ./Setupenvironment -n"
            echo
            ;;
	
    esac
done

#Check for no flags, if no flags normal install
if
    [ "$OPTIND" -eq 1 ]; then
    standard_install=true 
fi

##################################
#
#Command Functions
#
##################################

test(){
    echo "Hello World!"
}

pci_startup(){
    sudo cp /media/Hardware/GUB/load-drivers-startup.service /etc/systemd/system/
    sudo chmod +x /opt/fso_prj/FSO/scripts/load_drivers_startup.sh
    sudo systemctl daemon-reload
    sudo systemctl enable load-drivers-startup.service
    sudo systemctl start load-drivers-startup.service
}

#Create SSH Keys
generate_ssh(){
    PUBLIC_KEY=$(find ~/.ssh . -type f -name "*.pub" | head -n 1) 
    if [ $PUBLIC_KEY ] ; then
    echo "Your public key is: "
    cat "$PUBLIC_KEY"
    else 
        echo "Failed to locate key, generating key."
        ssh-keygen -t ed25519 -f ~/.ssh/$HOSTNAME -q -N ""
    fi
}

#Add user to dialout group for serial access
user_access_serial(){
    sudo usermod -a -G dialout $USER
}

#Give access to all USB devices
#must be done this way to handle permission issues when create the file
usb_access(){
    sudo echo "KERNEL==\"ttyUSB[0-9]*\",MODE=\"0666\"" > 50-myusb.rules
    sudo echo "KERNEL==\"ttyAMC[0-9]*\",MODE=\"0666\"" >> 50-myusb.rules
    sudo mv 50-myusb.rules /etc/udev/rules.d/
    sudo chown root:root /etc/udev/rules.d/50-myusb.rules
}

# Add rule 49
fpga_rules(){
    sudo echo "KERNEL==\"xdma0_user\",MODE=\"0666\"" > 49-fpga.rules
    sudo echo "KERNEL==\"xdma0_h2c_0\",MODE=\"0666\"" >> 49-fpga.rules
    sudo echo "KERNEL==\"xdma0_c2h_0\",MODE=\"0666\"" >> 49-fpga.rules
    sudo mv 49-fpga.rules /etc/udev/rules.d/
    sudo chown root:root /etc/udev/rules.d/49-fpga.rules
}

#Create a setup folder to keep track of files
create_setup_directory(){
    if [ -d "/home/$USER/setup" ] ; then
        echo "Setup directory already created, building environment..."
    else
        mkdir /home/$USER/setup && cd ~/setup
    fi
}

#Update Unix
update_unix_packages(){
    sudo apt update
}

#Upgrade Unix
upgrade_unix_packages(){
    sudo apt upgrade -y
}

###############################################################

#Check for PCI
check_for_pci(){
    TEST=$(lspci | grep Xilinx)
    if [[ $TEST != *"Xilinx"* ]]; then
        echo -e "${WARNING_COLOR} PCI Card not found. ${NO_COLOR}"
        PCI_FOUND=false
    else
        PCI_FOUND=true
    fi
}

copy_fpga_zip(){
    if [[ $PCI_FOUND == true ]] ; then
        ZIP=$(find /media/Hardware/GUB . -name cfd_xem83x0_fpga-main.zip)
        echo "$ZIP"
        cp $ZIP /home/$USER/setup
    else
        echo -e "${WARNING_COLOR} PCI not detected skipping file zip copy... ${NO_COLOR}"
    fi
}

unzip_fpga_zip(){

    if [[ $PCI_FOUND == true ]] ; then
        unzip $ZIP -d /opt/fso_prj
    else
        echo -e "${WARNING_COLOR} PCI not dectected, skippping unzip... ${NO_COLOR}"
    fi
}

make_install(){
    
    if [[ $PCI_FOUND == true ]] ; then
        pushd /opt/fso_prj/cfd_xem83x0_fpga-main/xem8320_pcie/sw/XDMA/linux-kernel/xdma
        sudo make install
        popd
    else
        echo -e "${WARNING_COLOR} PCI not dectected, skippping make install... ${NO_COLOR}"
    fi
}

make_tools(){
    if [[ $PCI_FOUND == true ]] ; then
        pushd /opt/fso_prj/cfd_xem83x0_fpga-main/xem8320_pcie/sw/XDMA/linux-kernel/tools
        make
        popd
    else
        echo -e "${WARNING_COLOR} PCI not dectected, skippping tools build... ${NO_COLOR}"
    fi
}

set_script_perms(){
    if [[ $PCI_FOUND == true ]] ; then
        pushd /opt/fso_prj/cfd_xem83x0_fpga-main/xem8320_pcie/sw/XDMA/linux-kernel/tests
        chmod +x *.sh scripts_mm/*.sh
        popd
    else
        echo -e "${WARNING_COLOR} PCI not dectected, skippping perms... ${NO_COLOR}"
    fi
}

###############################################################

#Create Project Folder
create_project_folder(){
    sudo mkdir -p /opt/fso_prj
    sudo chown $USER /opt/fso_prj
    sudo chmod 777 /opt/fso_prj
}

#Install Git
install_git(){
    sudo apt install git -y
}

verify_python(){
    if command -v python3 &>/dev/null; then
        echo "Python3 is already installed, continuing..."
    else
        echo "Installing Python3..."
        sudo apt install python 3 -y
    fi
}

#Install pip
install_pip(){
    sudo apt install python3-pip -y
}

#Install Pyvisa
install_pyvisa(){
    pip install -U pyvisa
    pip3 install pyvisa-py  
}

#Install libSerial
install_libSerial(){
    sudo apt install libserial-dev -y
}

#Install Dev Tools
install_dev_tools(){
    sudo apt-get install build-essential -y
}

#Install Nmap
install_nmap(){
    sudo apt install nmap -y
}

#Install NFS
install_nfs(){
    sudo apt install nfs-common -y
}

#Mount NFS to Hardware and Software folders
mount_nfs(){
    MOUNT=$(find /media . -type d -name "Hardware")

    if [ $MOUNT ] ; then
    echo "nfs already mounted"
    else
        sudo mkdir /media/Hardware
        sudo mkdir /media/Software
        sudo mount 10.1.5.143:/volume1/Hardware /media/Hardware
        sudo mount 10.1.5.143:/volume1/Software /media/Software
    fi
}


#Configure Fstab to mount NFS on startup
config_fstab(){
    echo "" | sudo  tee -a /etc/fstab
    echo "10.1.5.143:/volume1/Hardware /media/Hardware nfs auto,nofail,noatime,nolock,intr,tcp,actimeo=1800 0 0" | sudo  tee -a /etc/fstab
    echo "10.1.5.143:/volume1/Software /media/Software nfs auto,nofail,noatime,nolock,intr,tcp,actimeo=1800 0 0" | sudo  tee -a /etc/fstab
}

install_gcc_12(){
    sudo apt install gcc-12
}

install_make(){
    sudo apt install make
}

#Copy software packages from NFs to setup folder
#Note: If the name of this .tar.xz file changes beyond 'python-', we will need to update the command
copy_hardware(){
    TAR_FILE=$(find /media/Hardware/GUB . -type f -name "python-*.xz" | head -n 1)
    echo "$TAR_FILE"
    cp $TAR_FILE /home/$USER/setup
}

#Copy software packages from NFS to setup folder
copy_software(){
    cp /media/Software/GUB_Software/* /home/$USER/setup
}

#Extract Hardware Packages
extract_hardware_packages(){
    TAR_FILE=$(find /home/$USER/setup . -type f -name "python-*.xz" | head -n 1)
    tar -xvf $TAR_FILE
}

#Extract Software Packages
#This has not been set up yet. Do not append to list yet.
extract_software_packages(){
    echo "EXTRACTING SOFTWARE PACKAGES: DELETE ME!"
    #Something to extract software when set up
}

#Install Python USBTMC
install_python_usbtmc(){
    mkdir ~/setup/python-usbtmc
    unzip ~/setup/python-usbtmc
    cd  python-usbtmc/python-usbtmc-master
    python3 setup.py install
    if [ $? -eq 0 ]; then
        cd ..
        return 1
    fi
    cd ..
}

#Install Meld
install_meld(){
    sudo apt install meld
}

#Install Putty
install_putty(){
    sudo apt install putty -y
}

#Install ROS2 Humble
#Refer to https://colcon.readthedocs.io/en/released/user/installation.html#using-pip-on-any-platform for 
#pip installation preferences, this will effect the nature of the "setup_ros_bash" function
install_ros2(){
    sudo pip3 install -U colcon-common-extensions
}

#Install Locales
install_locales(){
    sudo apt install locales -y
}

#Set Locales
set_locales(){
    sudo locale-gen en_US en_US.UTF-8
}

#Update Locales
update_locales(){
    sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
    export LANG=en_US.UTF-8
}

#Install Software Properties
install_software_properties(){
    sudo apt install software-properties-common
}

#Add Apt Repo
add_apt_repo(){
    sudo add-apt-repository universe
}

#Install Curl
install_curl(){
    sudo apt install curl -y
}

#Install pyqt
install_pyqt6(){
    pip3 install pyqt6
}

#Install openssh
install_openssh(){
    #sudo apt install openssh
    sudo apt install openssh-client openssh-server
}

#Get ROS Distro
curl_ros(){
    sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
}

#Install ROS Humble
install_ros_humble(){
    sudo apt install ros-humble-desktop -y
}

#Install ROS Developer Tools
install_ros_dev_tools(){
    sudo apt install ros-dev-tools
}

#Extract Arduino IDE
extract_arduino(){
    ARDUINO_FILE=$(find /home/$USER/setup . -type f -name "arduino-*" | head -n 1)
    tar -xvf $ARDUINO_FILE
}

#Install Arduino IDE
install_arduino(){
    cd arduino-1.8.19
    sudo sh install.sh
    cd ..
}

#Add User to dialout
add_user_to_dialout(){
    sudo usermod -a -G dialout $USER
}

#Install Pylon Camera Packages
install_pylon(){
    PYLON_FILE=$(find /home/$USER/setup . -type f -name "pylon_*.deb" | head -n 1)
    sudo dpkg -i $PYLON_FILE
}

#Install Pylon Camera Supplementary Packages
install_pylon_supp(){
    PYLON_SUPP_FILE=$(find /home/$USER/setup . -type f -name "pylon-supplementary-package-for-blaze-*.deb" | head -n 1)
    sudo dpkg -i $PYLON_SUPP_FILE
}

#Install Codemeter Packages
install_codemeter(){
    CODEMETER_FILE=$(find /home/$USER/setup . -type f -name "codemeter_*.deb" | head -n 1)
    sudo dpkg -i $CODEMETER_FILE
}

#Initialize RosDep Resources
initialize_rosdep(){
    SOURCE_LIST=$(find /etc/ros/rosdep/sources.list.d . -type f -name "*.list" | head -n 1) 
    if [ $SOURCE_LIST ] ; then
    echo "Rosdep already initialized"
    else
        sudo rosdep init
    fi
}

#Update RosDep Resources
update_rosdep(){
    sudo rosdep update
}


#ROS dep Install
install_rosdep(){
    cd /opt/fso_prj/FSO
    rosdep install --from-paths src --ignore-src -r -y
    cd /home/$USER/setup
}

#Config Bashrc for ROS
#This is currently configured under a local setup. If we
#wish to procede with a global install this needs to be 
#discussed. Since ROS is installed via pip, it may be beneficial
#and space resourceful to use a pip global (install in a global
#directory rather than in a user directory). ROS provides 3 
#sourcing options as listed in the function below
#refer to https://colcon.readthedocs.io/en/released/user/installation.html#enable-completion for a detailed #explanation

setup_ros_bash(){
    source /opt/ros/humble/setup.bash
    #source /usr/share/colcon_argcomplete/hook/colcon-argcomplete.bash #Debian package option
    #source $HOME/.local/share/colcon_argcomplete/hook/colcon-argcomplete.bash #PIP user local option
    source /usr/local/share/colcon_argcomplete/hook/colcon-argcomplete.bash #PIP global option
    
: ' Note: the install directory is within the git ignore and never gets pulled
    GIT_BRANCH=$(find /opt/fso_prj . -type d -name "FSO")
    if [ $GIT_BRANCH ] ; then
    source /opt/fso_prj/FSO/install/local_setup.sh 
    else
        echo "Git repository must be pulled first"
    fi
'

}

#Update USBTMC Rules
#Reboot must occur before /etc/ rules can be applied 
udpate_usbtmc_rules(){
    echo "" | sudo tee -a /etc/udev/rules.d/68-usbtmc.rules
    echo "#USBTCM  instruments" | sudo tee -a /etc/udev/rules.d/68-usbtmc.rules
    echo "#THORLABS USB Devices" | sudo tee -a /etc/udev/rules.d/68-usbtmc.rules
    echo "SUBSYSTEMS=="usb", ACTION=="add", ATTRS{idVendor}=="1313", GROUP="usbtmc", MODE="0660"" | sudo tee -a /etc/udev/rules.d/68-usbtmc.rules
    echo "#KERNEL=="usbtmc/*",       MODE="0660", GROUP="usbtmc"" | sudo tee -a /etc/udev/rules.d/68-usbtmc.rules
    echo "#KERNEL=="usbtmc[0-9]*",   MODE="0660", GROUP="usbtmc"" | sudo tee -a /etc/udev/rules.d/68-usbtmc.rules
}

#Add SSH keys
source_ssh(){
    PUBLIC_KEY=$(find ~/.ssh . -type f -name "*.pub" | head -n 1) 
    chmod 400 $PUBLIC_KEY
    eval `ssh-agent`
    ssh-add 
    #ssh-add $PUBLIC_KEY
}


#Export ROS Pico
export_ros(){
    export PICO_SDK_PATH=/home/$USER/pico/pico-sdk
    export PICO_EXAMPLES_PATH=/home/$USER/pico/pico-examples
    export PICO_EXTRAS_PATH=/home/$USER/pico/pico-extras
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/pylon/lib/
}


#Install Visual Studio Code
install_vscode(){
    VSCODE_FILE=$(find /home/$USER/setup . -type f -name "code_*.deb" | head -n 1)
    sudo apt install $VSCODE_FILE
}


#Install Visual Studio Code Extensions
install_vscode_extensions(){
    code --install-extension ms-vscode.cpptools #Microsoft C++
    code --install-extension ms-iot.vscode-ros #Microsoft ROS
    code --install-extension mhutchie.git-graph #Mhutchi Git Graph
}

#Fix empy versions
#colcon-core 0.16.0 requires EmPy<4, but you have empy 4.1 which is incompatible. 
fix_empy_version(){
    pip3 unistall empy
    pip3 install empy==3.3.4
}

install_cffi(){
    pip3 install cffi
}

install_kconfig(){
    pip3 install kconfiglib
}

install_jsonschema(){
    pip install --user jsonschema
}

install_jinja2(){
    pip install --user jinja2
}

##########################################################

if [ "$standard_install" = true ]; then
    # Execute list of commands, appending to proper pass/fail array
    for i in "${COMMANDS[@]}"; do 
        $i
        if [ $? -eq 0 ]; then
            echo -e "${PASS_COLOR}Passed: ${i} with exit code: $? ${NO_COLOR}"
            PASSED_COMS+=("$i")
        else
            echo -e "${FAIL_COLOR}Failed: ${i} with exit code: $? ${NO_COLOR}"
            FAILED_COMS+=("$i")
        fi        
    done
fi

if [ "$fpga_install" = true ] ; then
    #Execute list of commands, append to proper pass/fail array
    for i in ${FPGA_COMMANDS[@]}; do 
        $i
        if [ $? -eq 0 ]; then
            echo -e "${PASS_COLOR}Passed: "${i}" with exit code: $? ${NO_COLOR}"
            PASSED_COMS+=("$i")
        else
        	echo -e "${FAIL_COLOR}Failed: "${i}" with exit code: $? ${NO_COLOR}"
            FAILED_COMS+=("$i")
        fi        
    done
fi

if [ "$ni_install" = true ] ; then
    #Execute list of commands, append to proper pass/fail array
    for i in ${NI_COMMANDS[@]}; do 
        $i
        if [ $? -eq 0 ]; then
            echo -e "${PASS_COLOR}Passed: "${i}" with exit code: $? ${NO_COLOR}"
            PASSED_COMS+=("$i")
        else
        	echo -e "${FAIL_COLOR}Failed: "${i}" with exit code: $? ${NO_COLOR}"
            FAILED_COMS+=("$i")
        fi        
    done
fi

echo "
     "
#Print all commands to the terminal     
echo "PASSED COMMANDS:"
for i in "${PASSED_COMS[@]}"; do
    echo "    $i"
done

echo ""
echo "FAILED COMMANDS:"
for i in "${FAILED_COMS[@]}"; do
    echo "    $i"
done

#Print host key for ease of upload to Github
echo ""
echo "Setup complete. Ensure to add your public key to the FSO Github in order to clone the repo"
echo "Your public key is:"
cat "$PUBLIC_KEY"
