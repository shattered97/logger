#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <libserial/SerialPort.h>
#include "timer/timer.h"
#include <iostream>
#include <thread>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
/////////////////////////////////
// NODE HPP FILE HERE
/////////////////////////////////
#include "../../custom_interfaces/custom_dt.h"
#include "custom_interfaces/msg/heart_beat.hpp"
#include "custom_interfaces/msg/camera_coords_message.hpp"

#include "src/gimbal_interface.h"
#include "src/bootloader.h"
#include "src/serial_port.h"

/*
 * CLASS NAME
 *
 * ROS2 PARAMETERS
 *
 *
 * NOTES
 *
 */

using namespace std::chrono_literals;
using std::placeholders::_1;

#define _TIMEOUT 30
#define _TIMEOUT_RETURN_HOME 3

struct sdk_process_t
{
  gremsy::sdk_process_state_t state = gremsy::STATE_IDLE;
  uint64_t timeout_ms;
};

struct gimbal_mode_t
{
  gremsy::type_of_gimbal gimbal_type;
  uint8_t mnt_mode;
};

class T3V3 : public rclcpp::Node
{
public:
  T3V3() : Node("t3v3_node")
  {
    initialization();

    std::string statusMsgName = this->get_name();
    status = this->create_publisher<custom_interfaces::msg::HeartBeat>(statusMsgName, 10);

    heartBeatTimer = this->create_wall_timer(1000ms, std::bind(&T3V3::heartBeat, this));
    watchDogTimer = this->create_wall_timer(100ms, std::bind(&T3V3::watchDog, this));

    parameter_callback_handle = this->add_on_set_parameters_callback(std::bind(&T3V3::parameter_change_callback, this, _1));

    cameraCoords = this->create_subscription<custom_interfaces::msg::CameraCoordsMessage>("camera_coords", 10, std::bind(&T3V3::recvCameraCoords, this, _1));

    gimbalThread = std::thread(&T3V3::runGimbalThread, this);
  }

  ~T3V3()
  {
    gimbalThreadRunning = false;
    gimbalThread.join();
  }

private:

  void recvCameraCoords(const custom_interfaces::msg::CameraCoordsMessage::SharedPtr msg)
  {
    RCLCPP_INFO(this->get_logger(), MSG_CAM_COORD, msg->target_id, msg->x, msg->y, msg->area, msg->brightness, msg->focal_length);
    int del_x = msg->x - x_trim; // For now, use known binned picture horizontal center of 360
    int del_y = msg->y - y_trim; // For now, use known binned picture vertical center of 270

    if (msg->target_found == true) // Only measure an angular error if a target is found, if not, set angular error to zero so gimbal doesn't deviate from current state
    {
      curr_angle_x = (180 / M_PI) * atan(0.001 * (msg->p_um) * del_x / (msg->focal_length));
      curr_angle_y = (180 / M_PI) * atan(0.001 * (msg->p_um) * del_y / (msg->focal_length));
    }
    else
    {
      curr_angle_x = 0.0;
      curr_angle_y = 0.0;
    }
    msg_detected = true;
  }

  void declareParams()
  {
    nodeState = status::state::unknown;
    nodeCommType = status::commType::serial;
    datafield = "empty";

    gimbalThreadRunning = true;

    this->declare_parameter("gimbal_com_port", "/dev/ttyUSB1");
    this->declare_parameter("baud_rate", 115200);
    this->declare_parameter("yaw_limit", 20);   // deg, ROS param for setting angular limits of gimbal, for some reason the yaw limit is actually 25 deg less than it is set to in code
    this->declare_parameter("pitch_limit", 20); // deg, ROS param for setting angular limits of gimbal
    this->declare_parameter("x_trim", 360);
    this->declare_parameter("y_trim", 270);
    this->declare_parameter("rate_hz", 1000);
    this->declare_parameter("limit_yaw_bias", 25);
    
    this->declare_parameter("tilt_speed_control", 180);
    this->declare_parameter("tilt_smooth_control", 45);
    this->declare_parameter("tilt_smooth_follow", 45);
    this->declare_parameter("tilt_window_follow", 1);

    this->declare_parameter("roll_speed_control", 10);
    this->declare_parameter("roll_smooth_control", 80);
    this->declare_parameter("roll_smooth_follow", 0);
    this->declare_parameter("roll_window_follow", 0);

    this->declare_parameter("pan_speed_control", 180);
    this->declare_parameter("pan_smooth_control", 45);
    this->declare_parameter("pan_smooth_follow", 45);
    this->declare_parameter("pan_window_follow", 1);


    comPort = this->get_parameter("gimbal_com_port").as_string();
    baudRate = this->get_parameter("baud_rate").as_int();
    limit_yaw = this->get_parameter("yaw_limit").as_int();
    limit_pitch = this->get_parameter("pitch_limit").as_int();
    x_trim = this->get_parameter("x_trim").as_int();
    y_trim = this->get_parameter("y_trim").as_int();
    rate_hz = this->get_parameter("rate_hz").as_int();
    limit_yaw_bias = this->get_parameter("limit_yaw_bias").as_int();

    tilt_speed_control = this->get_parameter("tilt_speed_control").as_int();
    tilt_smooth_control = this->get_parameter("tilt_smooth_control").as_int();
    tilt_smooth_follow = this->get_parameter("tilt_smooth_follow").as_int();
    tilt_window_follow = this->get_parameter("tilt_window_follow").as_int();

    roll_speed_control = this->get_parameter("roll_speed_control").as_int();
    roll_smooth_control = this->get_parameter("roll_smooth_control").as_int();
    roll_smooth_follow = this->get_parameter("roll_smooth_follow").as_int();
    roll_window_follow = this->get_parameter("roll_window_follow").as_int();

    pan_speed_control = this->get_parameter("pan_speed_control").as_int();
    pan_smooth_control = this->get_parameter("pan_smooth_control").as_int();
    pan_smooth_follow = this->get_parameter("pan_smooth_follow").as_int();
    pan_window_follow = this->get_parameter("pan_window_follow").as_int();
  }

  void heartBeat()
  {
    publishStatus(datafield);
  }

  void initialization()
  {

    nodeState = status::state::initializating;

    declareParams();
    initializeFlags();
    initializeGimbal();

    curr_angle_x = 0.0; // When node launches angle error starts at 0 degrees
    curr_angle_y = 0.0;

    msg_detected = false; // When node launches we haven't seen any ROS messages

    nodeState = status::state::running;
  }

  void initializeFlags()
  {
  }

  void initializeGimbal()
  {
    is_boot_mode = false;
    mav_gimbal_proto = Gimbal_Interface::MAVLINK_GIMBAL_V2;
  }

  bool initializeGimbalThread(Gimbal_Interface &gimbal_interface)
  {
    bool success = false;

    bool home = setGimbalHome(gimbal_interface);    
    bool follow = setGimbalFollowMode(gimbal_interface);    
    bool tilt = setGimbalTiltConfig(gimbal_interface);
    bool roll = setGimbalRollConfig(gimbal_interface);
    bool pan = setGimbalPanConfig(gimbal_interface);
    bool yaw = setLimitAngleYaw(gimbal_interface);
    bool angle = setLimitAnglePitch(gimbal_interface);

    if (home && follow && tilt && roll && pan && yaw && angle)
    {
      success = true;
    }

    return success;
  }

  void publishStatus(std::string datafield)
  {
    auto msg = custom_interfaces::msg::HeartBeat();
    msg.epoch = timer.timeSinceEpoch_us();
    msg.node_state = (int)nodeState;
    msg.comm_type = (int)nodeCommType;
    status->publish(msg);
  }

  rcl_interfaces::msg::SetParametersResult parameter_change_callback(const std::vector<rclcpp::Parameter> &params)
  {
    auto result = rcl_interfaces::msg::SetParametersResult();
    result.successful = true;

    for (const auto &param : params)
    {
      // RCLCPP_INFO(this->get_logger(), MSG_PARAM_UPDATE, param.get_name().c_str(), param.as_string().c_str());

      if (param.get_name() == "gimbal_com_port" && param.get_type() == rclcpp::ParameterType::PARAMETER_STRING)
      {
        nodeState = status::state::reconnecting;
        comPort = param.as_string();
      }
      if (param.get_name() == "baud_rate" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        baudRate = param.as_int();
      }
      if (param.get_name() == "yaw_limit" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        limit_yaw = param.as_int();
        RCLCPP_INFO(this->get_logger(), "What is Yaw?: (%d)\r\n", limit_yaw);

        /*Serial_Port serial_port(comPort.c_str(), baudRate);
        Gimbal_Interface gimbal_interface(&serial_port, 1, MAV_COMP_ID_ONBOARD_COMPUTER, mav_gimbal_proto, MAVLINK_COMM_0);

        serial_port.start();
        gimbal_interface.start();

        Gimbal_Interface::limit_angle_t limit_yaw_gSDK;

        //setting limit for yaw axis, determined by drone mounting HW
        limit_yaw_gSDK.angle_max = 1*(limit_yaw+25); //Sets gSDK angle limit boundaries to ROS params
        limit_yaw_gSDK.angle_min = -1*(limit_yaw+25);
        while (gimbal_interface.set_limit_angle_yaw(limit_yaw_gSDK) != Gimbal_Protocol::SUCCESS)
        {
            // printf("Try to set yaw limit again!\r\n"); Replacing with ROS debugger print
            RCLCPP_INFO(this->get_logger(), "Try to set yaw limit again!\r\n");
            usleep(1000);
        }
        // printf("Set yaw max: %d -- Set yaw min: %d\n" , limit_yaw_gSDK.angle_max, limit_yaw_gSDK.angle_min); Replacing with ROS debugger print
        RCLCPP_INFO(this->get_logger(), "Findlol Set yaw max: %d -- Set yaw min: %d \r\n" , gimbal_interface.get_limit_angle_yaw().angle_max, gimbal_interface.get_limit_angle_yaw().angle_min);

        serial_port.stop();
        gimbal_interface.stop();*/
        // For now, don't try to reset the actual gimbal yaw/pitch limit on the callback
      }
      if (param.get_name() == "pitch_limit" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        limit_pitch = param.as_int();
        RCLCPP_INFO(this->get_logger(), "What is Pitch?: (%d)\r\n", limit_pitch);

        /*Serial_Port serial_port(comPort.c_str(), baudRate);
        Gimbal_Interface gimbal_interface(&serial_port, 1, MAV_COMP_ID_ONBOARD_COMPUTER, mav_gimbal_proto, MAVLINK_COMM_0);

        serial_port.start();
        gimbal_interface.start();

        Gimbal_Interface::limit_angle_t limit_pitch_gSDK;

        //setting limit for pitch axis, determined by drone mounting HW
        limit_pitch_gSDK.angle_max = 1*limit_pitch;
        limit_pitch_gSDK.angle_min = -1*limit_pitch;
        while (gimbal_interface.set_limit_angle_pitch(limit_pitch_gSDK) != Gimbal_Protocol::SUCCESS)
        {
            // printf("Try to set yaw limit again!\r\n"); Replacing with ROS debugger print
            RCLCPP_INFO(this->get_logger(), "Try to set pitch limit again!\r\n");
            usleep(1000);
        }
        // printf("Set pitch max: %d -- Set pitch min: %d\n" , limit_pitch_gSDK.angle_max, limit_pitch_gSDK.angle_min); Replacing with ROS debugger print
        RCLCPP_INFO(this->get_logger(), "Findlol Set pitch max: %d -- Set pitch min: %d \r\n" , gimbal_interface.get_limit_angle_yaw().angle_max, gimbal_interface.get_limit_angle_yaw().angle_min);

        serial_port.stop();
        gimbal_interface.stop();*/
        // For now, don't try to reset the actual gimbal yaw/pitch limit on the callback
      }
      else
      {
        result.successful = false;
        result.reason = "Parameter not supported";
      }
    }
    return result;
  }

  void runGimbalThread()
  {

    Serial_Port serial_port(comPort.c_str(), baudRate);
    Gimbal_Interface gimbal_interface(&serial_port, 1, MAV_COMP_ID_ONBOARD_COMPUTER, mav_gimbal_proto, MAVLINK_COMM_0);

    serial_port.start();
    gimbal_interface.start();

    RCLCPP_INFO(this->get_logger(), "GIMBAL Thread Running");

    // Do not change code above this line.......................................

    //usleep(7000000); // Wait to make sure the gimbal finishes setting up

    bool initialized = initializeGimbalThread(gimbal_interface);

    if (initialized)
    {
      RCLCPP_INFO(this->get_logger(), "GIMBAL SUCCESSFULLY INITIALIZED!");
    }
    else
    {
      RCLCPP_ERROR(this->get_logger(), "GIMBAL INITIALIZATION FAILED!");
    }

    while (gimbalThreadRunning)
    {

      if (sdk.state == gremsy::STATE_IDLE)
      {
        if (gimbal_interface.present())
        {
          sdk.state = gremsy::STATE_CONNECTED;
        }
      }
      else if (sdk.state == gremsy::STATE_CONNECTED)
      {
        RCLCPP_INFO(this->get_logger(), MSG_GIMBAL_CONNECTED, comPort.c_str());
        sdk.state = gremsy::STATE_PROCESS;
      }
      else
      {
        if (msg_detected == true)
        {
          updateGimbalTarget(gimbal_interface);
        }
      }

      usleep(rate_hz); // Run at 1kHz, don't change this
    }

    serial_port.stop();
    gimbal_interface.stop();

    RCLCPP_INFO(this->get_logger(), "Gimbal Thread Exit");
  }

  bool setGimbalFollowMode(Gimbal_Interface &gimbal_interface)
  {
    bool success = false;

    Gimbal_Protocol::result_t res = Gimbal_Protocol::UNKNOWN;
    uint8_t timeout = 0;

    //RCLCPP_INFO(this->get_logger(),"This code ran!"); //Guess not
    res = gimbal_interface.set_gimbal_follow_mode_sync();

    while (res != Gimbal_Protocol::SUCCESS);
    {
      //RCLCPP_INFO(this->get_logger(),"This code ran!"); //Guess not
      
      if (timeout++ > _TIMEOUT)
      {
        RCLCPP_ERROR(this->get_logger(), "Could not set gimbal to FOLLOW MODE! Result code: %d\n", res);
      }
    }
    success = true;

    return success;
  }
  
  bool setGimbalHome(Gimbal_Interface &gimbal_interface)
  {
    bool success = false;

    Gimbal_Protocol::result_t res = Gimbal_Protocol::UNKNOWN;
    uint8_t timeout = 0;

    res = gimbal_interface.set_gimbal_return_home_sync();
    
    while (res != Gimbal_Protocol::SUCCESS && (fabsf(myattitude.pitch) > 0.5f || fabsf(myattitude.roll) > 0.5f || fabsf(myattitude.yaw) > 0.5f));
    {
      //res = gimbal_interface.set_gimbal_return_home_sync();
      //usleep(500000);

      if (++timeout >= _TIMEOUT_RETURN_HOME)
      {
        RCLCPP_ERROR(this->get_logger(), "Could not set gimbal to RETURN HOME! Result code: %d\n", res);
      }
      myattitude = gimbal_interface.get_gimbal_attitude();
    }
    success = true;
    
    return success;
  }

  bool setGimbalPanConfig(Gimbal_Interface &gimbal_interface)
  {
    bool success = false;

    uint8_t timeout = 0;
    Gimbal_Interface::gimbal_config_axis_t config = {pan_dir, pan_speed_control, pan_smooth_control, pan_smooth_follow, pan_window_follow}; // Pan

    gimbal_interface.set_gimbal_config_pan_axis(config);
    while(1)
    {
      usleep(500000);
      Gimbal_Interface::gimbal_config_axis_t new_config = gimbal_interface.get_gimbal_config_pan_axis();
      usleep(500000);

      if (new_config.dir == config.dir && new_config.smooth_control == config.smooth_control && new_config.smooth_follow == config.smooth_follow && new_config.speed_control == config.speed_control && new_config.window_follow == config.window_follow)
      {
        RCLCPP_INFO(this->get_logger(), "Set config for pan successfully!");
        success = true;
        break;
      }

      if (timeout++ > _TIMEOUT)
      {
        RCLCPP_ERROR(this->get_logger(), "Did not set up the pan axis due to timeout!");
        break;
      }
    }
    return success;
  }

  bool setGimbalRollConfig(Gimbal_Interface &gimbal_interface)
  {
    bool success = false; 

    uint8_t timeout = 0;
    Gimbal_Interface::gimbal_config_axis_t config = {roll_dir, roll_speed_control, roll_smooth_control, roll_smooth_follow, roll_window_follow}; // Roll
    gimbal_interface.set_gimbal_config_roll_axis(config);
    
    while (1)
    {
      usleep(500000);
      Gimbal_Interface::gimbal_config_axis_t new_config = gimbal_interface.get_gimbal_config_roll_axis();
      usleep(500000);

      if (new_config.dir == config.dir && new_config.smooth_control == config.smooth_control && new_config.smooth_follow == config.smooth_follow && new_config.speed_control == config.speed_control && new_config.window_follow == config.window_follow)
      {
        RCLCPP_INFO(this->get_logger(), "Set config for roll successfully!");
        success = true;
        break;
      }

      if (timeout++ > _TIMEOUT)
      {
        RCLCPP_ERROR(this->get_logger(), "Did not set up the roll axis due to timeout!");
        break;
      }
    }
    return success;
  }

  bool setGimbalTiltConfig(Gimbal_Interface &gimbal_interface)
  {
    bool success = false; 

    uint8_t timeout = 0;
    Gimbal_Interface::gimbal_config_axis_t config = {0}; // Instantiate null config for an axis

    config = {tilt_dir, tilt_speed_control, tilt_smooth_control, tilt_smooth_follow, tilt_window_follow}; // Tilt
    gimbal_interface.set_gimbal_config_tilt_axis(config);
    while (1)
    {
      usleep(500000);
      Gimbal_Interface::gimbal_config_axis_t new_config = gimbal_interface.get_gimbal_config_tilt_axis();
      usleep(500000);

      if (new_config.dir == config.dir && new_config.smooth_control == config.smooth_control && new_config.smooth_follow == config.smooth_follow && new_config.speed_control == config.speed_control && new_config.window_follow == config.window_follow)
      {
        RCLCPP_INFO(this->get_logger(), "Set config for tilt successfully!");
        success = true;
        break;
      }

      if (timeout++ > _TIMEOUT)
      {
        RCLCPP_ERROR(this->get_logger(), "Did not set up the tilt axis due to timeout!");
        break;
      }
    }
    return success;
  }

  bool setLimitAnglePitch(Gimbal_Interface &gimbal_interface)
  {
    bool success = false;

    Gimbal_Interface::limit_angle_t limit_pitch_gSDK;

    limit_pitch_gSDK.angle_max = 1 * limit_pitch;
    limit_pitch_gSDK.angle_min = -1 * limit_pitch;
    RCLCPP_INFO(this->get_logger(), "I'm trying to set pitch limit to %i",limit_pitch);
    
    while (gimbal_interface.set_limit_angle_pitch(limit_pitch_gSDK) != Gimbal_Protocol::SUCCESS)
    {
      RCLCPP_INFO(this->get_logger(), "Try to set pitch limit again!\r\n");
      usleep(rate_hz);
    }    
    RCLCPP_INFO(this->get_logger(), "Set pitch max: %d -- Set pitch min: %d \r\n", gimbal_interface.get_limit_angle_pitch().angle_max, gimbal_interface.get_limit_angle_pitch().angle_min);
    success = true;
  
    return success;
  }

  bool setLimitAngleYaw(Gimbal_Interface &gimbal_interface)
  {
    bool success = false;

    Gimbal_Interface::limit_angle_t limit_yaw_gSDK;

    // setting limit for yaw axis, determined by drone mounting HW
    limit_yaw_gSDK.angle_max = 1 * (limit_yaw + limit_yaw_bias); // Sets gSDK angle limit boundaries to ROS params
    limit_yaw_gSDK.angle_min = -1 * (limit_yaw + limit_yaw_bias);
    RCLCPP_INFO(this->get_logger(), "I'm trying to set yaw limit to %i",limit_yaw + limit_yaw_bias);
    
    while (gimbal_interface.set_limit_angle_yaw(limit_yaw_gSDK) != Gimbal_Protocol::SUCCESS)
    {
      RCLCPP_INFO(this->get_logger(), "Try to set yaw limit again!\r\n");
      usleep(rate_hz);
    }
    RCLCPP_INFO(this->get_logger(), "Set yaw max: %d -- Set yaw min: %d \r\n", gimbal_interface.get_limit_angle_yaw().angle_max, gimbal_interface.get_limit_angle_yaw().angle_min);
    success = true;

    return success;
  }

  void updateGimbalTarget(Gimbal_Interface &gimbal_interface)
  {
    myattitude = gimbal_interface.get_gimbal_attitude();

    float pitch_target; // variables updated with the targeted gimbal pitch, roll, 
    float roll_target;  // and yaw which depend on myattitude (current attitude) and current error from camera FOV center
    float yaw_target;

    RCLCPP_INFO(this->get_logger(), "Gimbal attitude Pitch - Roll - Yaw: (%.2f) - (%.2f) - (%.2f)\n", myattitude.pitch, myattitude.roll, myattitude.yaw);
    pitch_target = myattitude.pitch - curr_angle_y;
    yaw_target = myattitude.yaw + curr_angle_x;
    roll_target = 0; // Try to correct for any offset in roll

    msg_detected = false;

    gimbal_interface.set_gimbal_rotation_sync(pitch_target, roll_target, yaw_target);
  }

  void watchDog()
  {
  }

private:
  utility::Timer timer;
  status::state nodeState;
  status::commType nodeCommType;

  rclcpp::Publisher<custom_interfaces::msg::HeartBeat>::SharedPtr status;
  rclcpp::TimerBase::SharedPtr watchDogTimer;
  rclcpp::TimerBase::SharedPtr heartBeatTimer;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;

  rclcpp::Subscription<custom_interfaces::msg::CameraCoordsMessage>::SharedPtr cameraCoords;

  float epoch;
  int comm_type;
  int node_state;
  std::string datafield;

  std::thread gimbalThread;
  bool gimbalThreadRunning;
  int rate_hz;
  attitude<float> myattitude; // stores the current measured attitude from the gimbal any time it receives a target from the camera node

  std::string comPort;
  int baudRate;
  int limit_yaw;
  int limit_pitch;
  int limit_yaw_bias;

  int8_t tilt_dir = Gimbal_Interface::DIR_CW;
  uint8_t tilt_speed_control;
  uint8_t tilt_smooth_control;
  uint8_t tilt_smooth_follow;
  uint8_t tilt_window_follow;  
  
  int8_t roll_dir = Gimbal_Interface::DIR_CW;
  uint8_t roll_speed_control;
  uint8_t roll_smooth_control;
  uint8_t roll_smooth_follow;
  uint8_t roll_window_follow;

  int8_t pan_dir = Gimbal_Interface::DIR_CW;
  uint8_t pan_speed_control;
  uint8_t pan_smooth_control;
  uint8_t pan_smooth_follow;
  uint8_t pan_window_follow;

  sdk_process_t sdk;
  Serial_Port *serial_port_quit;
  Gimbal_Interface *gimbal_interface_quit;

  // static removed from these 3 data members to support ROS2 linking - not sure what effect this will have on the gsdk code base
  gimbal_mode_t gimbal_mode;
  bool is_boot_mode;
  Gimbal_Interface::MAVLINK_PROTO mav_gimbal_proto;

  double curr_angle_x; // Degrees yaw angle error read in from pfg_node
  double curr_angle_y; // Degrees pitch angle error read in from pfg_node
  int x_trim;
  int y_trim;

  bool msg_detected; // Tells gimbal thread when ROS has received and process a target
};

int main(int argc, char *argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<T3V3>());
  rclcpp::shutdown();
  return 0;
}
