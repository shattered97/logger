#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <libserial/SerialPort.h>
#include "timer/timer.h"

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
/////////////////////////////////
// NODE HPP FILE HERE
/////////////////////////////////
#include "../../custom_interfaces/custom_dt.h"
#include "custom_interfaces/msg/heart_beat.hpp"  

/*
 * CLASS NAME  
 * 
 * ROS2 PARAMETERS
 * 
 * 
 * NOTES
 * 
 */

using namespace std::chrono_literals;
using std::placeholders::_1;

class Test : public rclcpp::Node
{
  public:
  Test() : Node("test_node")
  {

    initialization();

    RCLCPP_INFO(this->get_logger(), "Hello World!");

    std::string statusMsgName = this->get_name();
    status = this->create_publisher<custom_interfaces::msg::HeartBeat>(statusMsgName, 10);

    heartBeatTimer = this->create_wall_timer(1000ms, std::bind(&Test::heartBeat, this));
    watchDogTimer = this->create_wall_timer(100ms, std::bind(&Test::watchDog, this));


    parameter_callback_handle = this->add_on_set_parameters_callback(std::bind(&Test::parameter_change_callback, this, _1));
  }

  ~Test()
  {

  }

  private:

  void declareParams()
  {
    nodeState = status::state::unknown; 
    nodeCommType = status::commType::pcie;
    datafield = "empty";

    this->declare_parameter("test", "5");
  }

  void heartBeat()
  {
    publishStatus(datafield);
  }

  void initialization()
  {
    declareParams();
    initializeFlags();
    nodeState = status::state::initializating;
  }

  void initializeFlags()
  {

  }

  void publishStatus(std::string datafield)
  {
    auto msg = custom_interfaces::msg::HeartBeat();
    msg.epoch = timer.timeSinceEpoch_us();
    msg.node_state = (int)nodeState;
    msg.comm_type = (int)nodeCommType;
    status->publish(msg);
    RCLCPP_INFO(this->get_logger(), datafield.c_str());
    RCLCPP_INFO(this->get_logger(), " %d", (int)nodeState);
  }

  rcl_interfaces::msg::SetParametersResult parameter_change_callback(const std::vector<rclcpp::Parameter> &params){
    auto result = rcl_interfaces::msg::SetParametersResult();
    result.successful = true;

    for(const auto &param : params)
    {
      RCLCPP_INFO(this->get_logger(), MSG_PARAM_UPDATE, param.get_name().c_str(), param.as_string().c_str());

      if(param.get_name() == "test" && param.get_type() ==  rclcpp::ParameterType::PARAMETER_STRING)
      {
        nodeState = status::state::reconnecting;
      }
      else
      {
        result.successful = false;
        result.reason = "Parameter not supported";
      }
    }
    return result;
  }

  void watchDog()
  {

  }

  private:

  utility::Timer timer;
  status::state nodeState;
  status::commType nodeCommType;

  rclcpp::Publisher<custom_interfaces::msg::HeartBeat>::SharedPtr status;
  rclcpp::TimerBase::SharedPtr watchDogTimer;
  rclcpp::TimerBase::SharedPtr heartBeatTimer;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;

  float epoch;
  int comm_type;
  int node_state;
  std::string datafield;

};

int main(int argc, char * argv[]){
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Test>());
  rclcpp::shutdown();
  return 0;
}