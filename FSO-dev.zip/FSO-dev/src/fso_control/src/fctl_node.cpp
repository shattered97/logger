#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include "timer/timer.h"

extern "C"
{
#include "fpga_drivers/reg.h"
#include "fpga_drivers/spi.h"
#include "fpga_drivers/adc.h"
}

#include "rclcpp/rclcpp.hpp"
#include <rclcpp/logging.hpp>

#include "std_msgs/msg/string.hpp"
/////////////////////////////////
// NODE HPP FILE HERE
/////////////////////////////////
#include "../../custom_interfaces/custom_dt.h"
#include "custom_interfaces/msg/heart_beat.hpp"  

/*
 * CLASS NAME  
 * 
 * ROS2 PARAMETERS
 * 
 * 
 * NOTES
 * 
 */

//use XOR to toggle bit
//use AND to determine if bit set

//static const uint32_t BIT00_MASK            = 0x00000001;
static const uint32_t EDFA_0_ENBL           = 0x00000002;
static const uint32_t EDFA_1_ENBL           = 0x00000004;
static const uint32_t ADC_RESET_N           = 0x00000008;
static const uint32_t VBIAS_DAC_RESET_N     = 0x00000010;
static const uint32_t LED_DRVR_0_ON         = 0x00000020;
static const uint32_t LED_DRVR_1_ON         = 0x00000040;
static const uint32_t APD_1_BW_SEL0         = 0x00000080;
static const uint32_t APD_1_BW_SEL1         = 0x00000100;
static const uint32_t APD_2_BW_SEL0         = 0x00000200;
static const uint32_t APD_2_BW_SEL1         = 0x00000400;
static const uint32_t APD_1_RSSI_SEL        = 0x00000800;
static const uint32_t APD_2_RSSI_SEL        = 0x00001000;
static const uint32_t MIRROR_0_VCC_ENBL_N   = 0X00002000;
static const uint32_t MIRROR_1_VCC_ENBL_N   = 0x00004000;
static const uint32_t MIRROR_0_DRIVER_RST_N = 0x00008000;
static const uint32_t MIRROR_1_DRIVER_RST_N = 0x00010000;
static const uint32_t TEC_0_ENBL            = 0x00020000;
static const uint32_t TEC_1_ENBL            = 0x00040000;
//static const uint32_t BIT19_MASK            = 0x00080000;
//static const uint32_t BIT20_MASK            = 0x00100000;
static const uint32_t LED_DRVR_DAC_RST_N    = 0x00200000;
static const uint32_t SFP_1_TDIS            = 0x00400000;
static const uint32_t SFP_2_TDIS            = 0x00800000;
static const uint32_t SFP_1_RATE_SEL0       = 0x01000000;
static const uint32_t SFP_1_RATE_SEL1       = 0x02000000;
static const uint32_t SFP_2_RATE_SEL0       = 0x04000000;
static const uint32_t SFP_2_RATE_SEL1       = 0x08000000;
static const uint32_t ETH_FLOW_CTL_EN       = 0x10000000;
static const uint32_t APD_1_FILT_BYPASS     = 0x20000000;
static const uint32_t APD_2_FILT_BYPASS     = 0x40000000;
//static const uint32_t BIT31_MASK            = 0x80000000;

static const uint32_t PCIE_WAKE_N            = 0x00000001;
static const uint32_t APD_1_LOS              = 0x00000002;
static const uint32_t APD_2_LOS              = 0x00000004;
static const uint32_t MIRROR_0_SPI_DATA_NRDY = 0x00000008;
static const uint32_t MIRROR_1_SPI_DATA_NRDY = 0x00000010;
static const uint32_t EDFA_0_STATUS          = 0x00000020;
static const uint32_t EDFA_1_STATUS          = 0x00000040;
static const uint32_t EDFA_0_ALARM           = 0x00000080;
static const uint32_t EDFA_1_ALARM           = 0x00000100;
static const uint32_t TEC_0_STATUS_N         = 0x00000200;
static const uint32_t TEC_1_STATUS_N         = 0x00000400;
//static const uint32_t BIT11_MASK             = 0x00000800;
//static const uint32_t BIT12_MASK             = 0x00001000;
static const uint32_t SFP_1_TFAULT           = 0X00002000;
static const uint32_t SFP_2_TFAULT           = 0x00004000;
static const uint32_t SFP_1_MOD_DEF0         = 0x00008000;
static const uint32_t SFP_1_MOD_DEF1         = 0x00010000;
static const uint32_t SFP_1_MOD_DEF2         = 0x00020000;
static const uint32_t SFP_2_MOD_DEF0         = 0x00040000;
static const uint32_t SFP_2_MOD_DEF1         = 0x00080000;
static const uint32_t SFP_2_MOD_DEF2         = 0x00100000;
static const uint32_t SFP_1_LOS              = 0x00200000;
static const uint32_t SFP_2_LOS              = 0x00400000;
static const uint32_t DDR4_CAL_CMPLT         = 0x00800000;
static const uint32_t PCIE_LINK_UP           = 0x01000000;
static const uint32_t ETH_LINK_UP            = 0x02000000;
//static const uint32_t BIT26_MASK             = 0x04000000;
//static const uint32_t BIT27_MASK             = 0x08000000;
//static const uint32_t BIT28_MASK             = 0x10000000;
//static const uint32_t BIT29_MASK             = 0x20000000;
//static const uint32_t BIT30_MASK             = 0x40000000;
//static const uint32_t BIT31_MASK             = 0x80000000;

static const uint8_t APD1_RSSI_CH = 0;
static const uint8_t APD2_RSSI_CH = 3;
static const uint8_t APD1_BIAS_CH = 4;
static const uint8_t APD2_BIAS_CH = 7;
        
using namespace std::chrono_literals;
using std::placeholders::_1;

class FSOCTL : public rclcpp::Node
{
  public:
  FSOCTL() : Node("fctl_node")
  {
    initialization();

    std::string statusMsgName = this->get_name();
    status = this->create_publisher<custom_interfaces::msg::HeartBeat>(statusMsgName, 10);

    heartBeatTimer = this->create_wall_timer(1000ms, std::bind(&FSOCTL::heartBeat, this));
    watchDogTimer = this->create_wall_timer(100ms, std::bind(&FSOCTL::watchDog, this));

    parameter_callback_handle = this->add_on_set_parameters_callback(std::bind(&FSOCTL::parameter_change_callback, this, _1));

  }

  ~FSOCTL()
  {

  }

  private:

  void declareParams()
  {
    nodeState = status::state::unknown; 
    nodeCommType = status::commType::pcie;
    datafield = "empty";

    this->declare_parameter("GPIO_ADDR", 0x01000C);
    this->declare_parameter("STATUS_ADDR", 0x010024);
    this->declare_parameter("DAC1_SPI_ADDR", 0x140000);
    this->declare_parameter("DAC2_SPI_ADDR", 0x150000);
    this->declare_parameter("ADC_ADDR", 0x170000);
    this->declare_parameter("FSO_RATE_SELECT_ADDR", 0x1A0010);  //Register for Rate Select, 1250Mbps = 0, Adjustable = 1
    this->declare_parameter("FSO_VRATE_SELECT_ADDR", 0x1A0014);  //Adjustable Rate 0x00 = 156.25, 0xFF 1.26Mbps

    this->declare_parameter("LTC2641_16_StepSize", 0.000744629); //0.000045776
    this->declare_parameter("LTC2641_DAC1_VBIAS", 0.00);
    this->declare_parameter("APD1_FILTER_BYPASS_VALUE", 0x01);  //default is high, Selectable bandwidth
    this->declare_parameter("APD2_FILTER_BYPASS_VALUE", 0x01);  //default is high, Selectable bandwidth
    this->declare_parameter("APD1_BANDWIDTH_SELECT_BIT7", 0x00);  //Binary value, 100mHz
    this->declare_parameter("APD1_BANDWIDTH_SELECT_BIT8", 0x01);  //Binary value, 100mHz
    this->declare_parameter("APD1_RSSI_SEL_BIT", 0x00);  //0 = Normal scaling;

    this->declare_parameter("FSO_RATE_ON/OFF", 0x00);
    this->declare_parameter("FSO_RATE_SELECT_16BIT", 0x0000);
    this->declare_parameter("TAKE_RSSI_VBIAS_READING", false);

    GPIO_ADDR = this->get_parameter("GPIO_ADDR").as_int();
    STATUS_ADDR = this->get_parameter("STATUS_ADDR").as_int();
    DAC1_SPI_ADDR = this->get_parameter("DAC1_SPI_ADDR").as_int();
    DAC2_SPI_ADDR = this->get_parameter("DAC2_SPI_ADDR").as_int(); 
    FSO_RATE_SELECT_ADDR = this->get_parameter("FSO_RATE_SELECT_ADDR").as_int();
    FSO_VRATE_SELECT_ADDR = this->get_parameter("FSO_VRATE_SELECT_ADDR").as_int();
    ADC_ADDR = this->get_parameter("ADC_ADDR").as_int();

    APD1_FILTER_BYPASS = this->get_parameter("APD1_FILTER_BYPASS_VALUE").as_int();
    APD2_FILTER_BYPASS = this->get_parameter("APD2_FILTER_BYPASS_VALUE").as_int();
    APD1_BW_SELECT_BIT7 = this->get_parameter("APD1_BANDWIDTH_SELECT_BIT7").as_int();
    APD1_BW_SELECT_BIT8 = this->get_parameter("APD1_BANDWIDTH_SELECT_BIT8").as_int();
    APD1_RSSI_SEL_BIT11 = this->get_parameter("APD1_RSSI_SEL_BIT").as_int();

    RATE_SELECT_VALUE = this->get_parameter("FSO_RATE_ON/OFF").as_int();
    VRATE_SELECT_VALUE = this->get_parameter("FSO_RATE_SELECT_16BIT").as_int();
    TAKE_RSSI_VBIAS_READING = this->get_parameter("TAKE_RSSI_VBIAS_READING").as_bool();

    LTC2641_stepSize = this->get_parameter("LTC2641_16_StepSize").as_double();
    LTC2641_DAC1_Vbias = this->get_parameter("LTC2641_DAC1_VBIAS").as_double();
  }

  void heartBeat()
  {
    publishStatus(datafield);
  }

  void healthCheck()
  {
    int status = reg_rd(STATUS_ADDR);
    std::cout << std::hex << status << std::endl;

    int bit0 = status & PCIE_WAKE_N;
    int bit1 = status & APD_1_LOS;
    int bit2 = status & APD_2_LOS;
    int bit5 = status & EDFA_0_STATUS;
    int bit6 = status & EDFA_1_STATUS;
    int bit7 = status & EDFA_0_ALARM;
    int bit8 = status & EDFA_1_ALARM;
    int bit9 = status & TEC_0_STATUS_N;
    
    int bit10 = status & TEC_1_STATUS_N;
    int bit13 = status & SFP_1_TFAULT;
    int bit14 = status & SFP_2_TFAULT;
    int bit21 = status & SFP_1_LOS;
    int bit22 = status & SFP_2_LOS;
    int bit23 = status & DDR4_CAL_CMPLT;
    int bit24 = status & PCIE_LINK_UP;
    int bit25 = status & ETH_LINK_UP;

    RCLCPP_INFO(this->get_logger(), STATUS_EDFA_PUMP, STATUS_ADDR, bit5, 0);
    RCLCPP_INFO(this->get_logger(), STATUS_EDFA_PUMP, STATUS_ADDR, bit6, 1);

    if(bit0 == 0)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_PCIE_WAKE_N, STATUS_ADDR, bit0);
    }

    if(bit1 == APD_1_LOS)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_APD_LOS, STATUS_ADDR, bit1, 1);   
    }

    if(bit2 == APD_2_LOS)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_APD_LOS, STATUS_ADDR, bit2, 2); 
    }

    if(bit7 == EDFA_0_ALARM)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_EDFA_ALARM, STATUS_ADDR, bit7, 0);
    }

    if(bit8 == EDFA_1_ALARM)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_EDFA_ALARM, STATUS_ADDR, bit8, 1);
    }

    if(bit9 == 0)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_TEC, STATUS_ADDR, bit9, 0);
    }

    if(bit10 == 0)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_TEC, STATUS_ADDR, bit10, 1);        
    }

    if(bit13 == SFP_1_TFAULT)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_SFP_TFAULT, STATUS_ADDR, bit13, 1);
    }

    if(bit14 == SFP_2_TFAULT)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_SFP_TFAULT, STATUS_ADDR, bit14, 2);
    }

    if(bit21 == SFP_1_LOS)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_SFP_LOS, STATUS_ADDR, bit21, 1);
    }

    if(bit22 == SFP_2_LOS)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_SFP_LOS, STATUS_ADDR, bit22, 2);
    }

    if(bit23 == 0)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_DDR4, STATUS_ADDR, bit23);
    }

    if(bit24 == 0)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_PCIE_LINK, STATUS_ADDR, bit24);
    }

    if(bit25 == 0)
    {
        RCLCPP_ERROR(this->get_logger(), ERROR_ETH_LINK, STATUS_ADDR, bit25);
    }
  }

  void initialization()
  {  
    declareParams();
    initializeFlags();
    nodeState = status::state::initializating;

    spi_setup(DAC1_SPI_ADDR, 0, 0, 0);  //Initialize SPI
    adc_setup(ADC_ADDR);                //ADC setup

    //Default DAC to 10v when the node starts
                         //LSB, MSB
    uint8_t tx_buf[2] = {0x00 , 0X35};  //Default to 10V
    uint8_t rx_buf[2] = {0x00};
    
    spi_txrx(DAC1_SPI_ADDR, &tx_buf[1], &rx_buf[0], 1);  //MSB First
    usleep(25);
    spi_txrx(DAC1_SPI_ADDR, &tx_buf[0], &tx_buf[0], 1);  //LSB Second
    usleep(25);

    healthCheck();
  }

  void initializeFlags()
  {

  }

  void publishStatus(std::string datafield)
  {
    auto msg = custom_interfaces::msg::HeartBeat();
    msg.epoch = timer.timeSinceEpoch_us();
    msg.node_state = (int)nodeState;
    msg.comm_type = (int)nodeCommType;
    status->publish(msg);
  }

  rcl_interfaces::msg::SetParametersResult parameter_change_callback(const std::vector<rclcpp::Parameter> &params)
  {
    auto result = rcl_interfaces::msg::SetParametersResult();
    result.successful = true;

    for(const auto &param : params)
    {
      if(param.get_name() == "LTC2641_DAC1_VBIAS" && param.get_type() ==  rclcpp::ParameterType::PARAMETER_DOUBLE)
      {
        if(param.as_double() >= 0.0 || param.as_double() <= 57.0)
        {
          setLM2641_V(param.as_double());
          result.successful = true;
        }
        else
        {
          result.successful = false;
        }
      }
      else if(param.get_name() == "APD1_FILTER_BYPASS_VALUE" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        uint32_t regResult = reg_rd(GPIO_ADDR);
        std::cout << "Prior to Change " << regResult << std::endl;

        uint32_t test = regResult & APD_1_FILT_BYPASS;

        //THis ugly but needed it to work fast
        if ((test == 0) && (param.as_int() == 1)) 
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_1_FILT_BYPASS;
          reg_wr(GPIO_ADDR, regResult);
        }
        else if ((test == APD_1_FILT_BYPASS) && (param.as_int() == 0)) 
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_1_FILT_BYPASS;
          reg_wr(GPIO_ADDR, regResult);
        }

        regResult = reg_rd(GPIO_ADDR);

        std::cout << std::hex << "After change" << regResult << std::endl;
      }

      else if(param.get_name() == "APD2_FILTER_BYPASS_VALUE" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        uint32_t regResult = reg_rd(GPIO_ADDR);
        std::cout << "Prior to Change " << regResult << std::endl;

        uint32_t test = regResult & APD_2_FILT_BYPASS;

        //THis ugly but needed it to work fast
        if ((test == 0) && (param.as_int() == 1)) 
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_2_FILT_BYPASS;
          reg_wr(GPIO_ADDR, regResult);
        }
        else if ((test == APD_2_FILT_BYPASS) && (param.as_int() == 0)) 
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_2_FILT_BYPASS;
          reg_wr(GPIO_ADDR, regResult);
        }

        regResult = reg_rd(GPIO_ADDR);

        std::cout << std::hex << "After change" << regResult << std::endl;
      }

      else if(param.get_name() == "APD1_BANDWIDTH_SELECT_BIT7" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        uint32_t regResult = reg_rd(GPIO_ADDR);
        std::cout << "Prior to Change " << regResult << std::endl;

        uint32_t test = regResult & APD_1_BW_SEL0;

        //THis ugly but needed it to work fast
        if ((test == 0) && (param.as_int() == 1)) 
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_1_BW_SEL0;
          reg_wr(GPIO_ADDR, regResult);
        }
        else if ((test == APD_1_BW_SEL0) && (param.as_int() == 0)) 
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_1_BW_SEL0;
          reg_wr(GPIO_ADDR, regResult);
        }

        regResult = reg_rd(GPIO_ADDR);
        std::cout << std::hex << "After change" << regResult << std::endl;

      }

      else if(param.get_name() == "APD1_BANDWIDTH_SELECT_BIT8" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        uint32_t regResult = reg_rd(GPIO_ADDR);
        std::cout << "Prior to Change " << regResult << std::endl;

        uint32_t test = regResult & APD_1_BW_SEL1;

        //THis ugly but needed it to work fast
        if ((test == 0) && (param.as_int() == 1)) 
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_1_BW_SEL1;
          reg_wr(GPIO_ADDR, regResult);
        }
        else if ((test == APD_1_BW_SEL1) && (param.as_int() == 0)) 
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_1_BW_SEL1;
          reg_wr(GPIO_ADDR, regResult);
        }

        regResult = reg_rd(GPIO_ADDR);
        std::cout << std::hex << "After change" << regResult << std::endl;
      }

      else if (param.get_name() == "FSO_RATE_ON/OFF" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        RATE_SELECT_VALUE = param.as_int();
        uint32_t regValue = reg_rd(FSO_RATE_SELECT_ADDR);
        std::cout << "BEFORE:  FSO Rate Select on/off: " << regValue << std::endl;
        reg_wr(FSO_RATE_SELECT_ADDR, RATE_SELECT_VALUE);
        regValue = reg_rd(FSO_RATE_SELECT_ADDR);
        std::cout << "After:  FSO Rate Select on/off: " << regValue << std::endl;
      }

      else if(param.get_name() == "FSO_RATE_SELECT_16BIT" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        VRATE_SELECT_VALUE = param.as_int();
        uint32_t regValue = reg_rd(FSO_VRATE_SELECT_ADDR);
        std::cout << "BEFORE: FSO VRate Select bits: " << regValue << std::endl;
        reg_wr(FSO_VRATE_SELECT_ADDR, VRATE_SELECT_VALUE);
        regValue = reg_rd(FSO_VRATE_SELECT_ADDR);
        std::cout << "AFTER: FSO VRate Select bits: " << regValue << std::endl;
      }

      else if(param.get_name() == "APD1_RSSI_SEL_BIT" && rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        APD1_RSSI_SEL_BIT11 = param.as_int();
        uint32_t regResult = reg_rd(FSO_VRATE_SELECT_ADDR);
        std::cout << "BEFORE: FSO VRate Select bits: " << regResult << std::endl;
        uint32_t test = regResult & APD_1_BW_SEL1;

        if(test == 0 && APD1_RSSI_SEL_BIT11 == 1)
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_1_RSSI_SEL;
          reg_wr(GPIO_ADDR, regResult);
        }
        else if(test == 1 && APD1_RSSI_SEL_BIT11 == 0)
        {
          std::cout << "Flipping Bit" << std::endl;
          regResult = regResult ^ APD_1_RSSI_SEL;
          reg_wr(GPIO_ADDR, regResult);
        }
      }

      else if(param.get_name() == "TAKE_RSSI_VBIAS_READING" && rclcpp::ParameterType::PARAMETER_BOOL)
      {
        readADC();
      }
    }
    return result;
  }

  bool readADC()
  {
    double apd1_rssi = adc_convert(ADC_ADDR, APD1_RSSI_CH);
    RCLCPP_INFO(this->get_logger(), "APD1 RSSI:  %f", apd1_rssi);

    double apd1_bais = adc_convert(ADC_ADDR, APD1_BIAS_CH);
    RCLCPP_INFO(this->get_logger(), "APD1 BIAS: %f", apd1_bais);
  }
  
  bool setLM2641_V(double desiredVoltage)
  {

    RCLCPP_INFO(this->get_logger(), "VBias Voltage set to:  %f", desiredVoltage);

    double numSteps = (desiredVoltage / 19.0) / LTC2641_stepSize;

    uint16_t inputRegValue = static_cast<uint16_t>(numSteps) - 1; //(65536 steps but count starts at 0) 

                        //LSB, MSB
    uint8_t tx_buf[2];
    uint8_t rx_buf[2];

    tx_buf[0] = 0x00;
    tx_buf[1] = 0x00;

    convertFrom16_bit(inputRegValue, tx_buf[1], tx_buf[0]);
    
    spi_txrx(DAC1_SPI_ADDR, &tx_buf[1], &rx_buf[0], 1);  //MSB First
    usleep(25);
    spi_txrx(DAC1_SPI_ADDR, &tx_buf[0], &tx_buf[0], 1);  //LSB Second
    usleep(25);
    spi_txrx(DAC2_SPI_ADDR, &tx_buf[1], &rx_buf[0], 1);  //MSB First
    usleep(25);
    spi_txrx(DAC2_SPI_ADDR, &tx_buf[0], &tx_buf[0], 1);  //LSB Second
    usleep(25);

    return true;
  }

  void watchDog()
  {

  }

  private:

  utility::Timer timer;
  status::state nodeState;
  status::commType nodeCommType;

  rclcpp::Publisher<custom_interfaces::msg::HeartBeat>::SharedPtr status;
  rclcpp::TimerBase::SharedPtr watchDogTimer;
  rclcpp::TimerBase::SharedPtr heartBeatTimer;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;

  float epoch;
  int comm_type;
  int node_state;
  std::string datafield;

  int GPIO_ADDR; 
  int STATUS_ADDR;
  int DAC1_SPI_ADDR;
  int DAC2_SPI_ADDR;
  int FSO_RATE_SELECT_ADDR;
  int FSO_VRATE_SELECT_ADDR;
  int ADC_ADDR;

  int APD1_FILTER_BYPASS;
  int APD2_FILTER_BYPASS;
  int APD1_BW_SELECT_BIT7;
  int APD1_BW_SELECT_BIT8;
  int APD1_RSSI_SEL_BIT11;

  bool TAKE_RSSI_VBIAS_READING;

  uint32_t RATE_SELECT_VALUE;  //see register address 0x1A0010 
  uint32_t VRATE_SELECT_VALUE; //see register address 0x1A0014

  double LTC2641_stepSize;
  int LTC2641_DAC1_Vbias;

};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<FSOCTL>());
  rclcpp::shutdown();
  return 0;
}