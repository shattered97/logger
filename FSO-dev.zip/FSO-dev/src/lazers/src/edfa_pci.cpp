#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include "timer/timer.h"

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
/////////////////////////////////
// NODE HPP FILE HERE
/////////////////////////////////
#include "../../custom_interfaces/custom_dt.h"
#include "custom_interfaces/msg/heart_beat.hpp"
#include "std_srvs/srv/empty.hpp"
extern "C"
{
#include "fpga_drivers/uart.h"
}

using namespace std::chrono_literals;
using std::placeholders::_1;

class EDFA_PCI : public rclcpp::Node
{
public:
  EDFA_PCI() : Node("edfa_pci")
  {
    sleep(1);
    edfaOn();
    edfaSendStatus();
    get_resp();

    // initialization();

    // std::string statusMsgName = this->get_name();
    // status = this->create_publisher<custom_interfaces::msg::HeartBeat>(statusMsgName, 10);

    // heartBeatTimer = this->create_wall_timer(1000ms, std::bind(&EDFA_PCI::heartBeat, this));
    // watchDogTimer = this->create_wall_timer(100ms, std::bind(&EDFA_PCI::watchDog, this));

    // parameter_callback_handle = this->add_on_set_parameters_callback(std::bind(&EDFA_PCI::parameter_change_callback, this, _1));
  }

  ~EDFA_PCI()
  {
    edfaOff();
  }

private:
  void declareParams()
  {
    nodeCommType = status::commType::pcie;
    datafield = "empty";

    this->declare_parameter("aopc_value", 25.0);
    this->declare_parameter("saopc_value", 25.0);
    this->declare_parameter("lazer_on", false);
    this->declare_parameter("gaopc", false);
    this->declare_parameter("get_status", false);
    this->declare_parameter("buffer_length", 256);

    this->declare_parameter("base_address", 0x040000); // UART0 (default): 0x040000   UART1: 0x050000

    aopc_value = this->get_parameter("aopc_value").as_double();
    saopc_value = this->get_parameter("saopc_value").as_double();
    UART_BASEADDR = this->get_parameter("base_address").as_int();
    buffer_length = this->get_parameter("buffer_length").as_int();
  }

  bool get_resp()
  {
    bool success = false;
    char resp[buffer_length] = {0};
    int res = 0;

    RCLCPP_INFO(this->get_logger(), "GRABBING RESPONSE");
    res = uart_rx(UART_BASEADDR, resp, buffer_length);

    if (res)
    {
      resp[res] = '\0';
      success = true;
      std::string response_str(resp);
      RCLCPP_INFO(this->get_logger(), "GOT RESPONSE: %s", response_str.c_str());
    }
    else
    {
      RCLCPP_ERROR(this->get_logger(), "FAILED TO GET RESPONSE");
    }

    return success;
  }

  void heartBeat()
  {
    publishStatus(datafield);
  }

  bool initialization()
  {
    bool success = false;
    nodeState = status::state::initializating;

    RCLCPP_INFO(this->get_logger(), "INTIALIZATION PROCESS STARTED");
    declareParams();
    initializeFlags();

    success = initalizeEdfa();

    if (success)
    {
      nodeState = status::state::running;
      RCLCPP_INFO(this->get_logger(), "INTIALIZATION PROCESS SUCCESS!");
    }
    else
    {
      nodeState = status::state::error;
      RCLCPP_ERROR(this->get_logger(), "INTIALIZATION PROCESS FAILED!");
    }

    timer.reset();
    timer.start();
    return success;
  }

  bool initalizeEdfa()
  {
    bool success = false;

    std::string cmd;

    sleep(1);
    sendCmd(cmd_reset);
    sendCmd(cmd_gmode);
    cmd = cmd_saopc + std::to_string(saopc_value);
    sendCmd(cmd);

    // ensure lazer is set to default setting on initialization
    cmd = cmd_aopc + std::to_string(saopc_value);
    sendCmd(cmd);

    return success;
  }

  void initializeFlags()
  {
    // flags were part of other edfa node
    lazer_on = this->get_parameter("lazer_on").as_bool();
    gaopc = this->get_parameter("gaopc").as_bool();
    getStatus = this->get_parameter("get_status").as_bool();
  }

  void publishStatus(std::string datafield)
  {
    auto msg = custom_interfaces::msg::HeartBeat();
    msg.epoch = timer.timeSinceEpoch_us();
    msg.node_state = (int)nodeState;
    msg.comm_type = (int)nodeCommType;
    status->publish(msg);
    // RCLCPP_INFO(this->get_logger(), datafield.c_str());
    RCLCPP_INFO(this->get_logger(), "Node State: %d", (int)nodeState);
  }

  rcl_interfaces::msg::SetParametersResult parameter_change_callback(const std::vector<rclcpp::Parameter> &params)
  {
    auto result = rcl_interfaces::msg::SetParametersResult();
    result.successful = true;

    for (const auto &param : params)
    {
      RCLCPP_INFO(this->get_logger(), MSG_PARAM_UPDATE, param.get_name().c_str(), param.as_string().c_str());

      if (param.get_name() == "aopc_value" && param.as_double())
      {
        aopc_value = param.as_double();
        std::string cmd = cmd_aopc + std::to_string(aopc_value);
        sendCmd(cmd);
      }
      else if (param.get_name() == "base_address" && param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
      }
      else if (param.get_name() == "comm_port" && param.get_type() == rclcpp::ParameterType::PARAMETER_DOUBLE)
      {
      }
      else if (param.get_name() == "gaopc" && param.get_type() == rclcpp::ParameterType::PARAMETER_BOOL)
      {
      }
      else if (param.get_name() == "get_status" && param.get_type() == rclcpp::ParameterType::PARAMETER_BOOL)
      {
      }
      else if (param.get_name() == "lazer_on" && param.get_type() == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        lazer_on = param.as_bool();
        if (lazer_on)
        {
          sendCmd(cmd_edfa_on);
        }
        else
        {
          sendCmd(cmd_edfa_off);
        }
      }
      else if (param.get_name() == "saopc_value" && param.get_type() == rclcpp::ParameterType::PARAMETER_DOUBLE)
      {
        saopc_value = param.as_double();
        std::string cmd = cmd_saopc + std::to_string(saopc_value);
      }
      else
      {
        result.successful = false;
        result.reason = "Parameter not supported";
      }
    }
    return result;
  }

  bool sendCmd(std::string cmd)
  {
    bool success = false;
    int num_byte_sent = 0;

    // Send the command
    num_byte_sent = uart_tx(UART_BASEADDR, cmd.c_str(), strlen(cmd.c_str()));

    if (num_byte_sent != 0)
    {
      RCLCPP_INFO(this->get_logger(), EDFA_CMD_SUCCESS, cmd.c_str());
      success = true;
    }
    else
    {
      RCLCPP_ERROR(this->get_logger(), EDFA_CMD_ERROR, cmd.c_str());
      success = false;
    }
    return success;
  }

  void watchDog()
  {
    sendCmd(cmd_fline);

    if (nodeState == status::state::reconnecting)
    {
      RCLCPP_INFO(this->get_logger(), MSG_WD_FIRED, "reconnect");
    }
  }

  // EDFA Commands
  void srvEdfaOffCallback(std::shared_ptr<std_srvs::srv::Empty::Request>, std::shared_ptr<std_srvs::srv::Empty::Response>)
  {
    sendCmd(cmd_edfa_off);
  }

  void srvEdfaOnCallback(std::shared_ptr<std_srvs::srv::Empty::Request>, std::shared_ptr<std_srvs::srv::Empty::Response>)
  {
    sendCmd(cmd_edfa_on);
  }

  void srvStatusCallback(std::shared_ptr<std_srvs::srv::Empty::Request>, std::shared_ptr<std_srvs::srv::Empty::Response>)
  {
    sendCmd(cmd_fline);
  }

  void srvResetCallback(std::shared_ptr<std_srvs::srv::Empty::Request>, std::shared_ptr<std_srvs::srv::Empty::Response>)
  {
    sendCmd(cmd_reset);
  }

  void srvGetPwr(std::shared_ptr<std_srvs::srv::Empty::Request>, std::shared_ptr<std_srvs::srv::Empty::Response>)
  {
    sendCmd(cmd_gaopc);
  }

  void srvGetTmp(std::shared_ptr<std_srvs::srv::Empty::Request>, std::shared_ptr<std_srvs::srv::Empty::Response>)
  {
    sendCmd(cmd_gcta);
    sendCmd(cmd_gbtemp);
  }

  bool edfaOff()
  {
    return sendCmd(cmd_edfa_off);
  }

  bool edfaOn()
  {
    return sendCmd(cmd_edfa_on);
  }

  bool edfaSendStatus()
  {
    return sendCmd(cmd_fline);
  }

  bool edfaReset()
  {
    return sendCmd(cmd_reset);
  }

private:
  utility::Timer timer;
  status::state nodeState;
  status::commType nodeCommType;

  rclcpp::Publisher<custom_interfaces::msg::HeartBeat>::SharedPtr status;
  rclcpp::TimerBase::SharedPtr watchDogTimer;
  rclcpp::TimerBase::SharedPtr heartBeatTimer;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;

  rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvReset_callback_handle;
  rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvStatus_callback_handle;
  rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvEdfaOn_callback_handle;
  rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvEdfaOff_callback_handle;
  rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvEdfaGetPwr_callback_handle;
  rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvGetTemp_callback_handle;

  float epoch;
  int comm_type;
  int node_state;
  std::string datafield;
  uint32_t UART_BASEADDR;

  bool lazer_on;
  bool gaopc;
  bool getStatus;
  bool reset;
  int buffer_length;

  double aopc_value;
  double saopc_value;
};

int main(int argc, char *argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<EDFA_PCI>());
  rclcpp::shutdown();
  return 0;
}