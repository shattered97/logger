/*------------------------------------------------------------------------------
--
-- (C)Copyright 2025 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : cam
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2025-02-03
--------------------------------------------------------------------------------
-- Description: Driver MRE-3 optical mirror
------------------------------------------------------------------------------*/

#include <unistd.h>
#include "fpga_drivers/mirror.h"
#include "fpga_drivers/spi.h"

#define MIRROR_CMD_LENGTH 14
#define READ_ERROR 0x7cf0bdc2

void mirror_setup(uint32_t baseaddr)
{
  // Setup spi peripheral with CPOL=0, CPHA=1, MSBit First
  spi_setup(baseaddr, 0, 1, 0);

  // Disable loopback
  spi_loopback(baseaddr, 0);

	return;
}


// Write mirror spi registers
int mirror_wr_regs(uint32_t baseaddr, mirror_wr_tx_t * cmd, mirror_wr_rx_t * rsp)
{
  uint8_t tx_buf[MIRROR_CMD_LENGTH] = {0};
  uint8_t rx_buf[MIRROR_CMD_LENGTH] = {0};

  tx_buf[ 0] = 0x00; // Write command MSByte
  tx_buf[ 1] = 0x01; // Write command LSByte
  tx_buf[ 2] = (cmd->addr0 >>  8) & 0xFF;
  tx_buf[ 3] = (cmd->addr0 >>  0) & 0xFF;
  tx_buf[ 4] = (cmd->addr1 >>  8) & 0xFF;
  tx_buf[ 5] = (cmd->addr1 >>  0) & 0xFF;
  tx_buf[ 6] = (cmd->wdat0 >> 24) & 0xFF;
  tx_buf[ 7] = (cmd->wdat0 >> 16) & 0xFF;
  tx_buf[ 8] = (cmd->wdat0 >>  8) & 0xFF;
  tx_buf[ 9] = (cmd->wdat0 >>  0) & 0xFF;
  tx_buf[10] = (cmd->wdat1 >> 24) & 0xFF;
  tx_buf[11] = (cmd->wdat1 >> 16) & 0xFF;
  tx_buf[12] = (cmd->wdat1 >>  8) & 0xFF;
  tx_buf[13] = (cmd->wdat1 >>  0) & 0xFF;

  // Initially, I sent one big packet with all 14 bytes. But this wasn't working...
  // After looking at the example Arduino code provided by Optotune, it became
  // clear that the mirror expects only one byte to be sent at a time, where each
  // byte is treated as a standalone packet (chip select is assered for each byte
  // and deasserted for a delay period between bytes).
  for (unsigned i = 0; i < MIRROR_CMD_LENGTH; i++)
  {
    spi_txrx(baseaddr, &tx_buf[i], &rx_buf[i], 1);
    usleep(25); 
  }

  uint16_t write_flag = ((uint16_t)rx_buf[0] << 8) | 
                        ((uint16_t)rx_buf[1] << 0);

  rsp->addr0  = ((uint16_t)rx_buf[ 2] << 8) | 
                ((uint16_t)rx_buf[ 3] << 0);
  rsp->addr1  = ((uint16_t)rx_buf[ 4] << 8) | 
                ((uint16_t)rx_buf[ 5] << 0);
  rsp->rpdat0 = ((uint32_t)rx_buf[ 6] << 24) |
                ((uint32_t)rx_buf[ 7] << 16) |
                ((uint32_t)rx_buf[ 8] <<  8) |
                ((uint32_t)rx_buf[ 9] <<  0);
  rsp->rpdat1 = ((uint32_t)rx_buf[10] << 24) |
                ((uint32_t)rx_buf[11] << 16) |
                ((uint32_t)rx_buf[12] <<  8) |
                ((uint32_t)rx_buf[13] <<  0);

  if (write_flag != 1 || rsp->addr0 == 0 || rsp->addr1 == 0 || 
      rsp->rpdat0 == READ_ERROR || rsp->rpdat1 == READ_ERROR) 
  {
    // Error in write response
    return 1;
  }
  
  return 0;
}


// Read mirror spi registers
int mirror_rd_regs(uint32_t baseaddr, mirror_rd_tx_t * cmd, mirror_rd_rx_t * rsp)
{
  uint8_t tx_buf[MIRROR_CMD_LENGTH] = {0};
  uint8_t rx_buf[MIRROR_CMD_LENGTH] = {0};

  tx_buf[ 0] = 0x00; // Read command MSByte
  tx_buf[ 1] = 0x00; // Read command LSByte
  tx_buf[ 2] = (cmd->addr >>  8) & 0xFF;
  tx_buf[ 3] = (cmd->addr >>  0) & 0xFF;
  tx_buf[ 4] = 0x00;
  tx_buf[ 5] = 0x00;
  tx_buf[ 6] = 0x00;
  tx_buf[ 7] = 0x00;
  tx_buf[ 8] = 0x00;
  tx_buf[ 9] = 0x00;
  tx_buf[10] = 0x00;
  tx_buf[11] = 0x00;
  tx_buf[12] = 0x00;
  tx_buf[13] = 0x00;

  for (unsigned i = 0; i < MIRROR_CMD_LENGTH; i++)
  {
    spi_txrx(baseaddr, &tx_buf[i], &rx_buf[i], 1);
    usleep(25); 
  }

  uint16_t read_flag = ((uint16_t)rx_buf[0] << 8) | 
                       ((uint16_t)rx_buf[1] << 0);

  rsp->prvrdat = ((uint32_t)rx_buf[ 2] << 24) |
                ((uint32_t)rx_buf[ 3] << 16) |
                ((uint32_t)rx_buf[ 4] <<  8) |
                ((uint32_t)rx_buf[ 5] <<  0);
  rsp->rpdat0 = ((uint32_t)rx_buf[ 6] << 24) |
                ((uint32_t)rx_buf[ 7] << 16) |
                ((uint32_t)rx_buf[ 8] <<  8) |
                ((uint32_t)rx_buf[ 9] <<  0);
  rsp->rpdat1 = ((uint32_t)rx_buf[10] << 24) |
                ((uint32_t)rx_buf[11] << 16) |
                ((uint32_t)rx_buf[12] <<  8) |
                ((uint32_t)rx_buf[13] <<  0);

  if (read_flag != 0 || rsp->rpdat0 == READ_ERROR || rsp->rpdat1 == READ_ERROR) {
    // Error in read response
    return 1;
  }
  
  return 0;
}

