# ***************************************************************************************
#                                 BuildPackages.sh script
# ***************************************************************************************
#   
# This script is intended to aid in debugging and building our ROS packages one by one.
# This aids when the 'colcon build' function causes errors and aborts after 2 consecutive
# failures during the build process."
#   
# This Script recursively searches the FSO/src looking for ROS packages which are"
# indicated via the directory name, which is also the ROS package name. The program" 
# builds a list of all the packages to help support future features of the script such as
# excluding a package from the build list."
#    
# ***************************************************************************************

#Directory variables
SCRIPTS_DIRECTORY=/opt/fso_prj/FSO/scripts
SRC_DIRECTORY=/opt/fso_prj/FSO/src

#Array storing the packages to build
PACKAGES_TO_BUILD=()
FAILED_BUILDS=()
PASSED_BUILDS=()

#Recursive searching method that checks each subdirectory underneath it for
#files named 'package.xml', indicating the direcrory is a valid package
search_directories(){

    for dirs in "$1"/*/ ; do #start from current directory
    if [ -d "$dirs" ] ; then
        if [ -f "$dirs/package.xml" ] ; then 
            echo "Found package at: $dirs, adding to build list." #if 'package.xml' in current directory add to build list
            package=$(basename "$dirs") #convert the directory to our package name
            PACKAGES_TO_BUILD+=("$package")
        fi
        search_directories "$dirs" #recursively search the next directory
    fi
    done 
}

#Main
##############################################################################

#Color codings
PASS_COLOR='\033[1;32m'
FAIL_COLOR='\033[1;31m'
NO_COLOR='\033[0m'

#Navigate to /src directory (avoid searching all FSO directories)
cd $SRC_DIRECTORY

#Call the recursive search function on the FSO directory
search_directories "$SRC_DIRECTORY"

#Build all of our packages
for i in ${PACKAGES_TO_BUILD[@]}
do
    colcon build --packages-select $i
    if [ $? -eq 0 ] ; then
        echo -e "${PASS_COLOR}Successfully Built: "${i}" with exit code: $? ${NO_COLOR}"
        PASSED_BUILDS+=("$i")
    else
        echo -e "${FAIL_COLOR}Failed to build: "${i}" with exit code: $? ${NO_COLOR}"
        FAILED_BUILDS+=("$i")
    fi    
done

#Print Passed Builds
echo "Passed Builds: "
for i in ${PASSED_BUILDS[@]}
do
    echo "    $i"
done
    
#Print Failed Builds
echo "Failed Builds: "
for i in ${FAILED_BUILDS[@]}
do
    echo "    $i"
done

#If we have left the script directory, return to it in the end
cd $SCRIPTS_DIRECTORY
