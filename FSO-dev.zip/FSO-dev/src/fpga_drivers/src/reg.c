/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : reg
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-10-28
--------------------------------------------------------------------------------
-- Description: Driver to access FPGA registers over the PCIe interface
------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <byteswap.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>


//#include "/opt/fso_prj/FSO/install/fpga_drivers/include/fpga_drivers/reg.h"
#include "fpga_drivers/reg.h"

// Clock speed 
#define REG_CLK_HZ 100000000LL

// Address Map
#define SCRATCHPAD_ADDR 0x00
#define ID_ADDR         0x04
#define VERSION_ADDR    0x08
#define BDATE_ADDR      0x0C
#define BTIME_ADDR      0x10
#define GITHASH_ADDR    0x14

// Character access devices
#define REG_DEVICE_PATH "/dev/xdma0_user"

// Compatibility with both little and big endian systems
/* ltoh: little endian to host */
/* htol: host to little endian */
#if __BYTE_ORDER == __LITTLE_ENDIAN
#define ltohl(x)       (x)
#define ltohs(x)       (x)
#define htoll(x)       (x)
#define htols(x)       (x)
#elif __BYTE_ORDER == __BIG_ENDIAN
#define ltohl(x)     __bswap_32(x)
#define ltohs(x)     __bswap_16(x)
#define htoll(x)     __bswap_32(x)
#define htols(x)     __bswap_16(x)
#endif


// Read an FPGA register
uint32_t reg_rd(uint32_t addr)
{
	int fd;
	void *map;
	uint32_t read_result = 0xDEADBEEF;
	off_t target;
	off_t pgsz, target_aligned, offset;

	target = addr;
	pgsz = sysconf(_SC_PAGESIZE);
	offset = target & (pgsz - 1);
	target_aligned = target & (~(pgsz - 1));

	if ((fd = open(REG_DEVICE_PATH, O_RDWR | O_SYNC)) == -1) {
		printf("Character device %s opened failed: %s.\n", REG_DEVICE_PATH, strerror(errno));
		return read_result;
	}

	map = mmap(NULL, offset + 4, PROT_READ | PROT_WRITE, MAP_SHARED, fd, target_aligned);

	if (map == (void *)-1) {
		printf("Memory 0x%lx mapped failed: %s.\n", target, strerror(errno));
		close(fd);
	  return read_result;
	}

	map += offset;
  read_result = *((uint32_t *) map);
  read_result = ltohl(read_result);

	close(fd);
	return read_result;
}


// Write an FPGA register
void reg_wr(uint32_t addr, uint32_t data)
{
	int fd;
	void *map;
	uint32_t writeval;
	off_t target;
	off_t pgsz, target_aligned, offset;

	target = addr;
	pgsz = sysconf(_SC_PAGESIZE);
	offset = target & (pgsz - 1);
	target_aligned = target & (~(pgsz - 1));

	if ((fd = open(REG_DEVICE_PATH, O_RDWR | O_SYNC)) == -1) {
		printf("Character device %s opened failed: %s.\n", REG_DEVICE_PATH, strerror(errno));
		return;
	}

	map = mmap(NULL, offset + 4, PROT_READ | PROT_WRITE, MAP_SHARED, fd, target_aligned);
	
	if (map == (void *)-1) {
		printf("Memory 0x%lx mapped failed: %s.\n", target, strerror(errno));
		close(fd);
		return;
	}

	map += offset;
  writeval = data;
  writeval = htoll(writeval);
  *((uint32_t *) map) = writeval;

	map -= offset;
	if (munmap(map, offset + 4) == -1) {
		printf("Memory 0x%lx mapped failed: %s.\n", target, strerror(errno));
	}

	close(fd);
	return;
}

// Print the FPGA version information
void reg_fpga_info(uint32_t baseaddr)
{
  reg_wr(baseaddr + SCRATCHPAD_ADDR, 0x00000000);
  printf("SCRATCHPAD: 0x%08X\n", reg_rd(baseaddr + SCRATCHPAD_ADDR));
  reg_wr(baseaddr + SCRATCHPAD_ADDR, 0x87654321);
  printf("SCRATCHPAD: 0x%08X\n", reg_rd(baseaddr + SCRATCHPAD_ADDR));
  printf("FPGA ID   : 0x%08X\n", reg_rd(baseaddr + ID_ADDR        ));
  printf("VERSION   : 0x%08X\n", reg_rd(baseaddr + VERSION_ADDR   ));
  printf("BUILD DATE: 0x%08X\n", reg_rd(baseaddr + BDATE_ADDR     ));
  printf("BUILD TIME: 0x%08X\n", reg_rd(baseaddr + BTIME_ADDR     ));
  printf("GIT HASH  : 0x%08X\n", reg_rd(baseaddr + GITHASH_ADDR   ));
}
