/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : spi
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-12-11
--------------------------------------------------------------------------------
-- Description: Driver for SPI FPGA block
------------------------------------------------------------------------------*/

#ifndef SPI_H_ 
#define SPI_H_

#include <stdint.h>

// This option depends on how the IP was built in Vivado.
#define SPI_TXRX_FIFO_DEPTH 16

// Number of times to try a transmit / receive before giving up
#define SPI_TXRX_TRIES 10

// Microseconds to wait between each transmit / receive try
#define SPI_TXRX_TIME_US 1000

void spi_soft_reset(uint32_t baseaddr);
void spi_setup(uint32_t baseaddr, unsigned cpol, unsigned cpha, unsigned lsb_first);
void spi_loopback(uint32_t baseaddr, unsigned loopback);
int spi_txrx(uint32_t baseaddr, uint8_t * tx_buf, uint8_t * rx_buf, unsigned size);

#endif /* SPI_H_ */
