/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : uart
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-10-28
--------------------------------------------------------------------------------
-- Description: Access FPGA uart setial port over the pcie interface
------------------------------------------------------------------------------*/

#ifndef UART_H_
#define UART_H_

#include <stdint.h>

// Number of times to try a transmit / receive before giving up
#define TXRX_TRIES 1000

// Microseconds to wait between each transmit / recieve try
#define TXRX_TIME_US 1000

int uart_is_tx_full(uint32_t baseaddr);
int uart_is_rx_empty(uint32_t baseaddr);

int uart_tx_byte(uint32_t baseaddr, char byte);
int uart_rx_byte(uint32_t baseaddr, char * byte);
int uart_tx(uint32_t baseaddr, const char * buf, unsigned len);
int uart_rx(uint32_t baseaddr, char * buf, unsigned len);

#endif /* UART_H_ */
