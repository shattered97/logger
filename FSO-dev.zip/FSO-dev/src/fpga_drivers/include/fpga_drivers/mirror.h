/*------------------------------------------------------------------------------
--
-- (C)Copyright 2025 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : mirror
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2025-02-03
--------------------------------------------------------------------------------
-- Description: Driver MRE-3 optical mirror
------------------------------------------------------------------------------*/
#ifndef MIRROR_H_
#define MIRROR_H_

#include <stdint.h>

// Mirror SPI write command
typedef struct mirror_wr_tx_t {
  uint16_t addr0; // Address 0 to write 
  uint16_t addr1; // Address 1 to write
  uint32_t wdat0; // Write data to address 0
  uint32_t wdat1; // Write data to address 1
} mirror_wr_tx_t;

// Mirror SPI write response
typedef struct mirror_wr_rx_t {
  uint16_t addr0;  // Address 0 written (or 0x0000 if write failed)
  uint16_t addr1;  // Address 1 written (or 0x0000 if write failed)
  uint32_t rpdat0; // Readback pointer data 0 (or 0x7CF0_BDC2 if read failed)
  uint32_t rpdat1; // Readback pointer data 1 (or 0x7CF0_BDC2 if read failed)
} mirror_wr_rx_t;

// Mirror SPI read command 
typedef struct mirror_rd_tx_t {
  uint16_t addr; // Address to read 
} mirror_rd_tx_t;

// Mirror SPI read response 
typedef struct mirror_rd_rx_t {
  uint32_t prvrdat; // Readback data from previous read request addr (or 0x7CF0_BDC2 if read failed)
  uint32_t rpdat0;  // Readback pointer data 0 (or 0x7CF0_BDC2 if read failed)
  uint32_t rpdat1;  // Readback pointer data 1 (or 0x7CF0_BDC2 if read failed)
} mirror_rd_rx_t;

void mirror_setup(uint32_t baseaddr);
int mirror_wr_regs(uint32_t baseaddr, mirror_wr_tx_t * cmd, mirror_wr_rx_t * rsp);
int mirror_rd_regs(uint32_t baseaddr, mirror_rd_tx_t * cmd, mirror_rd_rx_t * rsp);

#endif
