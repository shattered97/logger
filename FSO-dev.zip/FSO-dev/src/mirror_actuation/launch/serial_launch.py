from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package="serial",
            executable="serial",
            name="serial",
            output="screen",
            emulate_tty=True,
            parameters=[
                {"serialPortParam": "/dev/ttyACM1"},
                {"baudRateParam": 256000},
                {"serialIdParam": 0}
            ]
        ),
        Node(
            package="mirror_actuation",
            executable="mirror",
            name="mirror0",
            output="screen",
            emulate_tty=True,
            parameters=[
                {"mirrorIdParam": 0}
            ]
        ),
        Node(
            package="mirror_actuation",
            executable="mirrortranslator",
            name="mirrortranslator0",
            output="screen",
            emulate_tty=True,
            parameters=[
                {"mirrorIdParam": 0}
            ]
        ),
       Node(
            package="mirror_actuation",
            executable="mirrortoggler",
            name="mirrortoggler0",
            output="screen",
            emulate_tty=True,
            parameters=[]
        )
    ])
