/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : cam
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-12-03
--------------------------------------------------------------------------------
-- Description: Driver for Vision Components IMX273 camera
------------------------------------------------------------------------------*/


//#include "/opt/fso_prj/FSO/install/fpga_drivers/include/fpga_drivers/cam.h"
//#include "/opt/fso_prj/FSO/install/fpga_drivers/include/fpga_drivers/xiic.h"

#include "fpga_drivers/cam.h"
#include "fpga_drivers/xiic.h"

// Read a camera i2c register
// Returns the register value
uint8_t cam_rd_reg(uint32_t baseaddr, int device_sel, uint16_t addr)
{
  uint8_t i2c_addr;
  if (device_sel) {
    i2c_addr = CAM_MOD_I2C_ADDR;
  } else {
    i2c_addr = CAM_SEN_I2C_ADDR;
  }

  uint8_t tx_buf[2] = { 0 };
  tx_buf[0] = (addr >> 8) & 0xFF;
  tx_buf[1] = addr & 0xFF;
  XIic_Send(baseaddr, i2c_addr, tx_buf, 2, XIIC_STOP);

  uint8_t rx_buf[2] = { 0 };
  XIic_Recv(baseaddr, i2c_addr, rx_buf, 1, XIIC_STOP);

	return rx_buf[0];
}


// Write a camera i2c register
void cam_wr_reg(uint32_t baseaddr, int device_sel, uint16_t addr, uint8_t data)
{
  uint8_t i2c_addr;
  if (device_sel) {
    i2c_addr = CAM_MOD_I2C_ADDR;
  } else {
    i2c_addr = CAM_SEN_I2C_ADDR;
  }

  uint8_t tx_buf[3];
  tx_buf[0] = (addr >> 8) & 0xFF;
  tx_buf[1] = addr & 0xFF;
  tx_buf[2] = data;
  XIic_Send(baseaddr, i2c_addr, tx_buf, 3, XIIC_STOP);
	return;
}
