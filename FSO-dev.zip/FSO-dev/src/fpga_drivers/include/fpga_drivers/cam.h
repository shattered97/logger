/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : cam
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-12-03
--------------------------------------------------------------------------------
-- Description: Driver for Vision Components IMX273 camera
------------------------------------------------------------------------------*/

#ifndef CAM_H_
#define CAM_H_

#include <stdint.h>

#define CAM_MOD_I2C_ADDR 0x10
#define CAM_SEN_I2C_ADDR 0x1A

#define CAM_SEN 0 //0x1A
#define CAM_MOD 1 //0x10

#define CAM_MOD_INIT_ADDR             0x0100
#define CAM_MOD_STATUS_ADDR           0x0101
#define CAM_MOD_MODE_ADDR             0x0102
#define CAM_MOD_IOCTL_ADDR            0x0103
#define CAM_MOD_MOD_I2C_ADDR          0x0104
#define CAM_MOD_SENS_I2C_ADDR         0x0105
#define CAM_MOD_OUT_OVERRIDE_ADDR     0x0106
#define CAM_MOD_IN_STS_ADDR           0x0107
#define CAM_MOD_EXT_TRIG_EN_ADDR      0x0108
#define CAM_MOD_EXPOSURE_0_ADDR       0x0109
#define CAM_MOD_EXPOSURE_1_ADDR       0x010A
#define CAM_MOD_EXPOSURE_2_ADDR       0x010B
#define CAM_MOD_EXPOSURE_3_ADDR       0x010C
#define CAM_MOD_RETRGR_0_ADDR         0x010D
#define CAM_MOD_RETRGR_1_ADDR         0x010E
#define CAM_MOD_RETRGR_2_ADDR         0x010F
#define CAM_MOD_RETRGR_3_ADDR         0x0110
//#define CAM_MOD_RETRGR_3_ADDR         0x0110
#define CAM_SEN_VMAX_LOW_ADDR         0x0210
#define CAM_SEN_VMAX_MID_ADDR         0x0211
#define CAM_SEN_VMAX_HIG_ADDR         0x0212
#define CAM_SEN_HMAX_LOW_ADDR         0x0214
#define CAM_SEN_HMAX_HIG_ADDR         0x0215
#define CAM_SEN_SHS_LOW_ADDR          0x028D
#define CAM_SEN_SHS_MID_ADDR          0x028E
#define CAM_SEN_SHS_HIG_ADDR          0x028F
#define CAM_SEN_ROM_START_ADDR        0x1000
#define CAM_SEN_ENABLE_ADDR           0x7000
#define CAM_SEN_CLOCK_SEL_ADDR        0x7001

uint8_t cam_rd_reg(uint32_t baseaddr, int device_sel, uint16_t addr);
void cam_wr_reg(uint32_t baseaddr, int device_sel, uint16_t addr, uint8_t data);


#endif // CAM_H_
