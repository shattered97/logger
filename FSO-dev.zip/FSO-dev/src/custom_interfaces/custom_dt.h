#ifndef CUSTOM_DT_H
#define CUSTOM_DT_H


//Standardized Message Formats
#define MSG_PARAM_UPDATE "PARAMETER(%s) is being updated to: %s"  //param, new value
#define MSG_WD_FIRED "WATCHDOG(%s) method has fired"              //function called
#define MSG_CONNECTING "CONNECTING(%s) port %s"                   //comm type, port 
#define MSG_CAM_COORD "TARGET(%d) X: %f | Y: %f | Area: %f | Brightness: %f | Focal Length: %f"       //cam cooridantes

//Standardized Basler Error Formats
#define BASLER_ERROR "BASLER ERROR:  %s"

//Standardized Mirror Error Messages
#define MIRROR_STATUS_ERROR "MIRROR ERROR: %s"

//Standardized Mirror Messages
#define SEND_MIRROR_CMD "SEND MIRROR MOVE: X: %f | Y: %f"
#define SEND_MIRROR_CMD_FAILED "SEND MIRROR MOVE FAILED: X: %f | Y: %f"
#define MIRROR_COORDS_OOR "MIRROR COORDINATES ARE OUT OF RANGE: X: %f | Y: %f"

//Standardized EDFA Messages
#define SEND_EDFA_CMD "SEND EDFA COMMAND: %s"
#define EDFA_CMD_ERROR "FAILED TO SEND COMMAND: %s"
#define EDFA_CMD_SUCCESS "SUCCESSFULLY SENT COMMAND: %s"

//Register Read Message
#define REG_READ "Register(0x%02X) %s 0x%02X"
#define UPDATE_REG "UPDATE:  %s: %d(0x%X)"

//Standardized Service Formats
#define SRV_PTU_MOVE_REL_IN "SERVICE:INCOMING(ptu_move_rel) pan offset: %f | tilt offset: %f"
#define SRV_PTU_MOVE_REL_OUT "SERVICE:OUTGOING(put_move_rel) pan position: %f | tilt position: %f"
#define SRV_LENS_MOVE_IN "SERVICE:INCOMING(lens_move) motor ID: %d | percent offset: %f"
#define SRV_LENS_MOVE_OUT "SERVICE:OUTGOING(lens_move) success: %d"
#define SRV_LENS_HOME_IN "SERVICE:INCOMING(lens_home) going home: %d"
#define SRV_LENS_HOME_OUT "SERVICE:OUTGOING(lens_home) success: %d"
#define SRV_CAM_COORDS_IN "SERVICE:INCOMING(camera_coords_service)"
#define SRV_CAM_COORDS_OUT "SERVICE:OUTGOING(camera_coords_service) Focal length: %f | X coord: %f | Y coord: %f"

#define MSG_LOAD_FILE "LOAD FILE(%s):  %s"
#define MSG_LOAD_FILE_ERROR "FAILED TO OPEN(%s)"
#define MSG_INCORRECT_FILE "FILE FAILED TO PARSE CORRECTLY ON LINE:(%d)"

#define MSG_VC_THREAD_STARTED "VC MODULE(%d): Grab Thread Started"
#define MSG_VC_INITIAL_FAILED "VC MODULE(%d): Failed to Initialize"
#define MSG_VC_DMA_MEM_ERROR "VC MODULE(%d):  Out of memory: %lu"
#define MSG_VC_FAILED_TO_FRAME "VC MODULE(%d): Failed to read frame"

#define MSG_GIMBAL_CONNECTED "T3V3 GIMBAL: connected to serial port %s"

//FSO Control Messages
#define ERROR_PCIE_WAKE_N "ADDRESS(0x%X) value(%d): No PCIe wakeup signal from the PC"
#define ERROR_APD_LOS "ADDRESS(0x%X) value(%d): APD %d Loss of Signal"
#define STATUS_MIRROR_DATA_PIN "ADDRESS(0x%X) value(%d) data pin state: %d"
#define STATUS_EDFA_PUMP "ADDRESS(0x%X) value(%d): EDFA %d Pump laser status"
#define ERROR_EDFA_ALARM "ADDRESS(0x%X) value(%d): EDFA %d Alarm pin is enabled high"
#define ERROR_TEC "ADDRESS(0x%X) value(%d): TEC %d, 0 = TEC temp outside programmed temp window or an error occurred."
#define ERROR_SFP_TFAULT "ADDRESS(0x%X) value(%d): SFP %d, 1 = SFP transciever fault has occured. Likely means there is a hardware issue."
#define ERROR_SFP_LOS "ADDRESS(0x%X) value(%d): SFP %d LOS"
#define ERROR_DDR4 "ADDRESS(0x%X) value(%d): 1 = DDR4 calibration sequence is complete"
#define ERROR_PCIE_LINK "ADDRESS(0x%X) value(%d): PCIe link is down"
#define ERROR_ETH_LINK "ADDRESS(0x%X) value(%d): Ethernet link is down"

uint16_t covertTo16_bit(uint8_t byte2, uint8_t byte1)
{
return static_cast<int16_t>(static_cast<int>(byte2) << 8) | static_cast<int16_t>(static_cast<int>(byte1));
}

uint32_t convertTo32_bit(uint8_t byte4, uint8_t byte3, uint8_t byte2, uint8_t byte1)
{
return static_cast<int32_t>(static_cast<int>(byte4) << 24) | static_cast<int32_t>(static_cast<int>(byte3)) << 16 | static_cast<uint32_t>(static_cast<int>(byte2)) << 8 | static_cast<uint32_t>(static_cast<int>(byte1));
}

void convertFrom16_bit(uint16_t input, uint8_t &byte2, uint8_t &byte1 )
{
    byte2 = (input >> 4); //& 0xFF;  // Shift right by 8 bits and mask with 0xFF to get the high byte
    std::cout << "Byte2: " << std::hex << (int)byte2 << std::endl;
    byte1 = input & 0xFF;         // Mask with 0xFF to get the low byte
    std::cout << "Byte1: " << std::hex << (int)byte1 << std::endl; 
}

void convertFrom32_bit(uint32_t input, uint8_t &byte4, uint8_t &byte3, uint8_t &byte2, uint8_t& byte1 )
{
    byte4 = (input >> 24) & 0xFFF;
    byte3 = (input >> 16) & 0xFFF;
    byte2 = (input >>  8) & 0XFFF;
    byte1 =  input && 0xFFF;
}

//EDFA commands
const std::string cmd_reset    = "reset";
const std::string cmd_gmode    = "gmode";
const std::string cmd_saopc    = "saopc ";
const std::string cmd_aopc     = "aopc ";
const std::string cmd_fline    = "fline";
const std::string cmd_edfa_on  = "edfa on";
const std::string cmd_edfa_off = "edfa off";
const std::string cmd_gaopc    = "gaopc";
const std::string cmd_gcta     = "gcta";
const std::string cmd_gbtemp   = "gbtemp";

/*************
Constants
**************/

// Previous values 01/17/2025             Xm                     Ym
//  const std::pair<double,double> P1(-1.06888955257942e-07, -7.24793175333591e-09);
// const std::pair<double,double> P2(2.10795839393517e-06, 1.67199022986552e-06);
// const std::pair<double,double> P3(0.000136680565995848, 2.58140474851140e-08);
// const std::pair<double,double> P4(-8.50370696316274e-07, -3.94002383582425e-06);
// const std::pair<double,double> P5(1.05246067566438e-05, 0.000184560006772782);
// const std::pair<double,double> P6(0.000262472376265677, -0.0206226511848563);
// const std::pair<double,double> P7(7.34388260649382e-07, 5.24528037171462e-06);
// const std::pair<double,double> P8(0.0146711500220324, 5.22367980087423e-05);
// const std::pair<double,double> P9(-0.0203351658385909, -0.0142198292998564); 

// Previous values 01/20/2025            Xm                     Ym
/* const std::pair<double,double> P1(-8.54274819214711e-08, -1.42201013898337e-08);
const std::pair<double,double> P2(2.05772472715674e-06, 1.65947505488984e-06);
const std::pair<double,double> P3(0.000143031324664629, -2.11249045852511e-06);
const std::pair<double,double> P4(-6.7688858694739e-07, -3.93820220076029e-06);
const std::pair<double,double> P5(1.10875121249043e-05, 0.000181707947561496);
const std::pair<double,double> P6(0.000251837107895167, -0.0206693961795861);
const std::pair<double,double> P7(4.96679282571701e-06, 6.86529350040936e-06);
const std::pair<double,double> P8(0.0147246863289984, 2.74518617436374e-05);
const std::pair<double,double> P9(-0.0157925321969901, -0.01183947954226090); */

// 02/07/2025                             Xm                     Ym
//const std::pair<double,double> P1(-1.03724353550847e-07, -4.52406649311308e-08);
//const std::pair<double,double> P2(2.21681591416879e-06, 1.26049229910719e-06);
//const std::pair<double,double> P3(0.000144768305445293, 1.41730622006289e-05);
//const std::pair<double,double> P4(-9.00165987496236e-07, -4.15073274747220e-06);
//const std::pair<double,double> P5(1.32497832452655e-05, 0.000181249368764470);
//const std::pair<double,double> P6(0.000278448364482427, -0.0207312511943655);
//const std::pair<double,double> P7(4.24075289391362e-06, 7.54924253037835e-06);
//const std::pair<double,double> P8(0.0147307536304807, 3.09054247775116e-05);
//const std::pair<double,double> P9(-0.0127450252253104, -0.0132169290422150);

// 02/21/2025                             Xm                     Ym
/*const std::pair<double,double> P1(-9.02954353000365e-08, 2.18707190752533e-08);
const std::pair<double,double> P2(2.00474148798599e-06, 1.67906795505347e-06);
const std::pair<double,double> P3(0.000136126518172578, -1.40690599179815e-05);
const std::pair<double,double> P4(-6.95068757022066e-07, -3.96287773058647e-06);
const std::pair<double,double> P5(1.82945256468186e-05, 0.000191525108363986);
const std::pair<double,double> P6(-5.81553618130515e-06, -0.0206973979458823);
const std::pair<double,double> P7(-1.02345407296153e-06, 4.25828466457023e-06);
const std::pair<double,double> P8(0.0147196469514463, -0.000161729298675984);
const std::pair<double,double> P9(-0.0259716777419928, -0.0197061156023758);*/

// 02/27/2025        500us 4815 averaged    Xm                     Ym
// Static Calibration : 2025-02-27_1500_HP_CalTable_Testing_resampled_parallel_polycoeffs_4thorder.txt
//                                          Xm                     Ym 
 const std::pair<double,double> P1(1.77799644103188E-11, 5.93943291938596E-12);
 const std::pair<double,double> P2(-4.83714641333195E-12, 4.296363339603E-11);
 const std::pair<double,double> P3(-1.70971205046434E-09, -1.18406699159814E-09);
 const std::pair<double,double> P4(-1.87020444266816E-08, -1.87580539953897E-08);
 const std::pair<double,double> P5(-1.64428003601797E-08, 1.36306265982666E-07);
 const std::pair<double,double> P6(5.6044838909703E-11, -6.22757897589213E-11);
 const std::pair<double,double> P7(5.38556629336811E-10, -6.46473097417253E-10);
 const std::pair<double,double> P8(-2.8401611237857E-10, 3.3826235761863E-08);
 const std::pair<double,double> P9(-2.18183134112942E-07, 1.8036952557935E-07);
 const std::pair<double,double> P10(-1.85923972438342E-06, -7.64065902836951E-06);
 const std::pair<double,double> P11(-1.06832559232332E-09, -8.80006910131183E-10);
 const std::pair<double,double> P12(-1.07842174648146E-09, -1.34637259335384E-08);
 const std::pair<double,double> P13(2.7229203947794E-08, 2.2371779818578E-07);
 const std::pair<double,double> P14(2.90254551114261E-06, 3.97898899211588E-06);
 const std::pair<double,double> P15(1.26270494271931E-04, -4.22438395110118E-05);
 const std::pair<double,double> P16(2.75702056839555E-09, 4.16052665108299E-09);
 const std::pair<double,double> P17(-1.02010076515228E-07, 1.1032165390955E-08);
 const std::pair<double,double> P18(-1.03008933052524E-06, -5.39163613341608E-06);
 const std::pair<double,double> P19(3.27741226085878E-05, 1.88119480846881E-04);
 const std::pair<double,double> P20(4.47111726592884E-05, -2.02402322528687E-02);
 const std::pair<double,double> P21(1.23741451531543E-08, 1.34016486917978E-08);
 const std::pair<double,double> P22(2.08251229846996E-06, 6.91745131665356E-07);
 const std::pair<double,double> P23(-6.59753255518399E-06, 1.18427278248506E-06);
 const std::pair<double,double> P24(1.45661977280371E-02, -2.35128868928989E-04);
 const std::pair<double,double> P25(-3.86019828049997E-02, -1.86407641757177E-02);
// Please comment out previous Static Calibration



// 02/21/2025                             theta_x_corr             theta_y_corr, measured using new process in the mail room
// These are the coefficients found for FSO-B1-43074815
/* const std::pair<double,double> P1_corr(-3.49852071005916e-12, 5.01177394034537e-12);
const std::pair<double,double> P2_corr(3.76053465765004e-09, -3.31948738075112e-09);
const std::pair<double,double> P3_corr(-4.82484784446324e-07, -3.80545948556937e-07);
const std::pair<double,double> P4_corr(1.21710542205047e-09, -1.43940345368917e-09);
const std::pair<double,double> P5_corr(-1.24852427243086e-06, 8.14244535684096e-07);
const std::pair<double,double> P6_corr(0.000174720041057844, 0.000222323980195628);
const std::pair<double,double> P7_corr(-9.11273245984785e-08, -2.59168367346939e-07);
const std::pair<double,double> P8_corr(-5.71189740067623e-05, 0.000232650727871030);
const std::pair<double,double> P9_corr(0.0335012603127641, -0.0714624913295495); */

// Here is where you update them for use once you calibrate in the mail room
const std::pair<double,double> P1_corr(0, 0);
const std::pair<double,double> P2_corr(0, 0);
const std::pair<double,double> P3_corr(0, 0);
const std::pair<double,double> P4_corr(0, 0);
const std::pair<double,double> P5_corr(0, 0);
const std::pair<double,double> P6_corr(0, 0);
const std::pair<double,double> P7_corr(0, 0);
const std::pair<double,double> P8_corr(0, 0);
const std::pair<double,double> P9_corr(0, 0);


// FOV Calibration : 2025-02-28_1030_CalTable_Testing_resampled_parallel_polycoeffs_corr_highres.txt
/*                                          Xm                     Ym 
const std::pair<double,double> P1_corr(-8.33512726878936E-14, -2.9870480433533E-12);
const std::pair<double,double> P2_corr(-1.60695550196582E-10, 2.80798500548174E-09);
const std::pair<double,double> P3_corr(1.14212170268078E-08, -9.06981727981322E-07);
const std::pair<double,double> P4_corr(-2.88109513005328E-10, 7.62606928184542E-10);
const std::pair<double,double> P5_corr(9.20722890781855E-08, -8.99858766794086E-07);
const std::pair<double,double> P6_corr(-2.50051496564951E-05, 4.55024686231947E-04);
const std::pair<double,double> P7_corr(-1.76760637111099E-07, 3.45237346588245E-07);
const std::pair<double,double> P8_corr(2.09328418656975E-04, -2.6493021306104E-04);
const std::pair<double,double> P9_corr(-1.94720635769798E-02, 6.83359540827753E-03);*/
// Please comment out previous Static Calibration

// 02/26/2025    FOV CAL          theta_x_corr             theta_y_corr, measured using new process in the mail room
// These are the coefficients found for FSO-B1-43074815
/*const std::pair<double,double> P1_corr(-3.76374945626091e-12, 3.70069527828980e-12);
const std::pair<double,double> P2_corr(1.29553896565779e-09, -1.66583395236545e-09);
const std::pair<double,double> P3_corr(6.19567336286861e-07, -1.06854926806876e-06);
const std::pair<double,double> P4_corr(1.92640857240505e-09, -2.44642811787097e-09);
const std::pair<double,double> P5_corr(-4.88051833795954e-07, 1.11499197343425e-06);
const std::pair<double,double> P6_corr(-0.000409944204970438, 0.000518773850937749);
const std::pair<double,double> P7_corr(-2.73990293599932e-07, 4.51365950549412e-07);
const std::pair<double,double> P8_corr(0.000119453413059348, -0.000260174074099815);
const std::pair<double,double> P9_corr(0.0368958503746455, -0.0149803203190809);*/

//const std::vector<std::pair<double,double>> pValues = {P1, P2, P3, P4, P5, P6, P7, P8, P9};

/****************
 * ENUMERATIONS *
 ****************/
namespace status
{
    enum class state
    {
        initializating,
        notConnected,
        reconnecting,
        running,
        error,
        stopped,
        unknown
    };

    enum class commType
    {
        none,
        serial,
        i2c,
        spi,
        socket,
        usb,
        pcie,
        unknown
    };
}

/////////////////////////////////////////////////////////////////////////////
// GREMSY GIMBAL STRUCTS.
namespace gremsy
{
  enum sdk_process_state_t
  {
    STATE_IDLE,
    STATE_CONNECTED,
    STATE_PROCESS,
    STATE_DONE
  };

  enum gimbal_axis
  {
    AXIS_PITCH = 0x01,
    AXIS_ROLL,
    AXIS_PAN,
  };

  enum type_of_gimbal
  {
    TWO_AXIS = 0x01,
    THREE_AXIS,
  };

  enum mount_mode
  {
    TWO_AXIS_GIMBAL_MOUNT_MODE_ROLL_TILT = 0x01,
    TWO_AXIS_GIMBAL_MOUNT_MODE_PAN_TILT,
    THREE_AXIS_GIMBAL_MOUNT_NORMAL_MODE = 0x06,
    THREE_AXIS_GIMBAL_MOUNT_INVERTED_MODE,
    OFFSET = 5
  };
}

//pixelPos = xP or yP
//pixel_size in um
//Focal Length of LENS
//degrees = radians * 180 / PI
//returns angle to the pixel on the respective axis in radians

double convertPixelPointToAngle(int pixelPos, double pixelSize_um, double EFL_mm)
{

    double theta_radians = std::atan((pixelSize_um * 1e-06) * pixelPos / (EFL_mm * 1e-3));
    return theta_radians;
}

//cal_distance = distance from camera lens focal point to projection screen
//theta = thetaX or thetaY
//delta = deltaX or deltaY Theta and delta must be on the same axis
//delta_z = delta Z distance 
//degrees = radians * 180 / PI
//Returns mirror angle on the respective axis
double convertPixelThetaToMirrorPos(double calDistance, double thetaRadians, double deltaDistance, double deltaZ)
{
    double theta_radians = std::atan((calDistance * tan(thetaRadians) - deltaDistance) / (calDistance + deltaZ));
    return theta_radians;
}

/***********
 * CLASSES *
 ***********/
 
class CameraData
{
public:
    CameraData(int targetID, double Xp, double Yp, double tArea, double pBrightness, int hgt, int width, double focalLgth)
    {
        tID = targetID;
        x = Xp;
        y = Yp;
        area = tArea;
        brightness = pBrightness;
        imageHeight = hgt;
        imageWidth = width;
        focalLength = focalLgth;
    }

    int tID;
    double x;
    double y;
    double area;
    double brightness;
    int imageHeight;
    int imageWidth;
    double focalLength; 
    
};

class CalData
{
public:

    CalData()
    {
        //do not nothing, default constructor
    }

    CalData(double x_cam, double y_cam, double x_mirror, double y_mirror)
    {
        
        xP = x_cam;
        yP = y_cam;
        xM = x_mirror;
        yM = y_mirror;
    }

    double xP;
    double yP;
    double xM;
    double yM;
};

class RoiWindowData
{
    public:
    RoiWindowData(int width, int hgt)
    {
        x = width;
        y = hgt;
    }

    int x;
    int y;
};

class TargetData
{
     TargetData(double xP, double yP, double lastSeen)
     {
        lastSeen_epoch = lastSeen;
        _xP = xP;
        _yP = yP;
     }
    
    double lastSeen_epoch;
    double _xP;
    double _yP;
};

// class VC_Mode
// {
//     VC_Mode()
//     {
        
//     }

//     int cs;         //0 = 27Mhz, 1 = 54Mhz  1.5Gps or 750Mps
//     int hmax_low;
//     int hmax_high;
//     int vmax_low;
//     int vmax_mid;
//     int vmax_high

// };

// namespace mirror
// {
//     class mirror_wr_tx_t
//     {
//         public:
//         mirror_wr_tx_t()
//         {

//         }
//         uint16_t addr0; // Address 0 to write 
//         uint16_t addr1; // Address 1 to write
//         uint32_t wdat0; // Write data to address 0
//         uint32_t wdat1; // Write data to address 1
//     };

//     class mirror_wr_rx_t
//     {
//         public:
//         mirror_wr_rx_t()
//         {

//         }
//         uint16_t addr0;  // Address 0 written (or 0x0000 if write failed)
//         uint16_t addr1;  // Address 1 written (or 0x0000 if write failed)
//         uint32_t rpdat0; // Readback pointer data 0 (or 0x7CF0_BDC2 if read failed)
//         uint32_t rpdat1; // Readback pointer data 1 (or 0x7CF0_BDC2 if read failed)
//     };

//     class mirror_rd_tx_t
//     {
//         public:
//         mirror_rd_tx_t()
//         {

//         }
//         uint16_t addr; // Address to read 
//     };

//     class mirror_rd_rx_t
//     {
//         public:
//         mirror_rd_rx_t()
//         {

//         }
//         uint32_t prvrdat; // Readback data from previous read request addr (or 0x7CF0_BDC2 if read failed)
//         uint32_t rpdat0;  // Readback pointer data 0 (or 0x7CF0_BDC2 if read failed)
//         uint32_t rpdat1;  // Readback pointer data 1 (or 0x7CF0_BDC2 if read failed)
//     };
// };

//
#endif
