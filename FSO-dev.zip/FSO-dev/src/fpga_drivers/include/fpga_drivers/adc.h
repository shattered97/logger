/*------------------------------------------------------------------------------
--
-- (C)Copyright 2025 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : adc
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2025-04-07
--------------------------------------------------------------------------------
------------------------------------------------------------------------------*/


#ifndef ADC_H_
#define ADC_H_

#include <stdint.h>

void adc_setup(uint32_t baseaddr);
uint16_t adc_wr_reg(uint32_t baseaddr, uint8_t addr, uint8_t data);
uint8_t adc_rd_reg(uint32_t baseaddr, uint8_t addr);
double adc_convert(uint32_t baseaddr, uint8_t chan);

#endif // ADC_H_
