This folder is where FSO scripts are to be stored and executed. 

********************************************************
DO NOT EXECUTE SCRIPTS OUTSIDE OF THE SCRIPT ENVIRONMENT
********************************************************
