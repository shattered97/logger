/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : reg
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-10-28
--------------------------------------------------------------------------------
-- Description: Driver to access FPGA registers over the PCIe interface
------------------------------------------------------------------------------*/

#ifndef REG_H_
#define REG_H_

#include <stdint.h>

uint32_t reg_rd(uint32_t addr);
void reg_wr(uint32_t addr, uint32_t data);
void reg_fpga_info();

#endif /* REG_H_ */
