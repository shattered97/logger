#!/bin/bash

startFrameGrabber() 
{
    gnome-terminal --tab --title="Frame Grabber" -- ros2 run frame_grabber pfg_node 
}

startMirrorActuation()
{
    gnome-terminal --tab --title="Mirror Ctl" --  ros2 run mirror_actuation mirror_node_new 
}

startCalMirror()
{
    gnome-terminal --tab --title="Calibrate Mirror" -- ros2 run fso_tools calMirror_node
}

startFrameGrabber
startMirrorActuation
startCalMirror

PS3="
 Action: "

options=("Find Center of FOV"
         "Find Top Left of FOV" 
         "Find Top Right of FOV"
         "Find Bottom Left of FOV"
         "Find Bottom Right of FOV"
         "Go to Mirror Home"
         "CalibrationV1"
         "CalibrationV2"
         "Stop Calibration"
         "Restart ALL"
         "Restart Frame Grabber"
         "Restart Mirror CTL"
         "Restart Calibrate Mirror"
         "quit")

select opt in "${options[@]}"
do
    case $opt in
    "Find Center of FOV")
        ros2 param set /calMirror_node findCenter true
        ;;
    "Find Top Left of FOV")
        ros2 param set /calMirror_node findTopLeft true
        ;;
    "Find Top Right of FOV")
        ros2 param set /calMirror_node findTopRight true
        ;;
    "Find Bottom Left of FOV")
        ros2 param set /calMirror_node findBottomLeft true
        ;;
    "Find Bottom Right of FOV")
        ros2 param set /calMirror_node findBottomRight true
        ;;
    "Go to Mirror Home")
        ros2 param set /calMirror_node goToMirrorHome true
        ;;
    "CalibrationV1") 
        ros2 param set /calMirror_node buildCalTable true
        ;;
    "CalibrationV2")
        ros2 param set /calMirror_node buildCalTableV2 true
        ;;
    "Stop Calibration")
        ros2 param set /calMirror_node buildCalTable false
        ros2 param set /calMirror_node buildCalTableV2 false
        ;;
    "Restart ALL")
        startFrameGrabber
        startMirrorActuation
        startCalMirror
        ;;
    "Restart Frame Grabber")
        startFrameGrabber
        ;;
    "Restart Mirror CTL")
        startMirrorActuation
        ;;
    "Restart Calibrate Mirror")
        startCalMirror
        ;;
    quit)
        break
        ;; 
    *) 
        echo "PEBKAC: $REPLY"
        ;;
    esac
done




