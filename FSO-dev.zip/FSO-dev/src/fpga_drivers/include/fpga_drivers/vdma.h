/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : vdma
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-12-11
--------------------------------------------------------------------------------
-- Description: Driver for FPGA Video DMA block
------------------------------------------------------------------------------*/

#ifndef VDMA_H_
#define VDMA_H_

#include <stdint.h>

// Number of frames buffers defined by the FPGA IP block. This should only be
// changed on new FPGA builds.
#define VDMA_NUM_FRAME_BUF 2

void vdma_start(uint32_t baseaddr, uint32_t hsize, uint32_t vsize);
void vdma_stop(uint32_t baseaddr);
void vdma_soft_reset(uint32_t baseaddr);
uint32_t vdma_get_status(uint32_t baseaddr);
void vdma_clear_status(uint32_t baseaddr);
int vdma_set_buf_addr(uint32_t baseaddr, uint32_t buf_addr, uint32_t buf_idx);


//
// Get the frame pointer number that the FPGA is currently writing to.
// The FPGA writes frames sequentially, so 0, 1, 2, 3, ...
// If frames are defined to have different buffer addresses (using the vdma_set_buf_addr
// function), then they will be stored in different locations. If they are defined
// to all have the same address, then new frames will simply overwrite old frames, 
// and it will appear as if there's only one frame buffer.
//
// NOTICE! The base address that this function takes is different from the vdma
// base address. I wish it wasn't this way, but this was fastest and easiest way
// to get this information to software... Sorry...
//
// This returns a number in the range of 0 to VDMA_NUM_FRAME_BUF - 1
uint32_t vdma_get_wptr(uint32_t wptr_baseaddr);

#endif /* VDMA_H_ */
