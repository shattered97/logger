#include <cstdio>

#include "rclcpp/rclcpp.hpp"

#include "timer/timer.h"
#include "../../custom_interfaces/custom_dt.h"

#include "custom_interfaces/srv/edfa_reset.hpp"
#include "std_srvs/srv/empty.hpp"


#include <libserial/SerialPort.h>


using namespace std::chrono_literals;

class EDFA : public rclcpp::Node
{
  public:
    EDFA() : Node("edfa_ctl_node")
    {
      initialization(); 

      parameter_callback_handle = this->add_on_set_parameters_callback(std::bind(&EDFA::parameter_change_callback, this, std::placeholders::_1));
      srvReset_callback_handle = this->create_service<std_srvs::srv::Empty>("edfa_reset", std::bind(&EDFA::srvResetCallback, this, std::placeholders::_1, std::placeholders::_2));
      srvStatus_callback_handle = this->create_service<std_srvs::srv::Empty>("edfa_status", std::bind(&EDFA::srvStatusCallback, this, std::placeholders::_1, std::placeholders::_2));
      srvEdfaOff_callback_handle = this->create_service<std_srvs::srv::Empty>("edfa_off", std::bind(&EDFA::srvEdfaOffCallback, this, std::placeholders::_1, std::placeholders::_2));
      srvEdfaOn_callback_handle = this->create_service<std_srvs::srv::Empty>("edfa_on", std::bind(&EDFA::srvEdfaOnCallback, this, std::placeholders::_1, std::placeholders::_2));
      srvEdfaGetPwr_callback_handle = this->create_service<std_srvs::srv::Empty>("edfa_get_pwr", std::bind(&EDFA::srvGetPwr, this, std::placeholders::_1, std::placeholders::_2));
      srvGetTemp_callback_handle = this->create_service<std_srvs::srv::Empty>("edfa_getTemp", std::bind(&EDFA::srvGetTmp, this, std::placeholders::_1, std::placeholders::_2));

      //watchDogTimer = this->create_wall_timer(1000ms, std::bind(&EDFA::watchDog, this));
    }

    ~EDFA()
    {
      sendCmd(cmd_edfa_off);
    }

    private:

    bool connect_serial()
    {
      bool success = false;
      std::string nodeName = this->get_name();
      std::string nodePort = this->get_parameter("comm_port").as_string();

      try 
      {
       //Close the serial if open
        if(edfa.IsOpen())
        {
          edfa.Close();
        }

        RCLCPP_INFO(this->get_logger(), "Trying to open %s Serial Port:  %s", nodeName.c_str(), nodePort.c_str());

        edfa.Open(this->get_parameter("comm_port").as_string());
        edfa.SetBaudRate(LibSerial::BaudRate::BAUD_19200);  
        edfa.SetCharacterSize(LibSerial::CharacterSize::CHAR_SIZE_8);
        edfa.SetStopBits(LibSerial::StopBits::STOP_BITS_1);
        edfa.SetParity(LibSerial::Parity::PARITY_NONE);
        edfa.SetFlowControl(LibSerial::FlowControl::FLOW_CONTROL_NONE);
      
        if(edfa.IsOpen())
        {
          success = true;
          nodeState = status::state::running;
          RCLCPP_INFO(this->get_logger(), "%s Serial Port %s successfully opened", nodeName.c_str(), nodePort.c_str());
        }
        else
        {
          success = false;
          nodeState = status::state::error;
          RCLCPP_WARN(this->get_logger(), "%s Serial Port %s was not opened", nodeName.c_str(), nodePort.c_str());
        }

        return success;
      }

      catch (const LibSerial::NotOpen&)
      {
        success = false;
        nodeState = status::state::error;
        RCLCPP_WARN(this->get_logger(), "%s Serial Port %s not open", nodeName.c_str(), nodePort.c_str());
      }
      catch (const LibSerial::OpenFailed&)
      {
        success = false;
        nodeState = status::state::error;
        RCLCPP_WARN(this->get_logger(), "%s Serial Port %s failed to open", nodeName.c_str(), nodePort.c_str());
      }
      catch (const LibSerial::AlreadyOpen&)
      {
        success = true;
        nodeState = status::state::error;
        RCLCPP_WARN(this->get_logger(), "%s Serial Port %s is already open", nodeName.c_str(), nodePort.c_str());
      }
      return success;
    }

    void declareParams()
    {
      nodeCommType = status::commType::serial;
      nodeState = status::state::initializating;  
      this->declare_parameter("comm_port", "/dev/ttyUSB0"); 
      this->declare_parameter("aopc_value", 25.0);
      this->declare_parameter("saopc_value", 25.0);
      this->declare_parameter("lazer_on", false);
      this->declare_parameter("gaopc", false); 
      this->declare_parameter("get_status", false);

      aopc_value = this->get_parameter("aopc_value").as_double();
      saopc_value = this->get_parameter("saopc_value").as_double();            
    }

    bool get_resp(std::string &rtnValue, bool silent = false)
    {
      bool success = true;
      std::string nodeName = this->get_name();
      std::string nodePort = this->get_parameter("comm_port").as_string();

      LibSerial::DataBuffer buffer;
      try
      { 
        edfa.Read(buffer, 0, 1000);
      }
      catch(LibSerial::ReadTimeout&)
      {
        for (size_t i = 0 ; i < buffer.size() ; i++)
        {
            rtnValue.push_back(buffer.at(i));
        }
        edfa.FlushIOBuffers();
      }
      catch (const LibSerial::NotOpen&)
      {
        success = false;
        nodeState = status::state::error;
        RCLCPP_WARN(this->get_logger(), "%s Serial Port %s not open", nodeName.c_str(), nodePort.c_str());
      }
      catch (const LibSerial::OpenFailed&)
      {
        success = false;
        nodeState = status::state::error;
        RCLCPP_WARN(this->get_logger(), "%s Serial Port %s failed to open", nodeName.c_str(), nodePort.c_str());
      }
      catch (const LibSerial::AlreadyOpen&)
      {
        success = true;
        nodeState = status::state::error;
        RCLCPP_WARN(this->get_logger(), "%s Serial Port %s is already open", nodeName.c_str(), nodePort.c_str());
      }

      if(!silent)
      {
        std::string strSuccess = (success == 0) ? "false" : "true";
        RCLCPP_INFO(this->get_logger(), "Read was successful:  %s", strSuccess.c_str());
        RCLCPP_INFO(this->get_logger(), "Response: %s", rtnValue.c_str());
      }
    }
    
    void initializeFlags()
    {    
      lazer_on  = this->get_parameter("lazer_on").as_bool();
      gaopc     = this->get_parameter("gaopc").as_bool();
      getStatus = this->get_parameter("get_status").as_bool();
    }

    void initialization()
    {

      declareParams();
      initializeFlags();

      std::string cmd;

      if(!connect_serial())
      {
        nodeState = status::state::error;
      }
      else
      {
        sleep(1);  //allow everything to come on line
        sendCmd(cmd_reset);
        sendCmd(cmd_gmode);
        std::string cmd = cmd_saopc + std::to_string(saopc_value);
        sendCmd(cmd);
   
        //ensure lazer is set to default setting when it comes on
        cmd = cmd_aopc + std::to_string(saopc_value);
        sendCmd(cmd);
      }
    }

    bool sendCmd(std::string cmd, bool silent = false)
    {    
      bool success = false; 
      try
      {     
        if(edfa.IsOpen())
        {
          edfa.FlushIOBuffers();  //Clean up buffers before we send a cmd

          std::string::iterator it;
          for(it = cmd.begin(); it != cmd.end(); ++it)
          {  
            edfa.WriteByte(*it);
          }
          edfa.WriteByte('\r');
          //edfa.WriteByte('\n');  //terminate char causes issues 
          edfa.DrainWriteBuffer();  //wait for command to sent
          success = true;
        } 
        else
        {
          cmd = "Not Connected!";
          nodeState == status::state::reconnecting;
          success = false;
        }

        if(!silent)
        {
          std::string strSuccess = (success == 0) ? "false" : "true";
          RCLCPP_INFO(this->get_logger(), "Cmd Sent:  %s | Was Successful: %s", cmd.c_str(), strSuccess.c_str());
        }

        while(!edfa.IsDataAvailable())
        {
          usleep(100);
        }
        std::string test;
        get_resp(test);  //rtn value not used
      }
      catch (const LibSerial::NotOpen&)
      {
        success = false;
        RCLCPP_WARN(this->get_logger(), "%s Serial Port %s not opened", this->get_name(), this->get_parameter("comm_port").as_string().c_str());
        nodeState = status::state::notConnected;
        std::string msg = "Command failed:  " + cmd;
        reconnect(3);
      }
      catch (const LibSerial::OpenFailed&)
      {
        success = false;
        RCLCPP_WARN(this->get_logger(), "%s Serial Port %s failed to open", this->get_name(), this->get_parameter("comm_port").as_string().c_str());
        nodeState = status::state::notConnected;
        std::string msg = "Command failed:  " + cmd;
        reconnect(3);
      }
      catch (const LibSerial::AlreadyOpen&)
      {
        success = true;
        //RCLCPP_WARN(this->get_logger(), "%s Serial Port %s already open", port->second->status.msgName.c_str(), port->second->status.commPort.c_str());
      }
      
      return success;
    }

    rcl_interfaces::msg::SetParametersResult parameter_change_callback(const std::vector<rclcpp::Parameter> &params)
    {
      auto result = rcl_interfaces::msg::SetParametersResult();
      result.successful = true;

        for(const auto &param : params)
        {
          if(param.get_name() == "aopc_value" && param.as_double())
          {
            aopc_value = param.as_double();
            std::string cmd = cmd_aopc + std::to_string(aopc_value);
            sendCmd(cmd);
          }

          else if(param.get_name() == "saopc_value" && param.get_type() == rclcpp::ParameterType::PARAMETER_DOUBLE)
          {
            saopc_value = param.as_double();
            std::string cmd = cmd_saopc + std::to_string(saopc_value);
          }
          else if(param.get_name() == "lazer_on" && param.get_type() == rclcpp::ParameterType::PARAMETER_BOOL)
          {
            lazer_on = param.as_bool();
            if(lazer_on)
            {
              sendCmd(cmd_edfa_on);
            }
            else
            {
              sendCmd(cmd_edfa_off);
            }
          }
          else
          {
            result.successful = false;
            result.reason = "Parmeter not supported";
          }
        }

      return result;
    }

    bool reconnect(int numRetries)
    {
      bool success = false;
      std::string name = this->get_name();
      std::string port = this->get_parameter("comm_port").as_string();
      
      for (int i = 1; i <= numRetries; i++)
      {
        RCLCPP_WARN(this->get_logger(), "Trying to reconnect, attempt %d", i);
        if(connect_serial())
        {
            success = true;
            break;
        }
        else
        {
            usleep(10 * 1000);
            if(i == numRetries)
            {
            success = false;
            RCLCPP_ERROR(this->get_logger(), "%s failed to reconnect to port:  %s", name.c_str(), port.c_str());
            }
        }
      }
      return success;
    } 

    void srvEdfaOffCallback(std::shared_ptr<std_srvs::srv::Empty::Request>,
                    std::shared_ptr<std_srvs::srv::Empty::Response>)
    {
      sendCmd(cmd_edfa_off);
    }

    void srvEdfaOnCallback(std::shared_ptr<std_srvs::srv::Empty::Request>,
                   std::shared_ptr<std_srvs::srv::Empty::Response>)
    {
      sendCmd(cmd_edfa_on);
    }

    void srvStatusCallback(std::shared_ptr<std_srvs::srv::Empty::Request>,
                           std::shared_ptr<std_srvs::srv::Empty::Response>)
    {
      sendCmd(cmd_fline);                     
    }

    void srvResetCallback(std::shared_ptr<std_srvs::srv::Empty::Request>,
                          std::shared_ptr<std_srvs::srv::Empty::Response>)
    {
       sendCmd(cmd_reset);
    }   

    void srvGetPwr(std::shared_ptr<std_srvs::srv::Empty::Request>,
                   std::shared_ptr<std_srvs::srv::Empty::Response>)
    {
      sendCmd(cmd_gaopc);
    }

    void srvGetTmp(std::shared_ptr<std_srvs::srv::Empty::Request>,
                   std::shared_ptr<std_srvs::srv::Empty::Response>)
    {
      sendCmd(cmd_gcta);
      sendCmd(cmd_gbtemp);
    }

    void watchDog()
    {
      //Keep this code short - it will tie up Node
      //Move to a thread at some point
      sendCmd(cmd_fline);

      if(nodeState == status::state::reconnecting)
      {
        RCLCPP_INFO(this->get_logger(), MSG_WD_FIRED, "reconnect");
        nodeState = (reconnect(3)) ? status::state::running : status::state::error; 
      }
    }

    utility::Timer timer;

    LibSerial::SerialPort edfa;

    status::commType nodeCommType;
    status::state nodeState;
      
    rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;
    rclcpp::TimerBase::SharedPtr watchDogTimer;

    rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvReset_callback_handle;
    rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvStatus_callback_handle;
    rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvEdfaOn_callback_handle;
    rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvEdfaOff_callback_handle;
    rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvEdfaGetPwr_callback_handle;
    rclcpp::Service<std_srvs::srv::Empty>::SharedPtr srvGetTemp_callback_handle;
    

    double aopc_value;
    double saopc_value;

    bool lazer_on;
    bool gaopc;
    bool getStatus;
    bool reset;

};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<EDFA>());
  rclcpp::shutdown();
  return 0;
}

