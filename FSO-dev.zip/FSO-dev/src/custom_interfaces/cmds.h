//Vision Component Camera

namespace mirror
{
  // put command addresses here
  #define SYS_STATUS_REG      0x1007    // Status
  #define MISC_SETT_ADDR      0x2526    // Closed Loop Register
  #define CLOSED_LOOP_XY      0x2         // Enable Closed Loop for X/Y
  #define OPEN_LOOP_XY        0x0          //
  #define CONTROL_FLOW_X      0x4000
  #define CONTROL_FLOW_Y      0x4005
  #define CURRENT_X           0x5000
  #define CURRENT_Y           0x5100
  #define STATIC_REG_X        0x5002      // Specify static X/Y Input address 
  #define STATIC_REG_Y        0x5102      //
};

