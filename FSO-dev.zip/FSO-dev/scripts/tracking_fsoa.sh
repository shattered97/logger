#!/bin/bash

ros2 launch /opt/fso_prj/FSO/scripts/tracking_fsoa.yaml