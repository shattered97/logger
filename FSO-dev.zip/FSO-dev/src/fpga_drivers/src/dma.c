/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : dma
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-12-04
--------------------------------------------------------------------------------
-- Description: Driver for Xilinx PCIe DMA
------------------------------------------------------------------------------*/

#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>

//#include "/opt/fso_prj/FSO/install/fpga_drivers/include/fpga_drivers/dma.h"
#include "fpga_drivers/dma.h"

// Device driver paths
#define H2C_DEVICE_PATH "/dev/xdma0_h2c_0"
#define C2H_DEVICE_PATH "/dev/xdma0_c2h_0"

/*
 * On Linux, write() (and similar system calls) will transfer at most
 * 	0x7ffff000 (2,147,479,552) bytes, returning the number of bytes
 *	actually transferred.  (This is true on both 32-bit and 64-bit
 *	systems.)
 */
#define RW_MAX_SIZE	0x7ffff000


// Read a file into a C buffer
static ssize_t read_to_buffer(char *fname, int fd, uint8_t *buffer, uint64_t size, uint64_t base)
{
	ssize_t rc;
	uint64_t count = 0;
	uint8_t *buf = buffer;
	off_t offset = base;
	int loop = 0;

	while (count < size) {
		uint64_t bytes = size - count;

		if (bytes > RW_MAX_SIZE)
			bytes = RW_MAX_SIZE;

		if (offset) {
			rc = lseek(fd, offset, SEEK_SET);
			if (rc != offset) {
				fprintf(stderr, "%s, seek off 0x%lx != 0x%lx.\n",
					fname, rc, offset);
				perror("seek file");
				return -EIO;
			}
		}

		/* read data from file into memory buffer */
		rc = read(fd, buf, bytes);
		if (rc < 0) {
			fprintf(stderr, "%s, read 0x%lx @ 0x%lx failed %ld.\n",
				fname, bytes, offset, rc);
			perror("read file");
			return -EIO;
		}

		count += rc;
		if (rc != bytes) {
			fprintf(stderr, "%s, Read underflow 0x%lx/0x%lx @ 0x%lx.\n",fname, rc, bytes, offset);
			break;
		}

		buf += bytes;
		offset += bytes;
		loop++;
	}

	if (count != size && loop) {
		fprintf(stderr, "%s, read underflow 0x%lx/0x%lx.\n", fname, count, size);
  }
			
	return count;
}


// Write a C buffer to a file
static ssize_t write_from_buffer(char *fname, int fd, uint8_t *buffer, uint64_t size, uint64_t base)
{
	ssize_t rc;
	uint64_t count = 0;
	uint8_t *buf = buffer;
	off_t offset = base;
	int loop = 0;

	while (count < size) {
		uint64_t bytes = size - count;

		if (bytes > RW_MAX_SIZE)
			bytes = RW_MAX_SIZE;

		if (offset) {
			rc = lseek(fd, offset, SEEK_SET);
			if (rc != offset) {
				fprintf(stderr, "%s, seek off 0x%lx != 0x%lx.\n",
					fname, rc, offset);
				perror("seek file");
				return -EIO;
			}
		}

		/* write data to file from memory buffer */
		rc = write(fd, buf, bytes);
		if (rc < 0) {
			fprintf(stderr, "%s, write 0x%lx @ 0x%lx failed %ld.\n",
				fname, bytes, offset, rc);
			perror("write file");
			return -EIO;
		}

		count += rc;
		if (rc != bytes) {
			fprintf(stderr, "%s, write underflow 0x%lx/0x%lx @ 0x%lx.\n",
				fname, rc, bytes, offset);
			break;
		}
		buf += bytes;
		offset += bytes;

		loop++;
	}	

	if (count != size && loop) {
		fprintf(stderr, "%s, write underflow 0x%lx/0x%lx.\n", fname, count, size);
  }

	return count;
}


// Read from a contiguous FPGA memory buffer.
// Given a start_addr and size, this function reads FPGA memory over the pcie 
// interface and stores it in buf, which is accessable by the host.
// NOTICE: The caller must allocate buf on a 4k memory boundry
// Returns 0 on success and 1 on failure
int dma_rd(uint64_t start_addr, uint8_t * buf, uint64_t size)
{
	// Open the xdma driver device
	int fpga_fd = open(C2H_DEVICE_PATH, O_RDWR);
	if (fpga_fd < 0) {
		fprintf(stderr, "Unable to open dma device %s, %d.\n", H2C_DEVICE_PATH, fpga_fd);
		return 1;
	}

	// Read buffer from AXI MM address using SGDMA 
  ssize_t bytes_done = 0;
  bytes_done = read_to_buffer(H2C_DEVICE_PATH, fpga_fd, buf, size, start_addr);
  if (bytes_done < 0) {
    fprintf(stderr, "DMA write error\n");
    close(fpga_fd);
    return 1;
  } else if (bytes_done < size) {
    fprintf(stderr, "DMA underflow error\n");
    close(fpga_fd);
    return 1;
  }

  close(fpga_fd);
  return 0;
}


// Write to a contiguous FPGA memory buffer.
// Given a start_addr, size, and buf, this function writes the host buf to
// FPGA memory over the pcie interface. 
// NOTICE: The caller must allocate buf on a 4k memory boundry
// Returns 0 on success and 1 on failure
int dma_wr(uint64_t start_addr, uint8_t * buf, uint64_t size)
{
	// Open the xdma driver device
	int fpga_fd = open(H2C_DEVICE_PATH, O_RDWR);
	if (fpga_fd < 0) {
		fprintf(stderr, "Unable to open dma device %s, %d.\n", H2C_DEVICE_PATH, fpga_fd);
		return 1;
	}

	// Write buffer to AXI MM address using SGDMA 
  ssize_t bytes_done = 0;
  bytes_done = write_from_buffer(H2C_DEVICE_PATH, fpga_fd, buf, size, start_addr);
  if (bytes_done < 0) {
    fprintf(stderr, "DMA write error\n");
    close(fpga_fd);
    return 1;
  } else if (bytes_done < size) {
    fprintf(stderr, "DMA underflow error\n");
    close(fpga_fd);
    return 1;
  }

  close(fpga_fd);
  return 0;
}
