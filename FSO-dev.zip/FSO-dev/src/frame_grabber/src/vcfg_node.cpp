#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <libserial/SerialPort.h>
#include <thread>
#include <filesystem>
#include <iostream>
#include <fstream>

#include "timer/timer.h"
extern "C"
{
#include "fpga_drivers/reg.h"
#include "fpga_drivers/vdma.h"
#include "fpga_drivers/xiic.h"
#include "fpga_drivers/cam.h"
#include "fpga_drivers/dma.h"
}

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/features2d.hpp>
#include <image_transport/image_transport.hpp>
#include "sensor_msgs/msg/image.hpp"
#include <opencv2/core/hal/interface.h>
#include <opencv2/core/types.hpp>
#include <opencv2/imgproc/imgproc.hpp>

/////////////////////////////////
// NODE HPP FILE HERE
/////////////////////////////////
#include "../../custom_interfaces/custom_dt.h"
#include "../../custom_interfaces/cmds.h" 
#include "custom_interfaces/msg/heart_beat.hpp"  


#include "rocket.hpp"

/*
 * CLASS NAME  
 * 
 * ROS2 PARAMETERS
 * 
 * 
 * NOTES
 * 
 */

using namespace std::chrono_literals;
using std::placeholders::_1;

class VCFG : public rclcpp::Node
{
  public:
  VCFG() : Node("vcfg_node")
  {
    bool success = false;

    success = initialization();
    
    std::string statusMsgName = this->get_name();
    status = this->create_publisher<custom_interfaces::msg::HeartBeat>(statusMsgName, 10);

    connections += { test.connect<&VCFG::testFunction>(this) };

    heartBeatTimer = this->create_wall_timer(1000ms, std::bind(&VCFG::heartBeat, this));
    watchDogTimer  = this->create_wall_timer(100ms, std::bind(&VCFG::watchDog, this));

    parameter_callback_handle = this->add_on_set_parameters_callback(std::bind(&VCFG::parameter_change_callback, this, _1));

    rawImgPub = this->create_publisher<sensor_msgs::msg::Image>("RawImage", 10);

    uint16_t a = getHMAX();
    uint32_t b = getSHS();
    uint32_t c = getVMAX();

    std::cout << "HMAX: " << a << std::endl;
    std::cout << "SHS: " << b << std::endl;
    std::cout << "VMAX: " << c << std::endl;

    uint8_t Byte4 = 0x00;
    uint8_t Byte3 = 0x00;
    uint8_t Byte2 = 0x00;
    uint8_t Byte1 = 0x00;

    uint32_t test16 = 0xDEADBEAF;

    convertFrom32_bit(test16, Byte4, Byte3, Byte2, Byte1);
    std::cout << "Bytes:" << static_cast<int>(Byte4) << static_cast<int>(Byte3)<< static_cast<int>(Byte2) << ":" <<  static_cast<int>(Byte1) << std::endl;

    if(success)
    {
      grabThread = std::thread(&VCFG::grabImageThread, this);
    }
    else
    {
      RCLCPP_WARN(this->get_logger(), MSG_VC_INITIAL_FAILED, CAM_MOD);
    }
  }

  ~VCFG()
  { 
    grabThreadingRunning = false;
    grabThread.join();
    vdma_stop(VDMA_BASEADDR);
    cam_wr_reg(I2C_BASEADDR, CAM_SEN, 0x7000, 0); // Write 1 to this camera register to enable it
  }

  rocket::signal<void()> test;
  rocket::signal<void()> grabImageSig;

  void testFunction()
  {
    std::cout << "Signal Received" << std::endl;
  }

  private:

  void setExposure()
  {
    //microSecond Exposure = (vmax - shr) * hmax / clockSpeed
    //shr = vmax - (microSecond Exposure * CS / hmax) uses ceil for shr value

    uint32_t calcSHR = std::ceil((EXPOSURE_US * CLOCK_MHZ / getHMAX()));
    
  }

  void configureImageSize()
  {
    if(binning)
    {
      VIDEO_HEIGHT = this->get_parameter("VIDEO_HEIGHT").as_int() / 2;
      VIDEO_WIDTH  = this->get_parameter("VIDEO_WIDTH").as_int() / 2;
    }
    else
    {
      VIDEO_HEIGHT = this->get_parameter("VIDEO_HEIGHT").as_int();
      VIDEO_WIDTH  = this->get_parameter("VIDEO_WIDTH").as_int();
    }

    FRAME_SIZE_BYTES = VIDEO_HEIGHT * VIDEO_WIDTH;
  }

  uint16_t covertTo16_bit(uint8_t byte2, uint8_t byte1)
  {
    return static_cast<int16_t>(static_cast<int>(byte2) << 8) | static_cast<int16_t>(static_cast<int>(byte1));
  }

  uint32_t convertTo32_bit(uint8_t byte4, uint8_t byte3, uint8_t byte2, uint8_t byte1)
  {
    return static_cast<int32_t>(static_cast<int>(byte4) << 24) | static_cast<int32_t>(static_cast<int>(byte3)) << 16 | static_cast<uint32_t>(static_cast<int>(byte2)) << 8 | static_cast<uint32_t>(static_cast<int>(byte1));
  }

  void convertFrom16_bit(uint16_t input, uint8_t &byte2, uint8_t &byte1 )
  {
    byte2 = (input >> 8) & 0xFF;  // Shift right by 8 bits and mask with 0xFF to get the high byte
    byte1 = input & 0xFF;         // Mask with 0xFF to get the low byte
  }

  void convertFrom32_bit(uint32_t input, uint8_t &byte4, uint8_t &byte3, uint8_t &byte2, uint8_t& byte1 )
  {
    byte4 = (input >> 24) & 0xFFF;
    byte3 = (input >> 16) & 0xFFF;
    byte2 = (input >>  8) & 0XFFF;
    byte1 =  input && 0xFFF;
  }

  void declareParams()
  {
    nodeState = status::state::unknown; 
    nodeCommType = status::commType::pcie;
    datafield = "empty";

    //0 ->7fff ffff hgt * width (1 byte per pixel)  one block per image buffer up to 4
    
    //Parameters not exposed to user for updating
    //Launch file will update addresses to support multiple camera                                                 
    this->declare_parameter("FPGA_FRAME_BUF_BASEADDR", 0x00000000);  //add buffer add new address - increase by size of image frame
    this->declare_parameter("VDMA_BASEADDR", 0x20000);  
    this->declare_parameter("I2C_BASEADDR", 0x90000);
    this->declare_parameter("VIDEO_WIDTH", 1440);  
    this->declare_parameter("VIDEO_HEIGHT", 1080);  
    this->declare_parameter("FRAME_SIZE_BYTES", this->get_parameter("VIDEO_HEIGHT").as_int() * this->get_parameter("VIDEO_WIDTH").as_int());
    this->declare_parameter("NUM_FRAMES", 1);
    this->declare_parameter("RUN_GRAB_THREAD", true);

    //Default mode - 8bit, 2 MIPI Lanes, Full resolution
    //HMAX = 336, Clock = 74.25Mhz, VMAX = 1130, MIPI burst Rate, 1.5Ghz (Frame Rate = 195fps)
    //Binning mode Default - 8bit, 2 MIPI Lanes, 720 x 540
    //HMAX = 238, Clock = 74.25, VMAX = 586, MIPI burst Rate 1.5GHz (Frame Rate = 532fps)
    //Change these at your own risk........
    this->declare_parameter("VMAX", 1130);
    this->declare_parameter("VMAX_BINNING", 586);
    this->declare_parameter("CLOCK_MHZ", 74.25);
    this->declare_parameter("HMAX", 336);
    this->declare_parameter("HMAX_BINNING", 238);

    //Parameters that can be updated by the user
    this->declare_parameter("EXPOSURE_US", 100);
    this->declare_parameter("BINNING", false);

    //Assign Parameters to private data members for ease of use and handle ROS2 issue where the param callback
    //does not update the first time with "ros2 param set /<node> <param> <value>" command
    FPGA_FRAME_BUF_BASEADDR = this->get_parameter("FPGA_FRAME_BUF_BASEADDR").as_int();
    VDMA_BASEADDR           = this->get_parameter("VDMA_BASEADDR").as_int();
    I2C_BASEADDR            = this->get_parameter("I2C_BASEADDR").as_int();
    VIDEO_WIDTH             = this->get_parameter("VIDEO_WIDTH").as_int();
    VIDEO_HEIGHT            = this->get_parameter("VIDEO_HEIGHT").as_int();
    FRAME_SIZE_BYTES        = this->get_parameter("FRAME_SIZE_BYTES").as_int(); 
    NUM_FRAMES              = this->get_parameter("NUM_FRAMES").as_int();
    VMAX                    = this->get_parameter("VMAX").as_int();
    VMAX_BINNING            = this->get_parameter("VMAX_BINNING").as_int();
    CLOCK_MHZ               = this->get_parameter("CLOCK_MHZ").as_double();
    HMAX                    = this->get_parameter("HMAX").as_int();
    HMAX_BINNING            = this->get_parameter("HMAX_BINNING").as_int();
    EXPOSURE_US             = this->get_parameter("EXPOSURE_US").as_int();

    grabThreadingRunning = this->get_parameter("RUN_GRAB_THREAD").as_bool();
    binning = this->get_parameter("BINNING").as_bool();
  }

  void displayRegisters()
  {
    int modeInit     = cam_rd_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_INIT_ADDR);
    int modStatus    = cam_rd_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_STATUS_ADDR);
    int mode         = cam_rd_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_MODE_ADDR);
    int vmaxLow      = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_VMAX_LOW_ADDR);
    int vmaxMid      = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_VMAX_MID_ADDR);
    int vmaxHig      = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_VMAX_HIG_ADDR);
    int hmaxLow      = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_HMAX_LOW_ADDR);
    int hmaxHig      = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_HMAX_HIG_ADDR);
    int shsLow       = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_SHS_LOW_ADDR);
    int shsMid       = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_SHS_MID_ADDR);
    int shsHig       = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_SHS_HIG_ADDR);
    int senEnabled   = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_ENABLE_ADDR);

    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_MOD_INIT_ADDR, "Reset|Init", modeInit);
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_MOD_STATUS_ADDR, "Module Status", modStatus);
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_MOD_MODE_ADDR, "Mode: ", mode);
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_SEN_VMAX_LOW_ADDR, " VMAX Low:", vmaxLow);
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_SEN_VMAX_MID_ADDR, " VMAX Mid:", vmaxMid);
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_SEN_VMAX_HIG_ADDR, "VMAX High:", vmaxHig);
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_SEN_HMAX_LOW_ADDR, " HMAX Low:", hmaxLow);
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_SEN_HMAX_HIG_ADDR, "HMAX High:", hmaxHig);
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_SEN_SHS_LOW_ADDR, "  SHS Low:", shsLow );
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_SEN_SHS_MID_ADDR, "  SHS Mid:", shsMid );
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_SEN_SHS_LOW_ADDR, "  SHS Hig:", shsHig );
    RCLCPP_INFO(this->get_logger(), REG_READ, CAM_SEN_ENABLE_ADDR, "Sensor Enable:", senEnabled); 
    std::cout << std::endl;
  }

  void heartBeat()
  {
    publishStatus(datafield);
  }

  bool initialization()
  {
    //Order is very important here...
    //DMA and I2C changes must be done properly
    //Do not change order unless you have fully tested the change
    bool success = false;
    nodeState = status::state::initializating;

    RCLCPP_INFO(this->get_logger(), "INTIALIZATION PROCESS STARTED");
    declareParams();
    initializeFlags();

    success = initializeCam();
   
    if(success)
    {
      nodeState = status::state::running;
    }
    else
    {
      nodeState = status::state::error;
    }

    timer.reset();
    timer.start();
    return success;
  }

  bool initializeCam()
  {
    displayRegisters();
    configureImageSize();
    initializeDMA();  
    initializeI2C();  

    int senEnabled   = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_ENABLE_ADDR);
    int modStatus    = cam_rd_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_STATUS_ADDR);

    if(senEnabled == 0x01 && modStatus == 0x80)
    {
      return true;
    }
    else
    {
      return false;

    }
  }

  bool initializeDMA()
  {
    RCLCPP_INFO(this->get_logger(), "INITIALIZATING DMA");

    //FPG Frame Buffer Addresses, max size is 0x7FFF FFFF
    //Second Frame Buffer can be added by increasing the memory location by Height * Width of the Image.
    //No Frame Sync is possible due FS-295 Xilinx PCIe Driver issue, DMA registers
    //We can not read the Xilinx DMA registers without an error
    vdma_stop(VDMA_BASEADDR);
    vdma_set_buf_addr(VDMA_BASEADDR, FPGA_FRAME_BUF_BASEADDR, 0);  
    vdma_set_buf_addr(VDMA_BASEADDR, FPGA_FRAME_BUF_BASEADDR, 1);
    vdma_start(VDMA_BASEADDR, VIDEO_WIDTH, VIDEO_HEIGHT );
    vdma_clear_status(VDMA_BASEADDR);
    return true;
  }

  bool initializeI2C()
  {
    bool success = true;
    RCLCPP_INFO(this->get_logger(), "INITIALIZATING I2C");

    cam_wr_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_INIT_ADDR, 1);  //hold camera module in reset
   
    //Set register values that require reset here - when the camera comes out of reset it will activate those settings. 
  
    if(binning)
    {
      mode_binning_default();
    }
    else
    {
      mode_default();
    }

    //Any time the module is reset is takes time to reset due to what ever the camera
    //microcontroler is doing in the background.  
    cam_wr_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_INIT_ADDR, 0);  //take camera module out of reset
    usleep(1000 * 500);                                       //Give camera time to react

    cam_wr_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_ENABLE_ADDR, 1);  //enable sensor
    displayRegisters();
    
    return success;
  }

  void initializeFlags()
  {

  }

  uint16_t getHMAX()
  {
    uint8_t lowHMAX = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_HMAX_LOW_ADDR);
    uint8_t higHMAX = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_HMAX_HIG_ADDR);

    uint16_t result = covertTo16_bit(higHMAX, lowHMAX);
    RCLCPP_INFO(this->get_logger(), UPDATE_REG, "HMAX: ", result, result);
    return result;

  }

  uint32_t getSHS()
  {
    uint8_t lowSHS = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_SHS_LOW_ADDR);
    uint8_t midSHS = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_SHS_MID_ADDR);
    uint8_t higSHS = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_SHS_HIG_ADDR);

    return convertTo32_bit(0x0, higSHS, midSHS, lowSHS);
  }

  uint32_t getVMAX()
  {
    uint8_t lowVMAX = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_VMAX_LOW_ADDR);
    uint8_t midVMAX = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_VMAX_MID_ADDR);
    uint8_t higVMAX = cam_rd_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_VMAX_HIG_ADDR);

    return convertTo32_bit(0x0, higVMAX, midVMAX, lowVMAX);
  }

  bool grabImageFromMemory(uint8_t * bufferPtr, int bufferNum, cv::Mat &cvImage_raw)
  {
    bool success = false;

    vdma_clear_status(VDMA_BASEADDR); //clear any errors in vdma

    for(unsigned i = 0; i < NUM_FRAMES; i++)
    {
      int frame = 1;  //default to false
      //frame = dma_rd(FPGA_FRAME_BUF_BASEADDR, bufferPtr, FRAME_SIZE_BYTES);

      if(bufferNum == 0)
      {
        frame = dma_rd(FPGA_FRAME_BUF_BASEADDR, bufferPtr, FRAME_SIZE_BYTES);
      }
      else if(bufferNum == 1)
      {
        frame = dma_rd(FPGA_FRAME_BUF_BASEADDR, bufferPtr, FRAME_SIZE_BYTES);
      }

      if(frame)
      {
        RCLCPP_WARN(this->get_logger(), MSG_VC_FAILED_TO_FRAME, CAM_MOD);
        success = false;
      }
      else
      {
        success = true;
      }
    }

    std::memcpy( cvImage_raw.ptr(), bufferPtr, (VIDEO_WIDTH * VIDEO_HEIGHT) );

    cv_bridge::CvImagePtr cv_ptr;
    sensor_msgs::msg::Image::SharedPtr rawImg = cv_bridge::CvImage(std_msgs::msg::Header(), "mono8", cvImage_raw).toImageMsg();
    rawImgPub->publish(*rawImg.get());

    cv::imshow("Test", cvImage_raw);
    cv::waitKey(1);
    return success;
  }

  void grabImageThread()
  {

    RCLCPP_INFO(this->get_logger(), MSG_VC_THREAD_STARTED, CAM_MOD);
    cv::namedWindow("Test", cv::WINDOW_KEEPRATIO);
    cv::startWindowThread();

    //Allocate Memeory - posix_memalign must be used to ensure the memory is in the proper format for the FPGA
    uint8_t * host_framebuf = nullptr;
    posix_memalign((void **)&host_framebuf, 4096, FRAME_SIZE_BYTES + 4096 );  //double frame buffer for second camera
    if(!host_framebuf)
    {
      RCLCPP_WARN(this->get_logger(), MSG_VC_DMA_MEM_ERROR, CAM_MOD, (long unsigned int)FRAME_SIZE_BYTES + 4096);
    }

    cv::Mat cvImage_raw;
    cvImage_raw.create(VIDEO_HEIGHT, VIDEO_WIDTH, CV_8UC1);

    uint8_t loopCount = 0;
    int numBuffers = 2;
    int bufferLoc = 0;

    //Infinite Loop to grab frames from camera running on new thread as not
    //to tie up the ROS2 spin
    while(grabThreadingRunning)
    {
      bufferLoc = loopCount % numBuffers;
      grabImageFromMemory(host_framebuf, bufferLoc, cvImage_raw);
      loopCount++;  //designed to roll over
    }

    vdma_stop(VDMA_BASEADDR);
    free(host_framebuf);  //Not handled by ROS must manually clean up
    host_framebuf = nullptr;
  }

  void mode_default()
  {
    RCLCPP_INFO(this->get_logger(), "MODE:  8bit, 2 lanes, streaming mode");
    cam_wr_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_MODE_ADDR, 0x00);  
  }

  void mode_binning_default()
  {
    RCLCPP_INFO(this->get_logger(), "MODE:  8bit, 2 lanes, streaming mode binning");
    cam_wr_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_MODE_ADDR, 0x0C);
    resetCam();
  }

  void publishStatus(std::string datafield)
  {
    auto msg       = custom_interfaces::msg::HeartBeat();
    msg.epoch      = timer.timeSinceEpoch_us();
    msg.node_state = (int)nodeState;
    msg.comm_type  = (int)nodeCommType;
    status->publish(msg);
  }

  void resetCam()
  {
    RCLCPP_INFO(this->get_logger(), "Reset Camera");
    //Must give the Camera's microcontroller time to do its magic.
    cam_wr_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_INIT_ADDR, 0x01);
    usleep(1000 * 1000);                                                  
    cam_wr_reg(I2C_BASEADDR, CAM_MOD, CAM_MOD_INIT_ADDR, 0x00);
    usleep(1000 * 1000); 

  }

  rcl_interfaces::msg::SetParametersResult parameter_change_callback(const std::vector<rclcpp::Parameter> &params){
    auto result = rcl_interfaces::msg::SetParametersResult();
    result.successful = true;

    for(const auto &param : params)
    {
      if(param.get_name() == "BINNING" && param.get_type() ==  rclcpp::ParameterType::PARAMETER_BOOL)
      {
        RCLCPP_INFO(this->get_logger(), "Can set this at run time, must update in code");
      }
      else
      {
        result.successful = false;
        result.reason = "Parameter not supported";
      }
    }
    return result;
  }

  void writeHMAX(uint16_t hmax)
  {
    uint8_t low = 0x00;
    uint8_t hig = 0x00;

    static_cast<int16_t>(static_cast<int>(hig) << 8) | static_cast<int16_t>(static_cast<int>(low));

    hig = (hmax >> 8) & 0xFF; // Shift right by 8 bits and mask with 0xFF to get the high byte
    low = hmax & 0xFF;         // Mask with 0xFF to get the low byte
  
    cam_wr_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_HMAX_LOW_ADDR, low);
    cam_wr_reg(I2C_BASEADDR, CAM_SEN, CAM_SEN_HMAX_HIG_ADDR, hig);

    displayRegisters();
  }

  void watchDog()
  {

  }

  private:

  utility::Timer timer;
  status::state nodeState;
  status::commType nodeCommType;

  rclcpp::Publisher<custom_interfaces::msg::HeartBeat>::SharedPtr status;
  rclcpp::TimerBase::SharedPtr watchDogTimer;
  rclcpp::TimerBase::SharedPtr heartBeatTimer;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;

  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr rawImgPub;

  std::thread grabThread;
  std::vector<std::thread> saveImageThreads;

  rocket::scoped_connection_container connections;


  float epoch;
  int comm_type;
  int node_state;
  std::string datafield;

int FPGA_FRAME_BUF_BASEADDR;
int VDMA_BASEADDR;
int I2C_BASEADDR;
int VIDEO_WIDTH;
int VIDEO_HEIGHT;
int FRAME_SIZE_BYTES;
int NUM_FRAMES;
int VMAX;
int VMAX_BINNING;
int HMAX;
int HMAX_BINNING;
int EXPOSURE_US;  //micro Seconds

double CLOCK_MHZ;

bool grabThreadingRunning;
bool binning;

};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<VCFG>());
  rclcpp::shutdown();
  return 0;
}