/*------------------------------------------------------------------------------
--
-- (C)Copyright 2025 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : adc
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2025-04-07
--------------------------------------------------------------------------------
-- Description: Driver for adc
-- ADS8166IRHBR https://www.ti.com/lit/ds/symlink/ads8166.pdf?HQS=dis-dk-null-digikeymode-dsf-pf-null-wwe&ts=1744054037240&ref_url=https%253A%252F%252Fwww.ti.com%252Fgeneral%252Fdocs%252Fsuppproductinfo.tsp%253FdistId%253D10%2526gotoUrl%253Dhttps%253A%252F%252Fwww.ti.com%252Flit%252Fgpn%252Fads8166
--
-- * 8 channels
-- * 16 bit resolution
-- * 0.25 MSPS for all channels
--
-- CH 0 - apd1 rssi
-- CH 1 - unused
-- CH 2 - unused
-- CH 3 - apd2 rssi
-- CH 4 - apd1 bias
-- CH 5 - unused
-- CH 6 - unused
-- CH 7 - apd2 bias
--
------------------------------------------------------------------------------*/

#include <unistd.h>
#include "fpga_drivers/adc.h"
#include "fpga_drivers/spi.h"

#define ADC_CMD_BUF_SIZE (3)
#define ADC_WR_REG_CMD (0x01 << 3)
#define ADC_RD_REG_CMD (0x02 << 3)
#define ADC_CHANNEL_ID_REG_ADDR (0x1D)

void adc_setup(uint32_t baseaddr)
{
  // Setup spi peripheral with CPOL=0, CPHA=0, MSBit First
  spi_setup(baseaddr, 0, 0, 0);

  // Disable loopback
  spi_loopback(baseaddr, 0);

	return;
}


// Write an adc spi register
// This also returns the current adc voltage value as a uint16_t
uint16_t adc_wr_reg(uint32_t baseaddr, uint8_t addr, uint8_t data)
{
  uint8_t tx_buf[ADC_CMD_BUF_SIZE] = {0};
  uint8_t rx_buf[ADC_CMD_BUF_SIZE] = {0};

  tx_buf[ 0] = ADC_WR_REG_CMD;
  tx_buf[ 1] = addr; 
  tx_buf[ 2] = data;

  spi_txrx(baseaddr, tx_buf, rx_buf, ADC_CMD_BUF_SIZE);

  uint16_t vreg = rx_buf[0] << 8;
  vreg |= rx_buf[1];
  return vreg;
}


// Read an adc spi register
uint8_t adc_rd_reg(uint32_t baseaddr, uint8_t addr)
{
  uint8_t tx_buf[ADC_CMD_BUF_SIZE] = {0};
  uint8_t rx_buf[ADC_CMD_BUF_SIZE] = {0};

  // First transfer to set the read register address
  tx_buf[ 0] = ADC_RD_REG_CMD;
  tx_buf[ 1] = addr; 
  tx_buf[ 2] = 0x00; // Dummy data

  spi_txrx(baseaddr, tx_buf, rx_buf, ADC_CMD_BUF_SIZE);

  // Second transfer to get the read data
  tx_buf[ 0] = 0x00; // Dummy data
  tx_buf[ 1] = 0x00; // Dummy data
  tx_buf[ 2] = 0x00; // Dummy data

  spi_txrx(baseaddr, tx_buf, rx_buf, ADC_CMD_BUF_SIZE);

  uint8_t adc_reg = rx_buf[0];
  return adc_reg;
}


// Get the voltage of an ADC channel
double adc_convert(uint32_t baseaddr, uint8_t chan)
{
  const double lsb = 4.096 / 65535;

  // Need to do this at least twice so that we get an adc value after the
  // channel has been set.
  uint16_t vreg = adc_wr_reg(baseaddr, ADC_CHANNEL_ID_REG_ADDR, chan);
  vreg = adc_wr_reg(baseaddr, ADC_CHANNEL_ID_REG_ADDR, chan);
  vreg = adc_wr_reg(baseaddr, ADC_CHANNEL_ID_REG_ADDR, chan);
  double vin = vreg * lsb;
  return vin;
}
