/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : uart
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-10-28
--------------------------------------------------------------------------------
-- Description: Access FPGA uart setial port over the pcie interface
------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <unistd.h>

#include "fpga_drivers/reg.h"
#include "fpga_drivers/uart.h"

#define UART_RX_FIFO_ADDR 0x0
#define UART_TX_FIFO_ADDR 0x4
#define UART_STATUS_ADDR  0x8
#define UART_CONTROL_ADDR 0xC

// If not full, then SW can transmit a new byte
int uart_is_tx_full(uint32_t baseaddr)
{
  return (reg_rd(baseaddr + UART_STATUS_ADDR) >> 3) & 0x01;
}

// If not empty, then SW can receive a new byte
int uart_is_rx_empty(uint32_t baseaddr)
{
  return !(reg_rd(baseaddr + UART_STATUS_ADDR) & 0x01);
}

// Returns number of bytes transmitted. 1 on success and 0 on fail.
int uart_tx_byte(uint32_t baseaddr, char byte)
{
  int result = 0;
  for (size_t i = 0; i < TXRX_TRIES; i++) {
    if (uart_is_tx_full(baseaddr)) {
      usleep(TXRX_TIME_US);
    } else {
      reg_wr(baseaddr + UART_TX_FIFO_ADDR, byte);
      result = 1;
      break;
    }
  }
  return result;
}

// Returns number of bytes received. 1 on success and 0 on fail.
int uart_rx_byte(uint32_t baseaddr, char * byte)
{
  int result = 0;
  for (size_t i = 0; i < TXRX_TRIES; i++) {
    if (uart_is_rx_empty(baseaddr)) {
      usleep(TXRX_TIME_US);
    } else {
      *byte = reg_rd(baseaddr + UART_RX_FIFO_ADDR);
      result = 1;
      break;
    }
  }
  return result;
}

// Transmit a buffer of bytes. Returns number of bytes transmitted..
int uart_tx(uint32_t baseaddr, const char * buf, unsigned len)
{
  int result = 0;
  for (size_t i = 0; i < len; i++) {
    if (uart_tx_byte(baseaddr, buf[i]) > 0) {
      result++;
    } else {
      break;
    }
  }
  return result;
}

// Receive a buffer of bytes. May receive fewer bytes than the length of the buffer. 
// Returns the number of bytes received.
int uart_rx(uint32_t baseaddr, char * buf, unsigned len)
{
  int result = 0;
  for (size_t i = 0; i < len; i++) {
    if (uart_rx_byte(baseaddr, &buf[i]) > 0) {
      result++;
    } else {
      break;
    }
  }
  return result;
}