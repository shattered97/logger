#!/bin/bash
# set -x

# Make sure only root can run our script
if [[ $EUID -ne 0 ]]; then
	echo "This script must be run as root" 1>&2
	exit 1
fi

# Remove the existing xdma kernel module
lsmod | grep xdma
if [ $? -eq 0 ]; then
	rmmod xdma
	if [ $? -ne 0 ]; then
		echo "rmmod xdma failed: $?"
		exit 1
	fi
fi

echo "insmod xdma.ko poll_mode=1 ..."
ret=`insmod /opt/fso_prj/cfd_xem83x0_fpga-main/xem8320_pcie/sw/XDMA/linux-kernel/xdma/xdma.ko`

if [ ! $ret == 0 ]; then
	echo "Error: xdma driver did not load properly"
	echo " FAILED"
	exit 1
fi

echo ""
cat /proc/devices | grep xdma > /dev/null
returnVal=$?
if [ $returnVal == 0 ]; then
	# Installed devices were recognized.
	echo "The Kernel module installed correctly and the xmda devices were recognized."
else
	# No devices were installed.
	echo "Error: The Kernel module installed correctly, but no devices were recognized."
	echo " FAILED"
	exit 1
fi

echo "DONE"