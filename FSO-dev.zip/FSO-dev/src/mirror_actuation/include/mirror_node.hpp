#pragma once
#ifndef MIRRORHPP
#define MIRRORHPP
//#define POSERROR(A, B) RCLCPP_ERROR(this->get_logger(), "__FILE__:__LINE__ New (A) coordinate \"%f\" out of range! Aborting update.", (B))
enum mirrorCmd{
    updatePosCmd = 0,
    updateCurrentCmd
};
const double MAXPOSCOORD = 1.0f;
const double MAXNEGCOORD = -1.0f;
const double MAXPOSCURRENT = 500.0f;
const double MAXNEGCURRENT = -500.0f;
const uint16_t SERIALCONNECTION = 0;
const uint16_t TCPIPCONNECTION = 1;
const uint16_t XAXIS = 0;
const uint16_t YAXIS = 1;
#endif //MIRRORHPP