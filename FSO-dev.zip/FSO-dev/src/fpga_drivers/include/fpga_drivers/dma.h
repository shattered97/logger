/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : dma
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-12-04
--------------------------------------------------------------------------------
-- Description: Driver for Xilinx PCIe DMA
------------------------------------------------------------------------------*/

#ifndef DMA_H_
#define DMA_H_

#include <stdint.h>

int dma_rd(uint64_t start_addr, uint8_t * buf, uint64_t size);
int dma_wr(uint64_t start_addr, uint8_t * buf, uint64_t size);

#endif /* DMA_H_ */
