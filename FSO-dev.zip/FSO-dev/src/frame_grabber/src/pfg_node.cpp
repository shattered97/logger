#include <rclcpp/rclcpp.hpp>
#include <rclcpp/logging.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <rcl_interfaces/msg/parameter_descriptor.hpp>

#include <pylon/PylonIncludes.h>
#include <pylon/SoftwareTriggerConfiguration.h>
#include <pylon/usb/BaslerUsbInstantCamera.h>   // MJR
#include "cv_bridge/cv_bridge.h"
#include "opencv2/highgui.hpp"
#include "opencv2/features2d.hpp"

#include <thread>
#include <cmath>
#include <string>
 
#include "../../custom_interfaces/custom_dt.h"
#include "timer/timer.h"
#include "custom_interfaces/msg/heart_beat.hpp"
#include "custom_interfaces/srv/camera_coords_service.hpp"
#include "custom_interfaces/msg/camera_coords_message.hpp"

using namespace std::chrono_literals;

class PFG : public rclcpp::Node
{
public:
    PFG() : Node("pfg_node") 
    {
        initialization();
        pylon_getCameraSN();

        //Main starts here - 
        if(camera.IsOpen())  //ensure camera is open before we kick off the thread
        {
            nodeState = status::state::running;
            grabThread = std::thread(&PFG::pylon_GrabImageThread, this);
        }
        else
        {
            nodeState = status::state::stopped;
            std::cout << "Camera is not running" << std::endl;
        }

       //Timers
       watchDogTimer = this->create_wall_timer(100ms, std::bind(&PFG::watchDog, this));

       //Messages
       cameraCoordsMessagePub = this->create_publisher<custom_interfaces::msg::CameraCoordsMessage>("camera_coords", 10);

       //Services
       cameraCoordsService = this->create_service<custom_interfaces::srv::CameraCoordsService>("camera_coords_service", std::bind(&PFG::ros2_service_pos, this, std::placeholders::_1, std::placeholders::_2));

       //Callbacks
       //Register a callback function that will be called whenever there is attempt
       //to change one or more parameters of the node
       parameter_callback_handle = this->add_on_set_parameters_callback(
       std::bind(&PFG::parameter_change_callback, this, std::placeholders::_1));
    }

    ~PFG()
    {
        //clean up grab thread
        this->set_parameter(rclcpp::Parameter("thread_running", false));
        std::terminate();  //bad code - stop memory leak, will fix in HW v2.75
    }

private:

    void cv_createCV_Image(Pylon::CGrabResultPtr &aPtrGrabResult, cv::Mat &cvImage)
    {
        int width = this->get_parameter("cam_ImageWidth").as_int();
        int height = this->get_parameter("cam_ImageHeight").as_int();
        cvImage.create(height, width, CV_8UC1);
        frameGrabberLock.lock();
        memcpy(cvImage.ptr(), (uint8_t*)aPtrGrabResult->GetBuffer(), (width * height));
        frameGrabberLock.unlock();
    }

    void createRoiWindowLookup()
    {
        for(int row = 0; row <= (sensorHeight - roiY);  row += roiY)
        {
            for(int col = 0; col <= (sensorWidth - roiX); col += roiX)
            {
                roiWindows.push_back(RoiWindowData(col, row));
            }
        }

        currentWindow = roiWindows.begin();
        previousWindow = roiWindows.begin();

        for(auto rsp : roiWindows)
        {
            std::cout << "X:" << rsp.x << " " << "Y:" << rsp.y << std::endl;
        }
    }

    void cv_drawText(std::string &displayTxt, cv::Point2f &txtLoc, cv::Mat &image)
    {
        int font = cv::FONT_HERSHEY_COMPLEX_SMALL;
        double fontScale = 0.75;
        int fontThickness = 1.0;
        cv::Scalar color(0,0,0);
        cv::putText(image, displayTxt, txtLoc, font, fontScale, color, fontThickness );
    }
    
    bool cv_findMultiBlobs(cv::Mat &cvImage)
    {
        //frameGrabberLock.lock();
        bool targetFound = false;
        cv::Scalar black = cv::Scalar(0,0,0);  //black line
        cv::Mat threshold;
        std::vector<std::vector<cv::Point>> contours;
        std::vector<cv::Vec4i> hierarchy;

        int imageWidth = this->get_parameter("cam_ImageWidth").as_int();
        int imageHeight = this->get_parameter("cam_ImageHeight").as_int();

        //Find the brightest single pixel in the image
        //Also returns the CV::POINT location for the brightest pixel
        double minVal = 0;
        double maxVal = 0;
        cv::Point minIdx;
        cv::Point maxIdx;
        cv::minMaxLoc(cvImage, &minVal, &maxVal, &minIdx, &maxIdx);

        if(maxVal < 10)  //background brightness used to filter when no targets are present
        {
            maxVal = 255;
        }

        //use a percentage of the single brightest pixel for the threshold value
        cv::threshold(cvImage, threshold, (maxVal * thresholdPercent), 255, cv::THRESH_BINARY);

        cv::findContours(threshold, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE, cv::Point(0,0));

        std::vector<cv::Moments> mu(contours.size());
        std::vector<cv::Point2f> mc(contours.size());
        std::vector<cv::Point2f> displayPoints(contours.size() + 1);  //add one for brightest pixel point

        //Create new image to display the targets on with a white background
        cv::Mat drawing(threshold.size(), CV_8UC1, cv::Scalar(255,255,255));
        cv::Point2f displayPoint;
        int targetID = 0;
        std::vector<std::vector<cv::Point>>::iterator it;

            if(contours.size() > 0)
            {
                if(contours.size() > 1)
                {
                    RCLCPP_WARN(this->get_logger(), "We have a problem Jim, we have %lu targets", contours.size());
                }

                for(it = contours.begin(); it != contours.end(); ++it )
                {
                    targetID++;
                    //area filter
                    double c_area = cv::contourArea(*it);
                    //double perimeter = cv::arcLength(*it, true);

                    //Check if blob is a circle
                    // double circularity = 4 * CV_PI * c_area / (perimeter * perimeter);
                    // if(circularity < 0.8)
                    // {
                    //     continue;  //Not close enough to circle move to the next blob
                    //     std::cout  << "Ignoring target because it is not a circular object";
                    // }

                    //Draw perfect circle around the target 
                    cv::Point2f center;
                    float radius;
                    cv::minEnclosingCircle(*it, center, radius);
                    cv::circle(drawing, center, (int)radius, cv::Scalar(0,0,255), 2);

                    if(c_area <= area_filter && c_area > 0)  //only works if there is more than 1 pixel
                    {
                        mu.emplace_back(cv::moments(*it, false));
                        mc.emplace_back(mu.back().m10/mu.back().m00, mu.back().m01/mu.back().m00);
                        cv::drawMarker(drawing, mc.back(), black, cv::MARKER_TILTED_CROSS, 50, 1, 8);
                        std::string target =  "T" + std::to_string(targetID);
                        target.append("(");
                        target.append(std::to_string(mc.back().x));
                        target.append(":");
                        target.append(std::to_string(mc.back().y));
                        target.append(")");

                        cv_drawText(target, mc.back(), drawing);
                        ros2_publish_pos(targetID, mc.back().x, mc.back().y, c_area, maxVal, imageHgt, imageWidth, true);
                    }
                    else if(c_area < 1)
                    {
                        cv::drawMarker(drawing, maxIdx, black, cv::MARKER_STAR, 50,1,8);
                        ros2_publish_pos(targetID, maxIdx.x, maxIdx.y, c_area, maxVal, imageHgt, imageWidth, true);
                    }
                }
            }
            else  //No Targets found
            {
                ros2_publish_pos(targetID, maxIdx.x, maxIdx.y, 0, maxVal, imageHgt, imageWidth, false);
            }
        
        //Draw lines around camera FOV to define bounderies
        cv::line(drawing, cv::Point(10,10), cv::Point(imageWidth - 10,10), black);
        cv::line(drawing, cv::Point(imageWidth - 10,10), cv::Point(imageWidth -10 ,imageHeight - 10), black);
        cv::line(drawing, cv::Point(imageWidth - 10, imageHeight -10), cv::Point(10, imageHeight - 10), black);
        cv::line(drawing, cv::Point(10, imageHeight -10), cv::Point(10,10), black);

        cv::Point center((imageWidth/2), (imageHeight/2));

        cv::drawMarker(drawing, center, black, cv::MARKER_CROSS, 100, 1, 8);

        if(displayRaw) { cv::imshow("Raw", cvImage); }
        if(displayThreshold) { cv::imshow("Threshold", threshold); }
        if(displayPFGnode) { cv::imshow(this->get_name(), drawing); }

        //frameGrabberLock.unlock();
        return targetFound;
    }

    void declareParams()
    {
        targetFound  = false;
        targetLocked = false;

        this->declare_parameter("thread_running", true);  //default to thread running for ease of code 

        //hardcoded defaults - DO NOT CHANGE VALUES HERE
        //use ROS parameters to change values
        //use launch file to set camera specific defaults
        //Basler Plyon CamesendMoveMirrorra Configs
        this->declare_parameter("cam_sensor", "sony IMX273");
        this->declare_parameter("cam_sensor_width", 1440);
        this->declare_parameter("cam_sensor_height", 1080);
        this->declare_parameter("cam_FullName", "unknown");
        this->declare_parameter("cam_Model", "unknown");
        this->declare_parameter("cam_SerialNumber", 40374815);
        this->declare_parameter("cam_focalLength", 12.5);
        this->declare_parameter("cam_BinningSelector", "Region1");
        this->declare_parameter("cam_BinningHorizontal", 2);
        this->declare_parameter("cam_BinningVertical", 2);
        this->declare_parameter("cam_BinningHorizontalMode", "Sum");
        this->declare_parameter("cam_BinningVerticalMode", "Sum");  
        this->declare_parameter("pixelSize_um", 3.45); 
        this->declare_parameter("cam_MaxWidth", 0);

        //Cam Max Resoultion, binning will keep the same frame size, but decrease the
        //resolution by a factor of the binning size.  
        binningH = this->get_parameter("cam_BinningHorizontal").as_int();
        binningV = this->get_parameter("cam_BinningVertical").as_int();
        int sensorHeight = this->get_parameter("cam_sensor_height").as_int();
        int sensorWidth = this->get_parameter("cam_sensor_width").as_int();

        this->declare_parameter("cam_ImageHeight", sensorHeight / binningH); 
        this->declare_parameter("cam_ImageWidth", sensorWidth / binningV);
        this->declare_parameter("cam_ExposureTime", 100.0);  //100 lab
        this->declare_parameter("cam_MaxNumBuffer", 1);
        this->declare_parameter("cam_PixelFormat", "Mono8");

        //Generic Configs
        this->declare_parameter("pfg_DisplayRawImage", true);
        this->declare_parameter("pfg_DisplayThreshold", true);
        this->declare_parameter("pfg_DisplayPFGnode", true);

        displayRaw = this->get_parameter("pfg_DisplayRawImage").as_bool();
        displayThreshold = this->get_parameter("pfg_DisplayThreshold").as_bool();
        displayPFGnode = this->get_parameter("pfg_DisplayPFGnode").as_bool();

        this->declare_parameter("cv_thresholdPrecent", 0.95); //.5 lab
        this->declare_parameter("cam_area_filter", 3000);
        this->declare_parameter("cam_deltaX_mm", 0.0);       //Distance camera from mirror
        this->declare_parameter("cam_deltaY_mm", 0.044562);  //Distance camera from mirror
        this->declare_parameter("cam_deltaZ_mm", 0.07029);   //Distance camera from mirror
        
        thresholdPercent = this->get_parameter("cv_thresholdPrecent").as_double();
        deltaX_mm = this->get_parameter("cam_deltaX_mm").as_double();  //X axis distance between mirror and camera
        deltaY_mm = this->get_parameter("cam_deltaY_mm").as_double();  //Y axis distance between mirror and camera
        deltaZ_mm = this->get_parameter("cam_deltaZ_mm").as_double();  //Z axis distance between mirror and camera
    }

    bool findMaxWidth(GenApi_3_1_Basler_pylon::INodeMap& nodemap)
    {
        bool success = false;
        try
        {
            int rsp = Pylon::CIntegerParameter(nodemap, "WidthMax").GetValue();
            this->set_parameter(rclcpp::Parameter("cam_MaxWidth", rsp ));
            success = true;
        }
        catch(const Pylon::GenericException& e)
        {
            RCLCPP_ERROR(this->get_logger(), BASLER_ERROR, e.what());
            nodeState = status::state::error;
        }
        return success;
    }

    void initializeFlags()
    {
        //Not used at this time
    }

    void initialization()
    {
        timer.reset();
        timer.start();

        nodeState = status::state::initializating;
        nodeComType = status::commType::usb;

        pylon_getCameraSN();
        declareParams();
        pylonInitialize();
    }

    void moveToNextWindow(GenApi_3_1_Basler_pylon::INodeMap& _nodeMap)
    {
            previousWindow = currentWindow;
            currentWindow++;

            Pylon::CIntegerParameter ox(_nodeMap, "OffsetX");
            Pylon::CIntegerParameter oy(_nodeMap, "OffsetY");

        if(currentWindow == roiWindows.end())
        {   
            Pylon::CIntegerParameter(_nodeMap, "OffsetX").SetValue(0);  
            Pylon::CIntegerParameter(_nodeMap, "OffsetY").SetValue(0);
            int CX = ox.GetValue();
            int CY = oy.GetValue();
            std::cout << "Camera OX:" << CX << " " << "Camera OY:" << CY << std::endl;
            currentWindow = roiWindows.begin();
        }
        else
        {
            Pylon::CIntegerParameter(_nodeMap, "OffsetX").SetValue(currentWindow->x);  
            Pylon::CIntegerParameter(_nodeMap, "OffsetY").SetValue(currentWindow->y);
            int CX = ox.GetValue();
            int CY = oy.GetValue();
            std::cout << "Camera OX:" << CX << " " << "Camera OY:" << CY << std::endl;
        }
    }

    void moveToRoiWindow(GenApi_3_1_Basler_pylon::INodeMap& _nodeMap, int windowNum)
    {
        previousWindow = currentWindow;
        currentWindow = roiWindows.begin();
        currentWindow + windowNum;

        if(currentWindow != roiWindows.end())
        {    
            Pylon::CIntegerParameter(_nodeMap, "OffsetX").SetValue(currentWindow->x);  
            Pylon::CIntegerParameter(_nodeMap, "OffsetY").SetValue(currentWindow->y);
        }
    }

    rcl_interfaces::msg::SetParametersResult parameter_change_callback(const std::vector<rclcpp::Parameter> &params)
    {
        //Can not use new parameters until they are set. They are not set until this function is complete. 
        //Minimize time spent here - use the watchdog to perform actions on this node
        auto result = rcl_interfaces::msg::SetParametersResult();
        result.successful = true;
        GenApi_3_1_Basler_pylon::INodeMap& nodeMap = camera.GetNodeMap();
        for(const auto &param : params)
        {
            std::string name = param.get_name();
            rclcpp::ParameterType pt = param.get_type();

            if(name == "cam_SerialNumber" && pt == rclcpp::ParameterType::PARAMETER_INTEGER)
            {
                //Do Nothing here - This is used to find the camera, just update the parameter
            }
            else if(name == "cam_focalLenth" && pt == rclcpp::ParameterType::PARAMETER_DOUBLE)
            {
                focalLength = param.as_double();
            }
            else if(name == "cam_BinningSelector" && pt == rclcpp::ParameterType::PARAMETER_STRING)
            {
                result.successful = false;
                result.reason = "The only valid value is Region1";
            }
            else if(name == "cam_BinningHorizontal" && pt == rclcpp::ParameterType::PARAMETER_INTEGER)
            {
                if(param.as_int() > 0 && param.as_int() < 5)
                {
                    setBinning(nodeMap, 1, param.as_int());
                }
                else
                {
                    result.successful = false;
                    result.reason = "Valid input values are 1-4";
                }
            }
            else if(name == "cam_BinningVertical" && pt == rclcpp::ParameterType::PARAMETER_INTEGER)
            {
                if(param.as_int() > 0 && param.as_int() < 5)
                {
                    setBinning(nodeMap, 2, param.as_int());
                }
                else
                {
                    result.successful = false;
                    result.reason = "Valid input values are 1-4";
                }
            }
            else if(name == "cam_BinningHorizontalMode" && pt == rclcpp::ParameterType::PARAMETER_STRING)
            {
                //add error checking
                setBinningMode(nodeMap, 2, param.as_string());
            }
            else if(name == "cam_BinningVerticalMode" && pt == rclcpp::ParameterType::PARAMETER_STRING)
            {
                //add error checking
                setBinningMode(nodeMap, 1, param.as_string());
            } 
            else if(name == "cam_MaxWidth" && pt == rclcpp::ParameterType::PARAMETER_INTEGER)       
            {
                result.successful = false;
                result.reason = "This parameter can not be updated";
            }
            else if(name == "cam_ImageHeight" && pt == rclcpp::ParameterType::PARAMETER_INTEGER)
            {
                //add error checking
                setResoultion(nodeMap, 2, param.as_int());
            }
            else if(name == "cam_ImageWidth" && pt == rclcpp::ParameterType::PARAMETER_INTEGER)
            {
                //add error checking
                setResoultion(nodeMap, 1, param.as_int());
            }
            else if(name == "cam_ExposureTime" && pt == rclcpp::ParameterType::PARAMETER_DOUBLE)
            {
                //add error checking
                setExposure(nodeMap, param.as_double());
            }
            else if(name == "cv_thresholdPercent" && pt == rclcpp::ParameterType::PARAMETER_DOUBLE)
            {
                thresholdPercent = param.as_double();
            }
            else if(name == "cam_area_filter" && pt == rclcpp::ParameterType::PARAMETER_INTEGER)
            {
                area_filter = param.as_int();
            }
            else
            {
                result.successful = false;
                result.reason = "Parameter not supported";                
            }
        }
        return result;
    }
  
    //Find the camera that matches the serial number in the ROS params
    //Create the device
    void pylonInitialize()
    { 
        try
        {
            int sn = this->get_parameter("cam_SerialNumber").as_int();
            RCLCPP_INFO(this->get_logger(), "Initialization Camera, SN:  %d", sn );
            pylon_addCameraUsb(sn);

            //update ROS params with new information from camera
            Pylon::CDeviceInfo di = camera.GetDeviceInfo();

            this->set_parameter(rclcpp::Parameter("cam_FullName", di.GetFullName()));
            this->set_parameter(rclcpp::Parameter("cam_Model", di.GetModelName()));

            camera.Open();            
            nodeState = status::state::stopped;

            auto& nodeMap = camera.GetNodeMap();
            Pylon::CEnumParameter(nodeMap, "BinningSelector").SetValue("Region1");  //only valid value

            setBinningMode(nodeMap, 1, this->get_parameter("cam_BinningVerticalMode").as_string());
            setBinningMode(nodeMap, 2, this->get_parameter("cam_BinningHorizontalMode").as_string());
            setBinning(nodeMap, 1, this->get_parameter("cam_BinningVertical").as_int());
            setBinning(nodeMap, 2, this->get_parameter("cam_BinningHorizontal").as_int());
            findMaxWidth(nodeMap);
            setResoultion(nodeMap, 1, this->get_parameter("cam_ImageWidth").as_int());
            setResoultion(nodeMap, 2, this->get_parameter("cam_ImageHeight").as_int());
            setExposure(nodeMap, this->get_parameter("cam_ExposureTime").as_double());
            setPixelFormat(nodeMap, this->get_parameter("cam_PixelFormat").as_string());
            focalLength = this->get_parameter("cam_focalLength").as_double();
            area_filter = this->get_parameter("cam_area_filter").as_int();

            if(binningH == binningV)
            {
                pixelSize = (this->get_parameter("pixelSize_um").as_double()) * binningH ;    
            }
            else
            {
                RCLCPP_ERROR(this->get_logger(), "BINNING HORIZONTAL and BINNING VERTICAL are not equal");
            }
        }
        catch(const Pylon::GenericException& e)
        {
            RCLCPP_ERROR(this->get_logger(), BASLER_ERROR, e.what());
            nodeState = status::state::error;
        }
    }

    bool pylon_addCameraUsb(int serialNumber)
    {
        bool success = false;
        try
        {
            Pylon::CTlFactory& TlFactory = Pylon::CTlFactory::GetInstance();
            Pylon::CDeviceInfo di;        
            di.SetSerialNumber(std::to_string(serialNumber).c_str());
            di.SetDeviceClass(Pylon::BaslerUsbDeviceClass);
            camera.Attach(TlFactory.CreateDevice(di));
            success = true;
        }
        catch(const Pylon::GenericException& e)
        {
            RCLCPP_ERROR(this->get_logger(), BASLER_ERROR, e.what());
            nodeState = status::state::error;
            success = false;
        }
        return success;
    }

    void pylon_getCameraSN()
    {
        //Not needed for production - used for initial setup and testing
        Pylon::CTlFactory& TlFactory = Pylon::CTlFactory::GetInstance();  //Create a transport layer
        Pylon::DeviceInfoList_t deviceList;

        Pylon::DeviceInfoList_t::const_iterator it;

        TlFactory.EnumerateDevices( deviceList);
        if ( !deviceList.empty() )
        {
            for(it = deviceList.begin(); it != deviceList.end(); ++it)
            {
                std::cout << "Model:  " << it->GetModelName() << std::endl;
                std::cout << " Serial #:  " << it->GetSerialNumber() << std::endl;
            }
        }
        else
        {
            std::cout << "No cameras found" << std::endl;
            it = NULL;
        }
    }

    void ros2_publish_pos(int8_t tID, double Xp, double Yp, double a, double brightness, int imgHgt, int imgWidth, bool tf)
    {

        RCLCPP_INFO(this->get_logger(), MSG_CAM_COORD, tID, Xp, Yp, a, brightness, focalLength );
        auto cordMsg = custom_interfaces::msg::CameraCoordsMessage();
        
        if(!std::isnan(Xp) || !std::isnan(Yp))
        {   
            cordMsg.target_id = tID;
            cordMsg.target_found = tf;
            cordMsg.x = Xp;
            cordMsg.y = Yp;
            cordMsg.area = a; 
            cordMsg.brightness = brightness;
            cordMsg.img_hgt = imgHgt;
            cordMsg.img_width = imgWidth;
            cordMsg.focal_length = focalLength;
            cordMsg.p_um = pixelSize;
            cordMsg.delta_x_mm  = deltaX_mm;
            cordMsg.delta_y_mm = deltaY_mm;
            cordMsg.delta_z_mm = deltaZ_mm;
            
            cameraCoordsMessagePub->publish(cordMsg);
        }
    }

    // request is needed here
    void ros2_service_pos(std::shared_ptr<custom_interfaces::srv::CameraCoordsService::Request> request, 
                            std::shared_ptr<custom_interfaces::srv::CameraCoordsService::Response> response)
    {
        RCLCPP_INFO(this->get_logger(), SRV_CAM_COORDS_IN);

        float focal_length = this->get_parameter("focal_length").as_double();

        if(!std::isnan(srv_x_coord) || !std::isnan(srv_y_coord))
        {   
            response->set__x_pos(srv_x_coord);
            response->set__y_pos(srv_y_coord);
            response->set__focal_length(focal_length);

            RCLCPP_INFO(this->get_logger(), SRV_CAM_COORDS_OUT, response->focal_length, response->x_pos, response->y_pos);
        }
        else
        {
            RCLCPP_INFO(this->get_logger(), "NAN");
        }
    }

    void pylon_GrabImageThread()
    {
        try
        {
            std::cout << "Grab Thread Open" << std::endl;
            nodeState = status::state::running;
            Pylon::CGrabResultPtr ptrGrabResult;
            bool startWindows = false;

            if(this->get_parameter("pfg_DisplayRawImage").as_bool())
            {
                cv::namedWindow("Raw", cv::WINDOW_KEEPRATIO);
                startWindows = true;
            }
            
            if(this->get_parameter("pfg_DisplayThreshold").as_bool())
            {
                cv::namedWindow("Threshold", cv::WINDOW_KEEPRATIO);
                startWindows = true;
            }

            if(this->get_parameter("pfg_DisplayPFGnode").as_bool())
            {
                cv::namedWindow(this->get_name(), cv::WINDOW_KEEPRATIO);
                startWindows = true;
            }

            if(startWindows)
            {
                cv::startWindowThread();
            }

            targetFound = false;
            targetLocked = false;

            camera.StartGrabbing(Pylon::GrabStrategy_LatestImageOnly);

            while(this->get_parameter("thread_running").as_bool()  && camera.IsOpen())
            {
                nodeState = status::state::running;
                camera.RetrieveResult(1000, ptrGrabResult, Pylon::TimeoutHandling_ThrowException);

                if(ptrGrabResult->GrabSucceeded())
                {
                    cv::Mat cvImage_raw;  //used to convert from basler to open cv image format
                    cv_createCV_Image(ptrGrabResult, cvImage_raw);
                    ptrGrabResult.Release();  //done wwith basler image release it

                    targetFound = cv_findMultiBlobs(cvImage_raw);
                }
                else
                {
                    std::cout << "Grab Failed" << std::endl;
                }
            }
        }
        catch(const Pylon::GenericException& e)
        {
            RCLCPP_ERROR(this->get_logger(), BASLER_ERROR, e.what());
            nodeState = status::state::error;
        } 
        std::cout << "Grab Thread Stopped" << std::endl;
        camera.StopGrabbing();
        cv::destroyWindow(this->get_name());
        nodeState = status::state::stopped;
    }

    
    /*
    pos:  1 = Vertical, 2 = Horizontal
    Make sure the camera is idle, i.e., not capturing images.
    Set the BinningHorizontalMode parameter to one of the following values (if available):
    Sum: The values of the affected pixels are summed. This improves the signal-to-noise ratio, but also increases the camera's response to light.
    Average: The values of the affected pixels are averaged. This greatly improves the signal-to-noise ratio without affecting the camera's response to light.
    Set the BinningVerticalMode parameter accordingly.*/
    bool setBinningMode(GenApi_3_1_Basler_pylon::INodeMap& nodemap, int pos, std::string mode)   
    {  
        bool success = false;
        try
        {
            if(pos == 1) { Pylon::CEnumParameter(nodemap, "BinningHorizontalMode").SetValue(mode.c_str()); }
            else if(pos == 2) { Pylon::CEnumParameter(nodemap, "BinningVerticalMode").SetValue(mode.c_str()); }
            success = true;
        }
        catch(const Pylon::GenericException& e)
        {
            RCLCPP_ERROR(this->get_logger(), BASLER_ERROR, e.what());
            nodeState = status::state::error;
        } 
        return success;
    }

    /*   
    mode:  1 = HorizontalMode, 2 = VerticalMode
    value: 1 - 4
    Make sure the camera is idle, i.e., not capturing images.
    Set the BinningHorizontal parameter to one of the following values (if available):
        1: Disables binning in horizontal direction.
        2, 3, 4: Sets the number of combined adjacent pixels in horizontal direction to 2, 3, or 4.
    Set the BinningVertical parameter accordingly.
    Example: You set the BinningHorizontal parameter to 3 and the BinningVertical parameter to 2. This enables 3x2 binning. */
    bool setBinning(GenApi_3_1_Basler_pylon::INodeMap& nodemap, int mode, int value)
    {
        bool success = false;
        try
        {
            if(mode == 1) 
            { 
                Pylon::CIntegerParameter(nodemap, "BinningHorizontal").SetValue(value);
            }
            else if(mode == 2) 
            { 
                Pylon::CIntegerParameter(nodemap, "BinningVertical").SetValue(value);
            }
            success = true;
        }
        catch(const Pylon::GenericException& e)
        {
            RCLCPP_ERROR(this->get_logger(), BASLER_ERROR, e.what());
            nodeState = status::state::error;
        }
        return success;
    }

    bool setExposure(GenApi_3_1_Basler_pylon::INodeMap& nodemap, float value)
    {
        bool success = false;
        try
        {
            Pylon::CFloatParameter(nodemap, "ExposureTime").SetValue(value);
            success = true;
        }
        catch(const Pylon::GenericException& e)
        {
            RCLCPP_ERROR(this->get_logger(), BASLER_ERROR, e.what());
            nodeState = status::state::error;
        }
        return success;
    }

    bool setPixelFormat(GenApi_3_1_Basler_pylon::INodeMap& nodemap, std::string value)
    {
        bool success = false;
        try
        {
            Pylon::CEnumParameter(nodemap, "PixelFormat").SetValue(value.c_str());
        }
       catch(const Pylon::GenericException& e)
        {
            RCLCPP_ERROR(this->get_logger(), BASLER_ERROR, e.what());
            nodeState = status::state::error;
        }
        return success;
        
    }

    //axis: 1 = width, 2 = height
    bool setResoultion(GenApi_3_1_Basler_pylon::INodeMap& nodemap, int axis, int resolution)  
    {
        bool success = false;
        try
        {
            if(axis == 1) 
            { 
                Pylon::CIntegerParameter(nodemap, "Width").SetValue(resolution);
                imageWidth = resolution;
            }
            else if(axis == 2) 
            { 
                Pylon::CIntegerParameter(nodemap, "Height").SetValue(resolution); 
                imageHgt = resolution;
            }
            success = true;
        }
        catch(const Pylon::GenericException& e)
        {
            RCLCPP_ERROR(this->get_logger(), BASLER_ERROR, e.what());
            nodeState = status::state::error;     
        }

        return success;
    }  
    void watchDog()
    {
        if(nodeState == status::state::stopped && this->get_parameter("thread_running").as_bool())
        {
            std::cout << "watch dog restarted thread" << std::endl; 
            grabThread.join();
            grabThread = std::thread(&PFG::pylon_GrabImageThread, this);
            nodeState = status::state::running;
            this->set_parameter(rclcpp::Parameter("thread_running", true));
        }
    }

    rclcpp::TimerBase::SharedPtr watchDogTimer;

    rclcpp::Publisher<custom_interfaces::msg::CameraCoordsMessage>::SharedPtr cameraCoordsMessagePub;
    rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;

    rclcpp::Service<custom_interfaces::srv::CameraCoordsService>::SharedPtr cameraCoordsService;

    int sensorWidth;
    int sensorHeight;

    int roiX; 
    int roiY;

    int imageWidth;
    int imageHgt;

    int binningH;
    int binningV;

    bool displayRaw;
    bool displayThreshold;
    bool displayPFGnode;

    std::thread grabThread;

    bool targetFound;
    bool targetLocked;
    std::vector<RoiWindowData>::iterator currentWindow; 
    std::vector<RoiWindowData>::iterator previousWindow;
    std::vector<RoiWindowData>::iterator targetLock;

    utility::Timer timer;

    status::state nodeState;
    status::commType nodeComType;

    std::mutex frameGrabberLock;

    // PylonInitialize() will be called
    // autoInitTerm's destructor calls PylonTerminate()
    Pylon::PylonAutoInitTerm autoInitTerm; // PylonInitialize() will be called now
    Pylon::CInstantCamera camera;

    float srv_x_coord;
    float srv_y_coord;

    double focalLength;
    double thresholdPercent;
    double pixelSize;
    int area_filter;
    double deltaZ_mm;
    double deltaX_mm;
    double deltaY_mm;

    std::vector<TargetData> trackedTargets;

    std::vector<RoiWindowData> roiWindows;

};

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PFG>());
    rclcpp::shutdown();

    return 0;
}
