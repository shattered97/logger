/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : vdma
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-12-11
--------------------------------------------------------------------------------
-- Description: Driver for FPGA Video DMA block
------------------------------------------------------------------------------*/


//#include "/opt/fso_prj/FSO/install/fpga_drivers/include/fpga_drivers/vdma.h"
//#include "/opt/fso_prj/FSO/install/fpga_drivers/include/fpga_drivers/reg.h"

#include "fpga_drivers/vdma.h"
#include "fpga_drivers/reg.h"

#define VDMA_CTL_ADDR 0x30
#define VDMA_STS_ADDR 0x34
#define VDMA_VSIZE_ADDR 0xA0
#define VDMA_HSIZE_ADDR 0xA4
#define VDMA_STRIDE_ADDR 0xA8
#define VDMA_START_ADDR_ADDR 0xAC


#define VDMA_PARK_PTR_ADDR 0x28
#define VDMA_PARK_PTR_WR_FRAME_BIT_SHIFT 24
#define VDMA_PARK_PTR_WR_FRAME_BIT_MASK 0x1F 


void vdma_start(uint32_t baseaddr, uint32_t hsize, uint32_t vsize)
{
  reg_wr(baseaddr + VDMA_CTL_ADDR, 0x00010083);
  reg_wr(baseaddr + VDMA_STRIDE_ADDR, hsize);
  reg_wr(baseaddr + VDMA_HSIZE_ADDR, hsize);
  reg_wr(baseaddr + VDMA_VSIZE_ADDR, vsize);
}


void vdma_stop(uint32_t baseaddr)
{
  reg_wr(baseaddr + VDMA_CTL_ADDR, 0x00010082);
}


void vdma_soft_reset(uint32_t baseaddr)
{
  reg_wr(baseaddr + VDMA_CTL_ADDR, 0x00010086);
}


uint32_t vdma_get_status(uint32_t baseaddr)
{
  return reg_rd(baseaddr + VDMA_STS_ADDR);
}


void vdma_clear_status(uint32_t baseaddr)
{
  reg_wr(baseaddr + VDMA_STS_ADDR, 0xFFFFFFFF);
}


int vdma_set_buf_addr(uint32_t baseaddr, uint32_t buf_addr, uint32_t buf_idx)
{
  if (buf_idx > VDMA_NUM_FRAME_BUF - 1) {
    return 1;
  }
  reg_wr(baseaddr + VDMA_START_ADDR_ADDR + (buf_idx * 4), buf_addr);
  return 0; 
}


uint32_t vdma_get_wptr(uint32_t baseaddr)
{
  uint32_t reg = reg_rd(baseaddr + VDMA_PARK_PTR_ADDR);
  reg = (reg >> VDMA_PARK_PTR_WR_FRAME_BIT_SHIFT) & VDMA_PARK_PTR_WR_FRAME_BIT_MASK;
  return reg;  
}
