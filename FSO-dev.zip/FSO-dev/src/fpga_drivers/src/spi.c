/*------------------------------------------------------------------------------
--
-- (C)Copyright 2024 - Critical Frequency Design
--
--------------------------------------------------------------------------------
--
-- All rights reserved. This document contains proprietary information and
-- except with written permission from Critical Frequency Design, such
-- information shall not be published or disclosed to others or used for any
-- purpose other than those prescribed by Critical Frequency Design.
--
--------------------------------------------------------------------------------
-- Project    : Modem Control Phase 3 FPGA
--------------------------------------------------------------------------------
-- Title      : spi
--------------------------------------------------------------------------------
-- Author     : David Gussler
-- Created    : 2024-12-11
--------------------------------------------------------------------------------
-- Description: Driver for SPI FPGA block
------------------------------------------------------------------------------*/

#include <unistd.h>
//#include "spi.h"
//#include "reg.h"

#include "fpga_drivers/reg.h"
#include "fpga_drivers/spi.h"

#define XSP_DGIER_OFFSET	0x1C	/**< Global Intr Enable Reg */
#define XSP_IISR_OFFSET		0x20	/**< Interrupt status Reg */
#define XSP_IIER_OFFSET		0x28	/**< Interrupt Enable Reg */
#define XSP_SRR_OFFSET	 	0x40	/**< Software Reset register */
#define XSP_CR_OFFSET	  	0x60	/**< Control register */
#define XSP_SR_OFFSET	  	0x64	/**< Status Register */
#define XSP_DTR_OFFSET		0x68	/**< Data transmit */
#define XSP_DRR_OFFSET		0x6C	/**< Data receive */
#define XSP_SSR_OFFSET		0x70	/**< 32-bit slave select */
#define XSP_TFO_OFFSET		0x74	/**< Tx FIFO occupancy */
#define XSP_RFO_OFFSET		0x78	/**< Rx FIFO occupancy */

#define XSP_CR_LOOPBACK_MASK	     0x00000001 /**< Local loopback mode */
#define XSP_CR_ENABLE_MASK	       0x00000002 /**< System enable */
#define XSP_CR_MASTER_MODE_MASK	   0x00000004 /**< Enable master mode */
#define XSP_CR_CLK_POLARITY_MASK   0x00000008 /**< Clock polarity high or low */
#define XSP_CR_CLK_PHASE_MASK	     0x00000010 /**< Clock phase 0 or 1 */
#define XSP_CR_TXFIFO_RESET_MASK   0x00000020 /**< Reset transmit FIFO */
#define XSP_CR_RXFIFO_RESET_MASK   0x00000040 /**< Reset receive FIFO */
#define XSP_CR_MANUAL_SS_MASK	     0x00000080 /**< Manual slave select assert */
#define XSP_CR_TRANS_INHIBIT_MASK  0x00000100 /**< Master transaction inhibit */
#define XSP_CR_RESET_DONE_MASK	   0x00000000 /**< FIFO reset complete */
#define XSP_CR_LSB_FIRST_MASK   	 0x00000200

#define XSP_SR_RX_EMPTY_MASK	     0x00000001 /**< Receive Reg/FIFO is empty */
#define XSP_SR_RX_FULL_MASK	       0x00000002 /**< Receive Reg/FIFO is full */
#define XSP_SR_TX_EMPTY_MASK	     0x00000004 /**< Transmit Reg/FIFO is empty */
#define XSP_SR_TX_FULL_MASK	       0x00000008 /**< Transmit Reg/FIFO is full */
#define XSP_SR_MODE_FAULT_MASK	   0x00000010 /**< Mode fault error */
#define XSP_SR_SLAVE_MODE_MASK	   0x00000020 /**< Slave mode select */

/*
 * The following bits are available only in axi_qspi Status register.
 */
#define XSP_SR_CPOL_CPHA_ERR_MASK  0x00000040 /**< CPOL/CPHA error */
#define XSP_SR_SLAVE_MODE_ERR_MASK 0x00000080 /**< Slave mode error */
#define XSP_SR_MSB_ERR_MASK	       0x00000100 /**< MSB Error */
#define XSP_SR_LOOP_BACK_ERR_MASK  0x00000200 /**< Loop back error */
#define XSP_SR_CMD_ERR_MASK	       0x00000400 /**< 'Invalid cmd' error */

// Software reset of the SPI core
void spi_soft_reset(uint32_t baseaddr)
{
  reg_wr(baseaddr + XSP_SRR_OFFSET, 0xA);
}

// Configure the spi parameters.
void spi_setup(uint32_t baseaddr, unsigned cpol, unsigned cpha, unsigned lsb_first)
{
  uint32_t cr = reg_rd(baseaddr + XSP_CR_OFFSET);

  if (cpol) {
    cr |= XSP_CR_CLK_POLARITY_MASK; 
  } else {
    cr &= ~(XSP_CR_CLK_POLARITY_MASK); 
  }
  
  if (cpha) {
    cr |= XSP_CR_CLK_PHASE_MASK; 
  } else {
    cr &= ~(XSP_CR_CLK_PHASE_MASK); 
  }

  if (lsb_first) {
    cr |= XSP_CR_LSB_FIRST_MASK;
  } else {
    cr &= ~(XSP_CR_LSB_FIRST_MASK);
  }
	
  reg_wr(baseaddr + XSP_CR_OFFSET, cr);

  return;
}


// Enable / disable internal loopback mode for test / debug
void spi_loopback(uint32_t baseaddr, unsigned loopback)
{
  uint32_t cr = reg_rd(baseaddr + XSP_CR_OFFSET);

  if (loopback) {
    cr |= XSP_CR_LOOPBACK_MASK; 
  } else {
    cr &= ~(XSP_CR_LOOPBACK_MASK); 
  }

	reg_wr(baseaddr + XSP_CR_OFFSET, cr);

  return;
}


// Run a spi transcation. Only supports transaction lengths up to
// SPI_TXRX_FIFO_DEPTH bytes. 
int spi_txrx(uint32_t baseaddr, uint8_t * tx_buf, uint8_t * rx_buf, unsigned size)
{
  uint32_t cr;
  uint32_t ssr;

  // Make sure transaction is within the allowed range
  if (size > SPI_TXRX_FIFO_DEPTH) {
    // Error: as of now, this only supports SPI_TXRX_FIFO_DEPTH transactions
    return 1; 
  }

  // Force slave select is set to all ones
  ssr = 0xFFFFFFFF;
  reg_wr(baseaddr + XSP_SSR_OFFSET, ssr);

  // Enable spi, reset fifos, and make sure transactions are inhibited
  cr = reg_rd(baseaddr + XSP_CR_OFFSET);
  cr |= (XSP_CR_TRANS_INHIBIT_MASK | XSP_CR_MANUAL_SS_MASK | 
         XSP_CR_MASTER_MODE_MASK | XSP_CR_TXFIFO_RESET_MASK | 
         XSP_CR_RXFIFO_RESET_MASK);
  reg_wr(baseaddr + XSP_CR_OFFSET, cr);

  // Set slave select to slave 0
  ssr = reg_rd(baseaddr + XSP_SSR_OFFSET);
  ssr &= ~0x1;
  reg_wr(baseaddr + XSP_SSR_OFFSET, ssr);

  // Write tx_buf to the tx fifo
  for (unsigned i0 = 0; i0 < size; i0++) {
    reg_wr(baseaddr + XSP_DTR_OFFSET, tx_buf[i0]);
  }

  // Uninhibit and enable to start the transfer
  cr = reg_rd(baseaddr + XSP_CR_OFFSET);
  cr &= ~(XSP_CR_TRANS_INHIBIT_MASK);
  cr |= XSP_CR_ENABLE_MASK;
  reg_wr(baseaddr + XSP_CR_OFFSET, cr);


  // Wait for tx fifo empty
  int i = 0; 
  while (!(reg_rd(baseaddr + XSP_SR_OFFSET) & XSP_SR_TX_EMPTY_MASK)) {
    usleep(SPI_TXRX_TIME_US);
    i++;
    if (i > SPI_TXRX_TRIES) {
      // Error: Transaction timeout
      return 1;
    }
  }

  // And wait for rx fifo not empty
  i = 0; 
  while ((reg_rd(baseaddr + XSP_SR_OFFSET) & XSP_SR_RX_EMPTY_MASK)) {
    usleep(SPI_TXRX_TIME_US);
    i++;
    if (i > SPI_TXRX_TRIES) {
      // Error: Transaction timeout
      return 1;
    }
  }
  
  // Dump the rx fifo into rx_buf
  for (unsigned i0 = 0; i0 < size; i0++) {
    rx_buf[i0] = reg_rd(baseaddr + XSP_DRR_OFFSET);
  }

  // Unset slave select
  ssr = reg_rd(baseaddr + XSP_SSR_OFFSET);
  ssr |= 0x1;
  reg_wr(baseaddr + XSP_SSR_OFFSET, ssr);

  // Disable
  cr = reg_rd(baseaddr + XSP_CR_OFFSET);
  cr |= (XSP_CR_TRANS_INHIBIT_MASK);
  cr &= ~(XSP_CR_ENABLE_MASK);
  reg_wr(baseaddr + XSP_CR_OFFSET, cr);

  // Done!
  return 0;
}
