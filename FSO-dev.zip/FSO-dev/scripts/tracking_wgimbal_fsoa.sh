#!/bin/bash

ros2 launch /opt/fso_prj/FSO/scripts/tracking_wgimbal_fsoa.yaml