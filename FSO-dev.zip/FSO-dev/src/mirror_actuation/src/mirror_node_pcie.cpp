#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <thread>
#include "timer/timer.h"

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
/////////////////////////////////
// NODE HPP FILE HERE
/////////////////////////////////
#include "../../custom_interfaces/custom_dt.h"
#include "mirror_node.hpp"
#include "custom_interfaces/msg/camera_coords_message.hpp"
#include "custom_interfaces/msg/heart_beat.hpp"  
#include "custom_interfaces/msg/move_mirror.hpp"
#include "custom_interfaces/srv/move_mirror.hpp"
#include "../../custom_interfaces/cmds.h"

extern "C"
{
#include "fpga_drivers/mirror.h"
#include "fpga_drivers/spi.h"
#include "fpga_drivers/reg.h"
}

/*
 * CLASS NAME  
 * 
 * ROS2 PARAMETERS
 * 
 * 
 * NOTES
 * 
 */

using namespace std::chrono_literals;
using std::placeholders::_1;

class MIRROR : public rclcpp::Node
{
  public:
  MIRROR() : Node("mpci_node")
  {
    initialization();
    
    rcmd.addr = 0x1007;                                          //
    mirror_rd_regs(0x0D0000, &rcmd, &rrsp);                      //   Get the Status from the mirrior. This is simple debug code. Not production
    mirror_rd_regs(0x0D0000, &rcmd, &rrsp);                      //
    printf("INFO: Mirror Sys Status : 0x%X\n", rrsp.prvrdat);    //

    std::string statusMsgName = this->get_name();
    status = this->create_publisher<custom_interfaces::msg::HeartBeat>(statusMsgName, 10);

    heartBeatTimer = this->create_wall_timer(1000ms, std::bind(&MIRROR::heartBeat, this));
    watchDogTimer = this->create_wall_timer(500ms, std::bind(&MIRROR::watchDog, this));
    
    test = this->create_service<custom_interfaces::srv::MoveMirror>("move_mirror_service", std::bind(&MIRROR::moveMirrorServiceCallback, this, std::placeholders::_1, std::placeholders::_2));

    //parameter_callback_handle = this->add_on_set_parameters_callback(std::bind(&MIRROR::parameter_change_callback, this, _1));
  
    recvMoveCmd = this->create_subscription<custom_interfaces::msg::MoveMirror>("move_mirror", 10, std::bind(&MIRROR::moveMirrorCallback, this, _1));
  }

  ~MIRROR()
  {
    initializeMirrorHome(); // Send the mirror back home
  }
  private:

  void declareParams()
  {
    nodeState = status::state::unknown; 
    nodeCommType = status::commType::spi;
    datafield = "empty";
    moveToXY = "xy=0.0";
    
    this->declare_parameter("MIRROR_ADDR", 0x0D0000);    // Mirror base address
    this->declare_parameter("REG_OFFSET", 0x01000C);
    this->declare_parameter("mirror_id_param", -1);
    this->declare_parameter("moveCmdXY", "xy=0;0");
    this->declare_parameter("closed_loop", true);        // Closed loop command (used in initialization)

    MIRROR_ADDR = this->get_parameter("MIRROR_ADDR").as_int();
  }

  void dumpRegisters()
  {                           

  }

  void enableMirror()
  {
    RCLCPP_INFO(this->get_logger(), "ENABLING MIRROR");       // Enables the pins required to control the mirror
    uint32_t reg = 0;                                         // The FSO Control node has the addresses for resetting
    reg = reg_rd(0x01000C);                                   // and controlling the enable pins for the mirror.
    uint32_t mirror_0_en_bitmask = (0x0001 << 13);            // The powerCycleMirror() function demonstrates a better
    reg &= ~(mirror_0_en_bitmask);                            // of such. This is really never used anymore.
    reg_wr(0x01000C, reg);

    reg = reg_rd(0x01000C);
    uint32_t mirror_1_en_bitmask = (0x0001 << 14);
    reg &= ~(mirror_1_en_bitmask);
    reg_wr(0x01000C, reg);

    RCLCPP_INFO(this->get_logger(), "MIRROR ENABLED");
  }

  bool enableClosedLoop()
  {
    RCLCPP_INFO(this->get_logger(), "ENABLING CLOSED LOOP");
    bool success = false;

    wcmd.addr0 = MISC_SETT_ADDR;                              // Registers used for enabling closed loop. Refer to cmds.h
    wcmd.addr1 = MISC_SETT_ADDR;                              // for the list of registers used in this code
    wcmd.wdat0 = CLOSED_LOOP_XY;
    wcmd.wdat1 = CLOSED_LOOP_XY;

    sendWriteCmd(&wcmd, &wrsp);                               // Write to the mirror, and check for a response

    sleep(1);

    rcmd.addr = MISC_SETT_ADDR;                               //
                                                              //  Read the misc register to ensure closed loop is enabled
    sendReadCmd(&rcmd, &rrsp);                                //
    // mirror_rd_regs(MIRROR_ADDR, &rcmd, &rrsp);
    // mirror_rd_regs(MIRROR_ADDR, &rcmd, &rrsp);

    if (rrsp.prvrdat == 0x2)
    {
      success = true;
      RCLCPP_INFO(this->get_logger(), "SUCCESS: ENABLE CLOSED LOOP");
    }
    else
    {
      RCLCPP_ERROR(this->get_logger(), "FAILED: ENABLE CLOSED LOOP");
    }

    return success;
  }

  bool enableOpenLoop()
  {
    RCLCPP_INFO(this->get_logger(), "ENABLING OPEN LOOP");
    bool success = false;

    wcmd.addr0 = MISC_SETT_ADDR;                                // Registers used for enabling closed loop. Refer to cmds.h
    wcmd.addr1 = MISC_SETT_ADDR;                                // for the list of registers used in this code
    wcmd.wdat0 = OPEN_LOOP_XY;
    wcmd.wdat1 = OPEN_LOOP_XY;
      
    bool res = sendWriteCmd(&wcmd, &wrsp);                      // Write to the mirror, and check for a response

    if (res == 0)
    {
      success = true;
    }
    else
    {
      RCLCPP_ERROR(this->get_logger(), "FAILED TO ENABLE OPEN LOOP");
    }

    return success;
  }

  // Reads the status register, returns true if successfully read the register
  bool getStatus()
  {
    bool success = false;

    rcmd.addr = SYS_STATUS_REG;
    
    sendReadCmd(&rcmd, &rrsp);

    return success;
  }

  // Heart beat, calling publishStatus()
  void heartBeat()
  {
    publishStatus(datafield);
  }

  // Same as previous node just reduced logic
  bool isBitSet(int input, int bitToCheck)
  {
    //Check if a bit is set, input is the num to check
    //                       bitToCheck is the nth bit to verify
 
    bool success = (input & (1 << bitToCheck) ? true : false);

    return success;
  }

  // Checks status message and prints to console the issues indicated by the status bits
  bool isMirrorHealthy()
  {
    std::map<int, std::string> errorCodes;  //Key:  Bit | Value: Description
    errorCodes.insert({0, "Proxy not connected!"});
    errorCodes.insert({1, "Proxy temperature threshold is reached!"});
    errorCodes.insert({2, "Mirror temperature threshold is reached!"});
    errorCodes.insert({3, "Mirror EEPROM not valid!"});
    errorCodes.insert({4, "Mirror not stable!"});
    errorCodes.insert({5, "Output current limit is reached!" });
    errorCodes.insert({6, "Output current average limit is reached!"});
    errorCodes.insert({7, "XY input is trimmed!"});
    errorCodes.insert({8, "Proxy was disconnected!"});
    errorCodes.insert({9, "Proxy temperature threshold was reached!"});
    errorCodes.insert({10, "Mirror temperature threshold was reached!"});
    errorCodes.insert({11, "Output current limit was reached!"});
    errorCodes.insert({12, "Output current average limit was reached!"});
    errorCodes.insert({13, "XY input was trimmed!"});
    errorCodes.insert({14, "FrontEnd power supply has fault!"});
    errorCodes.insert({15, "FrontEnd power supply had fault!"});
    errorCodes.insert({16, "Channel 0 output fault condition!"});
    errorCodes.insert({17, "Channel 0 output had fault condition!"});
    errorCodes.insert({18, "Channel 1 output fault condition!"});
    errorCodes.insert({19, "Channel 1 output had fault condition!"});
    errorCodes.insert({20, "Driver over-heat fault!"});
    errorCodes.insert({21, "Driver had over-heat fault!"});
    errorCodes.insert({22, "Device on proxy (mirror) not detected!"});
    errorCodes.insert({23, "Device on proxy (mirror) was not detected!"});
    errorCodes.insert({24, "Device on proxy has impedance error!"});
    errorCodes.insert({25, "Device on proxy had impedance error!"});
    errorCodes.insert({26, "Proxy has over-current fault on 3V3 supply line!"});
    errorCodes.insert({27, "Proxy had over-current fault on 3V3 supply line!"});
    errorCodes.insert({28, "Device sensor (PD) out of range!"});
    errorCodes.insert({29, "Device sensor (PD) was out of range!"});
    errorCodes.insert({30, "Device I2C communication error!"});
    errorCodes.insert({31, "Device had I2C communication error!"});
    
    bool success = true;
    int statusBits;

    int res = getStatus(); // Get the status

    if (res == 0)
    {
      success = true;
      statusBits = rrsp.prvrdat;

      for(int i = 0; i < 32; i++)
      {
        if(isBitSet(statusBits, i))
        {
          success = false;
          std::map<int, std::string>::iterator it;
          it = errorCodes.find(i);
          RCLCPP_ERROR(this->get_logger(), MIRROR_STATUS_ERROR, it->second.c_str());
        }
      }
    }

    return success;
  }

  bool initialization()
  {
    bool success = false;
    nodeState = status::state::initializating;

    dumpRegisters(); // Not implemented yet, could be useful when seeing the current register values

    RCLCPP_INFO(this->get_logger(), "INTIALIZATION PROCESS STARTED");
    declareParams();
    initializeFlags();

    success = initializeMirror(); // Sets the basic register values for the mirror, including spi and closed loop mode

    if (success)
    {
      nodeState = status::state::running;
      RCLCPP_INFO(this->get_logger(), "INTIALIZATION PROCESS SUCCESS!");
    }
    else
    {
      nodeState = status::state::error;
      RCLCPP_ERROR(this->get_logger(), "INTIALIZATION PROCESS FAILED!");
    }

    timer.reset();
    timer.start();
    return success;
  }

  void initializeFlags()
  {

  }

  bool initializeMirror()
  {
    bool success = false;

    RCLCPP_INFO(this->get_logger(), "INTIALIZING MIRROR STARTED");

    bool spy_init = initializeSpi(); // Set up SPI interface (David's code)

    if (!spy_init)
    {
      RCLCPP_ERROR(this->get_logger(), "SPI INIT FAILED");
    }

    bool mirror_home = initializeMirrorHome(); // Send the mirror home on startup

    if (!mirror_home)
    {
      RCLCPP_ERROR(this->get_logger(), "MIRROR HOME FAILED");
    }

    bool set_loop_setting = setLoopSetting(); // Set open loop or open loop

    if (!set_loop_setting)
    {
      RCLCPP_ERROR(this->get_logger(), "LOOP SETTING FAILED");
    }

    success = spy_init && set_loop_setting && mirror_home;

    return success;
  }

  bool initializeMirrorHome()
  {
    RCLCPP_INFO(this->get_logger(), "MIRROR GOING HOME");

    bool success = false;

    wcmd.addr0 = CURRENT_X;                                     //
    wcmd.addr1 = CURRENT_Y;                                     // 
    wcmd.wdat0 = 0x0;                                           // Set the current registers to 0 (these are not the same as the XY coord)
    wcmd.wdat1 = 0x0;                                           // registers, this is on purpose to clear the mirror drivers of input
                                                                //
    int res = sendWriteCmd(&wcmd, &wrsp);                       //

    if (res == 0)
    {
      success = true;
    }

    return success;
  }

  bool initializeSpi()
  {
    bool success = false;
    RCLCPP_INFO(this->get_logger(), "INITIALIZING SPI");

    //enableMirror();

    mirror_setup(MIRROR_ADDR); // Setup SPI

    success = true;

    return success;
  }

  void moveMirrorCallback(const custom_interfaces::msg::MoveMirror::SharedPtr msg)
  {
    updateXY(msg->x, msg->y); // for the pub/sub bus
  }

  void moveMirrorServiceCallback(const std::shared_ptr<custom_interfaces::srv::MoveMirror::Request> request, std::shared_ptr<custom_interfaces::srv::MoveMirror::Response> response)
  {
    float x = request->x;
    float y = request->y;     // for the ROS service bus
    bool success = updateXY(x,y);
    response->empty = success;
  }

  // Not production code, simply resest the camera before every use. I found this nice for resetting to default starting point every time i run the node
  void powerCycleMirror()
  {
    int test = reg_rd(0x01000C);
    reg_wr(0x01000C, test^0x00008000);
    test = reg_rd(0x01000C);
    sleep(2);
    reg_wr(0x01000C, test^0x00008000);
    test = reg_rd(0x01000C);
    sleep(5);
  }

  // Publishes the status of the mirror
  void publishStatus(std::string datafield)
  {
    auto msg = custom_interfaces::msg::HeartBeat();
    msg.epoch = timer.timeSinceEpoch_us();
    msg.node_state = (int)nodeState;
    msg.comm_type = (int)nodeCommType;
    status->publish(msg);
  }
  
  // Utilizes davids user driver code to get responses from the mirror. Note the read must be used twice.
  void sendReadCmd(mirror_rd_tx_t *cmd, mirror_rd_rx_t *rsp)
  {
    mirror_rd_regs(MIRROR_ADDR, cmd, rsp);
    mirror_rd_regs(MIRROR_ADDR, cmd, rsp);
  }

  // Utilizes davids user driver code to send commands. 
  bool sendWriteCmd(mirror_wr_tx_t *cmd, mirror_wr_rx_t *rsp)
  { 
    bool success = false;                               // Im confident the mirror will respond with "error messages" even when there
                                                        // is no fault in the command. The mirror will move when X/Y commands are sent
    int res = mirror_wr_regs(MIRROR_ADDR, cmd, rsp);    // but returns that the write failed. This must be tested.

    if (res == 0)
    {
      success = true;
      RCLCPP_INFO(this->get_logger(), "Write Command Successfully Sent!");
    }

    return success;
  }

  // Checks ROS parameter to enable looping mode
  bool setLoopSetting()
  {
    RCLCPP_INFO(this->get_logger(), "SETTING LOOP MODE");
    bool success = false;

    loop_mode = this->get_parameter("closed_loop").as_bool();
    
    if (loop_mode)
    {
      success = enableClosedLoop();
    }
    else
    {
      success = enableOpenLoop();
    }
    
    return success;
  }

  // Sets up the command with the XY coords and wrtites to mirror
  bool updateXY(double Xm, double Ym)
  {
    bool success = false;
    if (Xm > 1 || Xm < -1 || Ym > 1 || Ym < -1) // Boundaries
    {
      RCLCPP_ERROR(this->get_logger(), MIRROR_COORDS_OOR, Xm, Ym);
    }
    else
    {
      wcmd.addr0 = STATIC_REG_X; // Registers for static input of XY coordinates
      wcmd.addr1 = STATIC_REG_Y;
      
      // Cast XY to IEEE 754 Floats
      float x = static_cast<float>(Xm);
      float y = static_cast<float>(Ym);
  
      memcpy(&wcmd.wdat0, &x, sizeof(uint32_t)); // Copy those values into memory (safer than using assingment operator)
      memcpy(&wcmd.wdat1, &y, sizeof(uint32_t));
  
      int res = sendWriteCmd(&wcmd, &wrsp);
  
      if (res == 0) // Checks response, please refer to my previous comments concerning this return value
      {
        success = true;
        RCLCPP_INFO(this->get_logger(), SEND_MIRROR_CMD, Xm, Ym);
      }
      else
      {
        RCLCPP_ERROR(this->get_logger(), SEND_MIRROR_CMD_FAILED, Xm, Ym);
      }
    }
    return success;
  }

  // Watchdog
  void watchDog()
  {
    if(!isMirrorHealthy())
    {
      nodeState = status::state::error;
    }
  }

  private:
  utility::Timer timer;
  status::state nodeState;
  status::commType nodeCommType;

  rclcpp::Subscription<custom_interfaces::msg::MoveMirror>::SharedPtr recvMoveCmd;
  rclcpp::Service<custom_interfaces::srv::MoveMirror>::SharedPtr test;
  rclcpp::Publisher<custom_interfaces::msg::HeartBeat>::SharedPtr status;
  rclcpp::TimerBase::SharedPtr watchDogTimer;
  rclcpp::TimerBase::SharedPtr heartBeatTimer;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;

  float epoch;
  int comm_type;
  int node_state;
  int loop_mode;
  std::string datafield;

  // PCIE
  int MIRROR_ADDR;
  mirror_wr_tx_t wcmd;
  mirror_wr_rx_t wrsp;
  mirror_rd_tx_t rcmd;
  mirror_rd_rx_t rrsp;

  std::string moveToXY;
};

int main(int argc, char * argv[]){
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MIRROR>());
  rclcpp::shutdown();
  return 0;
}