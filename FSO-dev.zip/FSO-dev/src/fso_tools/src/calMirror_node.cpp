#include "rclcpp/rclcpp.hpp"

#include "timer/timer.h"


#include "custom_interfaces/msg/camera_coords_message.hpp"
#include "custom_interfaces/msg/move_mirror.hpp"

#include "../../custom_interfaces/custom_dt.h"

#include <filesystem>
#include <iostream>
#include <fstream>


using std::placeholders::_1;
using namespace std::chrono_literals;

class CalMirror : public rclcpp::Node
{

  public:
    CalMirror() : Node("calMirror_node")
    {
      declareParams();
      initializeFlags();
      initialization();

      cameraCoords = this->create_subscription<custom_interfaces::msg::CameraCoordsMessage>("camera_coords", 10, std::bind(&CalMirror::recvCameraCoords, this, _1)); 
      moveMirror = this->create_publisher<custom_interfaces::msg::MoveMirror>("move_mirror", 10);

      parameter_callback_handle = this->add_on_set_parameters_callback(std::bind(&CalMirror::parameter_change_callback, this, std::placeholders::_1));

      watchDogTimer = this->create_wall_timer(100ms, std::bind(&CalMirror::watchdog, this));

      sendMoveMirror(0.0, 0.0);  //always start at mirror 0,0
    }

    ~CalMirror()
    {
      
    }

  private:

  void createCalTable()
  {
    std::string ts = timer.getTimeStamp();
    std::string  log_loc = "~/calResults";

    std::string fileName = ts;
    fileName.append("_CalTable_Testing");

    std::ofstream logFile(fileName);

    if(logFile.is_open())
    { 

      logFile << "TimeFinished: " << ts << std::endl;

      std::vector<std::vector<CalData>>::iterator it_row;
      std::vector<CalData>::iterator it_col;

      for(it_row = calTable_row.begin(); it_row != calTable_row.end(); ++it_row)
      {
          for(it_col = it_row->begin(); it_col != it_row->end(); ++it_col)
          {
            logFile << std::setprecision(4) << it_col->xP
                    << ";" 
                    << std::setprecision(4) << it_col->yP 
                    << ";" 
                    << std::setprecision(4) << it_col->xM  
                    << ";" 
                    << std::setprecision(4) << it_col->yM 
                    << std::endl;
          }  
      }
    }

    logFile.close();
  }

  void declareParams()
  {
    //Setup ROS Parameters
    this->declare_parameter("findCenter", false);
    this->declare_parameter("findTopLeft", false);
    this->declare_parameter("findTopRight", false);
    this->declare_parameter("findBottomRight", false);
    this->declare_parameter("findBottomLeft", false);

    this->declare_parameter("buildCalTable", false);
    this->declare_parameter("buildCalTableV2", false);

    this->declare_parameter("goToMirrorHome", false);

    this->declare_parameter("moveToPixel", false);
    this->declare_parameter("pixelX", 10);
    this->declare_parameter("pixelY", 10);

    this->declare_parameter("calDistance_mm", 0.0);

    pixelX = 10;
    pixelY = 10;
  }

  void createPolyApproxCoeffVectors()
  {
      //std::vector<CalData> calTable_col;
      //std::vector<std::vector<CalData>> calTable_row;  

      std::vector<std::vector<CalData>>::iterator it_row;
      std::vector<CalData>::iterator it_col;

      for(it_row = calTable_row.begin(); it_row != calTable_row.end(); ++it_row)
      {
        for(it_col = it_row->begin(); it_col != it_row->end(); ++it_col)
        {
          double tX_radians = convertPixelPointToAngle(it_col->xP, pixelSize_um, focalLength_mm);
          double tX_degrees = tX_radians * 180 / M_PI;
          thetaX.push_back(tX_degrees);

          double tY_radians = convertPixelPointToAngle(it_col->yP, pixelSize_um, focalLength_mm);
          double tY_degrees = tY_radians * 180 / M_PI;
          thetaY.push_back(tY_radians);

          xM.push_back(it_col->xM);
          yM.push_back(it_col->yM);
        }
      }
  }



  void initializeFlags()
  { 
    findCenter      = false;
    findTopLeft     = false;
    findTopRight    = false;
    findBottomRight = false;
    findBottomLeft  = false;
    moveToPixel     = false;

    buildCalTable   = false;
    buildCalTableV2 = false;
    findPoint       = false;
  }

  void initialization()
  {
    timer.reset();
    timer.start();

    //set current position of the mirror to home
    xM_current = 0;
    yM_current = 0;   

    xM_center = 0;
    yM_center = 0;
  }
  
  void initializeCalTable()
  {
    findPoint = true;

    if(buildCalTable)
    {
      //Start at top left or (0,0)pixel plus offset for FOV
      point_xP = 10;
      point_yP = 10;
    }

    //Clear Cal Table
    calTable_col.clear();
    calTable_row.clear();
  }

  bool moveMirrorToPixelPoint(int xPixel,                 //Cam Pixel to Find
                              int yPixel,
                              double xP_current,          //Latest Reported Cam Pixel
                              double yP_current,  
                              double xStepSize = 0.0003,  
                              double yStepSize = 0.0003)
  {

    int xP = std::round(xP_current);
    int yP = std::round(yP_current);

    bool foundMirrorX = false;
    bool foundMirrorY = false;
 
    if(xPixel == xP)
    {
      foundMirrorX = true;
    }
    else if(xPixel < xP)
    {
      xM_current = xM_current + (-1 * xStepSize);
      foundMirrorX = false;
    }
    else if(xPixel > xP)
    {
      xM_current = xM_current + xStepSize;
      foundMirrorX = false;
    }

    if(yPixel == yP)
    {
      foundMirrorY = true;
    }
    else if(yPixel < yP)
    {
      yM_current = yM_current + yStepSize;
      foundMirrorY = false;
    }
    else if(yPixel > yP)
    {
      yM_current = yM_current + (-1 * yStepSize);
      foundMirrorY = false;
    } 

    sendMoveMirror(xM_current, yM_current); 

    bool keepLooking = !(foundMirrorX && foundMirrorY);  //invert!!!!!!!!!!!!!!!

    return keepLooking;
  }

  rcl_interfaces::msg::SetParametersResult parameter_change_callback(const std::vector<rclcpp::Parameter> &params)
  {
    //Can not use new parameters until they are set. They are not set until this function is complete. 
    //Minimize time spent here - use the watchdog to perform actions on this node
    auto result = rcl_interfaces::msg::SetParametersResult();
    result.successful = true;

    for(const auto &param : params)
    {

      std::string name = param.get_name();
      rclcpp::ParameterType pt = param.get_type();

      if(name == "findCenter" && pt == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        findCenter = param.as_bool();
      }
      else if(name == "findTopLeft" && pt == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        findTopLeft = param.as_bool();
      }
      else if(name == "findTopRight" && pt == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        findTopRight = param.as_bool();
      }
      else if(name == "findBottomRight" && pt == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        findBottomRight = param.as_bool();
      }    
      else if(name == "findBottomLeft" && pt == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        findBottomLeft = param.as_bool();
      }
      else if(name == "buildCalTable" && pt == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        buildCalTable = param.as_bool();
        if(buildCalTable)
        {
          initializeCalTable(); 
        }
      }
      else if(name == "buildCalTableV2" && pt == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        buildCalTableV2 = param.as_bool();
        if(buildCalTableV2)
        {
          initializeCalTable();
        }
      }
      else if(name == "goToMirrorHome" && pt == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        if(param.as_bool())
        {
          sendMoveMirror(0,0); 
        }
      }
      else if(name == "moveToPixel" && pt == rclcpp::ParameterType::PARAMETER_BOOL)
      {
        moveToPixel = param.as_bool();
      }
      else if(name == "pixelX" && pt == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        pixelX = param.as_int();
      }
      else if(name == "pixelY" && pt == rclcpp::ParameterType::PARAMETER_INTEGER)
      {
        pixelY = param.as_int();
      }
      else
      {
        result.successful = false;
        result.reason = "Parameter not supported";
      }
    }
    return result;
  }

  void recvCameraCoords(const custom_interfaces::msg::CameraCoordsMessage::SharedPtr msg) 
  {
    //All processing done in real time as the images come in
    RCLCPP_INFO(this->get_logger(), MSG_CAM_COORD, 0, msg->x, msg->y, msg->area, msg->brightness, msg->focal_length); 
    int16_t fov_buffer_pixels = 10;

    focalLength_mm = msg->focal_length;
    pixelSize_um = msg->p_um;
    
    if(findCenter)
    {
      findCenter = moveMirrorToPixelPoint(msg->img_width /2, 
                                          msg->img_hgt /2,
                                          msg->x,
                                          msg->y
                                          );
      if(!findCenter)  //Center found save the data
      {
        xM_center = xM_current;
        yM_center = yM_current;
      }
    }

    else if(findTopLeft)
    {
      findTopLeft = moveMirrorToPixelPoint(msg->img_width - (msg->img_width - fov_buffer_pixels), 
                                          msg->img_hgt - (msg->img_hgt - fov_buffer_pixels),
                                          msg->x,
                                          msg->y
                                          );   

      if(!findTopLeft)  //Top Left found save the data
      {
        xM_tl = xM_current;
        yM_tl = yM_current;       
      }  
    }

    else if(findTopRight)
    {
      findTopRight = moveMirrorToPixelPoint((msg->img_width - fov_buffer_pixels), 
                                             msg->img_hgt - (msg->img_hgt - fov_buffer_pixels),
                                             msg->x,
                                             msg->y
                                             );   

      if(!findTopRight)  //Top Left found save the data
      {
        xM_tr = xM_current;
        yM_tr = yM_current;;
      }  
    }

    else if(findBottomRight)
    {
      findBottomRight = moveMirrorToPixelPoint((msg->img_width - fov_buffer_pixels), 
                                             (msg->img_hgt - fov_buffer_pixels),
                                             msg->x,
                                             msg->y
                                             );   

      if(!findBottomRight)  //Top Left found save the data
      {
        xM_br = xM_current;
        yM_br = yM_current;
      }  
    }

    else if(findBottomLeft)
    {
      findBottomLeft = moveMirrorToPixelPoint(msg->img_width - (msg->img_width - fov_buffer_pixels), 
                                             (msg->img_hgt - fov_buffer_pixels),
                                             msg->x,
                                             msg->y
                                             );   

      if(!findBottomLeft)  //Bottom Left found save the data
      {
        xM_bl = xM_current;
        yM_bl = yM_current;
      }  
    }

    else if(moveToPixel)
    {
      moveToPixel = moveMirrorToPixelPoint(pixelX,  
                                           pixelY, 
                                           msg->x,
                                           msg->y
                                           );   
    }

    else if(buildCalTable)  
    {   
        if(findPoint)
        {
          double XpixelStep = 10;
          double YpixelStep = 10;

          findPoint = moveMirrorToPixelPoint(point_xP, 
                                             point_yP, 
                                             msg->x, 
                                             msg->y
                                            ); 

          if(!findPoint)
          {
            calTable_col.emplace_back(point_xP, point_yP, xM_current, yM_current); 

            point_xP += XpixelStep;  //move to next column
            if(point_xP <= msg->img_width - fov_buffer_pixels)
            {
              findPoint = true;        //look for the next point
            }
            else
            {
              //save previous row and move to next row
              calTable_row.push_back(calTable_col);  
              calTable_col.clear();

              //Move the mirror the first position of the current row in one move
              double xM_FirstCol = calTable_row.back().at(0).xM;
              double yM_LastRow = calTable_row.back().at(0).yM;
              sendMoveMirror(xM_FirstCol, yM_LastRow); 
              usleep(1000 * 100);  //Delay is neede to give time for the mirror to move that far



              sendMoveMirror(xM_current, yM_current);
              point_xP = fov_buffer_pixels;
              point_yP += YpixelStep;  //move to next row
              if(point_yP > msg->img_hgt - fov_buffer_pixels)
              {
                buildCalTable = false;
                findPoint = false;
                createCalTable();
                RCLCPP_INFO(this->get_logger(), "Calibration Complete");
              }
              else
              {
                findPoint = true;  //Keep looking
              }
            }
          }
        }
    }
  }

  void sendMoveMirror(float x, float y)
  {
      RCLCPP_INFO(this->get_logger(), SEND_MIRROR_CMD, x, y);

      xM_current = x;
      yM_current = y;
      auto moveMirrorMsg = custom_interfaces::msg::MoveMirror();
      moveMirrorMsg.x = x;
      moveMirrorMsg.y = y;
      moveMirror->publish(moveMirrorMsg); 
  }

  void watchdog()
  {


  }

  utility::Timer timer;

  double point_xP;  //Pixel point to find
  double point_yP;  //Pixel point to find
  //int vectorRow;

  double xM_current; //mirror current location absolute from mirror home x=0
  double yM_current; //mirror current location absolute from mirror home y=0

  double xM_center;  //mirror center refrenced to camera center
  double yM_center;  //mirror center refrenced to camera center

  double xM_tl;  //mirror top left in camera frame of refrenece
  double yM_tl;  //mirror top left in camera frame of reference

  double xM_tr;  //mirror top right in camera frame of refrence
  double yM_tr;  //mirror top right in camera frame of refrence

  double xM_br;  //mirror bottom right in camera frame of refrence
  double yM_br;  //mirror bottomr right in camera frame of refrence

  double xM_bl;  //mirror bottom left in camera frame of refrence
  double yM_bl;  //mirror bottom left in camera frame of refrence

//used to track the search window for the mirror
  //double xM_window_start;
  //double xM_window_stop;

  //double yM_window_start;
  //double yM_window_stop;

  //double xM_moveTo;  //Column
  //double yM_moveTo;  //Row

  //Flags
  bool findCenter;
  bool findTopLeft;
  bool findTopRight;
  bool findBottomRight;
  bool findBottomLeft;
  bool moveToPixel;

  bool buildCalTable;
  bool buildCalTableV2;
  bool findPoint;

  int pixelX;  //user defined pixel
  int pixelY;  //user defined pixel

  std::string log_loc;

  //Buffers to store the pixel mapping to mirror mapping
  std::vector<CalData> calTable_col;
  std::vector<std::vector<CalData>> calTable_row;   

  //Vectors for linear transform 
  //Used to find the poly approx coeff
  std::vector<double> thetaX;
  std::vector<double> thetaY;
  std::vector<double> xM;
  std::vector<double> yM;

  double focalLength_mm;
  double pixelSize_um;
  double calDistance_mm;  //Distance from Camera Lens Focal Point to projection screen.

  //double FOVoffset;

  rclcpp::Subscription<custom_interfaces::msg::CameraCoordsMessage>::SharedPtr cameraCoords;
  rclcpp::Publisher<custom_interfaces::msg::MoveMirror>::SharedPtr moveMirror;

  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle;

  rclcpp::TimerBase::SharedPtr watchDogTimer;
};


int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<CalMirror>());
  rclcpp::shutdown();
  return 0;
}
