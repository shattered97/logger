// Copyright 2016 Open Source Robotics Foundation, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <chrono>
#include <functional>
#include <memory>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "mirror_node.hpp"
#include "custom_interfaces/msg/mirror_update.hpp"
using std::placeholders::_1;

/*
 * Mirror
 * Mirror represents a virtual model of a physical mirror. It maintains the mirror's state, and has methods to enact a change in the physical state of the mirror.
 * Note that Mirror doesn't directly update the physical mirror. The mirrorUpdate message is first sent out to a Mirror_Translator, which parses the mirrorUpdate and
 * then dispatches the command to the selected interface.
 * 
 * ROS2 PARAMETERS
 * - mirrorIdParam: The ID of the mirror. Used when addressing messages to a serial interface.
 */

class Mirror : public rclcpp::Node {
  public:
    Mirror() : Node("mirror"){
      this->declare_parameter("mirrorIdParam", -1);
      mirrorId = this->get_parameter("mirrorIdParam").as_int();
      mirrorUpdatePub_ = this->create_publisher<custom_interfaces::msg::MirrorUpdate>("mirror_update", 10);
      mirrorCmdSub_ = this->create_subscription<std_msgs::msg::String>(
        "mirror_toggle", 10, std::bind(&Mirror::mirrorCmdCallback_, this, _1)); //TODO: figure out how to make an argument-less callback so we stop getting an unused variable warning
    }
    ~Mirror() {
      setPos(XAXIS, 0.0f);
      setPos(YAXIS, 0.0f);
    }
    void mirrorCmdCallback_(const std_msgs::msg::String & message) const {
      static int count = 0;
      switch(count){
        case 0:
          setPos(XAXIS, 1.0f);
          setPos(YAXIS, 1.0f);
          RCLCPP_INFO(this->get_logger(), "Attempting to set to (1,1)");
          count++;
          break;
        case 1:
          setPos(XAXIS, -1.0f);
          setPos(YAXIS, 1.0f);
          RCLCPP_INFO(this->get_logger(), "Attempting to set to (-1,1)");
          count++;
          break;
        case 2:
          setPos(XAXIS, -1.0f);
          setPos(YAXIS, -1.0f);
          RCLCPP_INFO(this->get_logger(), "Attempting to set to (-1,-1)");
          count++;
          break;
        case 3:
          setPos(XAXIS, 1.0f);
          setPos(YAXIS, -1.0f);
          RCLCPP_INFO(this->get_logger(), "Attempting to set to (1,-1)");
          count = 0;
          break;
        default:
          this->setPos(XAXIS, 1.0f);
          this->setPos(YAXIS, 1.0f);
          RCLCPP_ERROR(this->get_logger(), "Mirror default condition. How did you get here?");
          count = 0;
          break;
      }
    }
    bool setPos(uint16_t whichAxis, double newCoord) const {
      if((newCoord > MAXPOSCOORD) || (newCoord < MAXNEGCOORD)){
        RCLCPP_ERROR(this->get_logger(), "New %s coordinate \"%f\" out of range! Aborting update.", ((whichAxis == XAXIS) ? "x":"y"), newCoord);
        return(0);
      } else {
        auto message = custom_interfaces::msg::MirrorUpdate();
        message.mirror_id = mirrorId;
        message.cmd = updatePosCmd;
        message.axis = whichAxis;
        message.arg = newCoord;
        mirrorUpdatePub_->publish(message);
        return(1);   
      }
    }
    bool setCurrent(uint16_t whichAxis, double newCurrent){
      if((newCurrent > MAXPOSCURRENT) || (newCurrent < MAXNEGCURRENT)){
        RCLCPP_ERROR(this->get_logger(), "New %s current \"%f\" out of range! Aborting update.", ((whichAxis == XAXIS) ? "x":"y"), newCurrent);
        return(0);
      } else {
        auto message = custom_interfaces::msg::MirrorUpdate();
        message.mirror_id = mirrorId;
        message.cmd = updateCurrentCmd;
        message.axis = whichAxis;
        message.arg = newCurrent;
        mirrorUpdatePub_->publish(message);
        return(1);
      }
    }
    bool queryStatus(){
      return(0);
    }
  
  private:
    rclcpp::Publisher<custom_interfaces::msg::MirrorUpdate>::SharedPtr mirrorUpdatePub_;
    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr mirrorCmdSub_;
    int16_t mirrorId;
};

int main(int argc, char * argv[]){
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Mirror>());
  rclcpp::shutdown();
  return 0;
}
